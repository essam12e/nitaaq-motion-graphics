# E-commerce Product Video (Product Commercial Director)

Code: `src/scenes/commerce/product-director.tsx` (product-hero, product-detail), recipes in `src/director/recipes.ts`, genre arc `product` in `src/director/plan.ts`. Module `product-commercial` (selected for genre `product`: something to sell with the real product image).

## Narrative

`hook → product → detail → feature → offer → social → proof → cta` — beats without material are dropped (no fake reviews, no invented offers). Existing commerce families stay available: `product-showcase`, `product-grid`, `product-details`, `price-offer`, `shopping-cart`, `checkout-flow`, `order-success`, `before-after`, `comparison-table`, `testimonial`/`social-proof` (only with real, sourced quotes), `category-showcase`.

## New scenes

- `product-hero` — drop-land (the product drops with weight and lands; contact = the impact anchor), rim-light (a light rim sweeps the silhouette), dark-reveal (the product emerges from shadow).
- `product-detail` — macro (camera zooms into **declared** points of interest), callouts (pointer lines only to points the brief declares with `at`), specs (spec rail beside the product).

## The product is never altered

- User product images are ingested byte-identical (SHA-1 verified) and drawn with `object-fit: contain` — shape, colours, logo, text, packaging and proportions are untouched. Light effects are drawn **around/over** the image as separate layers, never baked into it.
- No product is generated or replaced; without a product image the product beats use the product name/price typographically.
- Callouts never point at invented features: no `at` point → no callout line.
- QC: `MEDIA_DISTORTED` / `MEDIA_BROKEN` block delivery.

Acceptance video 2 (product ad with music); the product-first ad variant also exercises it (PRODUCT_VIDEO.md).


---

# Launch / Hype Film

Code: `tease-reveal` and `feature-montage` in `src/scenes/commerce/product-director.tsx`, genre arc `launch` (`src/director/plan.ts`), `launch-hype` style, transition engine rhythm rules, procedural soundtrack.

## Structure

`tease → reveal → montage → feature → product → offer → cta` (opener `tease` replaces the hook when there is material to withhold). Beats without material are dropped; a supplied screenshot or product is never lost (a `demo`/`product` beat is inserted).

- `tease-reveal` — slit (a thin light slit opens onto the reveal), countdown (3-2-1 in the project numerals), word-tease (tease lines, then the name). Tease copy comes from `content.tease` (split into clauses) or the hook; the reveal is `content.reveal`, the product name or the brand. `content.launchDate` is shown under the reveal.
- `feature-montage` — flash (one big word per beat) or rail (features stream past the product).
- Escalation: the AI Creative Director's energy curve builds to the hero (the reveal or the product), and the CTA resolves.

## Hype ≠ chaos

- Rhythmic hard cuts (≥ 25 % of cuts, more on beats), one flashy transition budget, never the same transition twice in a row.
- One hero moment; the soundtrack's downbeat/drop is placed on it (`heroSec`), the Sound Director puts a build (riser ending exactly on the reveal) and one impact there, and avoids doubling the soundtrack's own hits.
- Hierarchy stays: one message per scene, CTA readable and held.
- `launch-hype` style (near-black stage, one hot colour, hard light) is used when the wording is hype/bold («حماس»، «جريء»، "hype", teaser); otherwise the brand or industry style.

Acceptance videos 10 (9:16 hype with sport soundtrack) and 17 (mixed Arabic/English SaaS launch).


---

# Ad Creative Variants

Code: `src/director/variants.ts` (`STRATEGIES`, `planVariants`), CLI `variants`, brief field `variants`.

```bash
npx tsx cli/nitaaq.ts variants brief.json --strategies problem-first,product-first,offer-first --aspects 9:16,4:5,1:1,16:9 [--plan-only] [--out dir]
```

or in the brief: `"variants": { "strategies": ["problem-first", "offer-first"], "aspects": ["9:16", "1:1"] }`.

## Strategies (they change the story, not the colours)

| Strategy | Needs in the brief | Opening / order | Pace |
|---|---|---|---|
| problem-first | a problem | hook → problem → bridge → solution → feature → proof → cta | brief |
| product-first | a product | **product** in the first second → feature → detail → offer → proof → cta | brief |
| benefit-first | features or a solution | hook (benefit) → feature → product → demo → proof → cta | brief |
| offer-first | an offer or price | **offer** first → product → feature → social → cta; CTA earlier and held longer | fast |
| result-first | a sourced stat / series / testimonial | proof → data → solution → feature → cta | brief |

A strategy whose material is missing is **skipped with the reason** (`unsupported` in the report) — nothing is invented to make a variant possible.

Each variant keeps the brand identity (logo, colours, brand motion) and gets its own hook copy, arc (`preferences.arc`), pacing, seed (`<base>:<strategy>`) and therefore its own typography emphasis and transitions. The explicit arc may open on its own first beat (product / offer) instead of a generic hook.

## Aspects are recomposed, not cropped

Every aspect is **directed separately**: layouts, text fitting, safe areas, map projection heights and scene choices are computed for 9:16, 4:5, 1:1 and 16:9 (e.g. feature grids become stacks in portrait). Each job runs the full pipeline (QC included) and the command writes `<base>.variants-report.json` with every variant's scenes, delivery path and scores.
