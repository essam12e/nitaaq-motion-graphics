# E-commerce Product Video (Product Commercial Director)

Code: `src/scenes/commerce/product-director.tsx` (product-hero, product-detail), recipes in `src/director/recipes.ts`, genre arc `product` in `src/director/plan.ts`. Module `product-commercial` (selected for genre `product`: something to sell with the real product image).

## Narrative

`hook → product → detail → feature → offer → social → proof → cta` — beats without material are dropped (no fake reviews, no invented offers). Existing commerce families stay available: `product-showcase`, `product-grid`, `product-details`, `price-offer`, `shopping-cart`, `checkout-flow`, `order-success`, `before-after`, `comparison-table`, `testimonial`/`social-proof` (only with real, sourced quotes), `category-showcase`.

## New scenes

- `product-hero` — drop-land (the product drops with weight and lands; contact = the impact anchor), rim-light (a light rim sweeps the silhouette), dark-reveal (the product emerges from shadow).
- `product-detail` — macro (camera zooms into **declared** points of interest), callouts (pointer lines only to points the brief declares with `at`), specs (spec rail beside the product).

## The product is never altered

- User product images are ingested byte-identical (SHA-1 verified) and drawn with `object-fit: contain` — shape, colours, logo, text, packaging and proportions are untouched. Light effects are drawn **around/over** the image as separate layers, never baked into it.
- No product is generated or replaced; without a product image the product beats use the product name/price typographically.
- Callouts never point at invented features: no `at` point → no callout line.
- QC: `MEDIA_DISTORTED` / `MEDIA_BROKEN` block delivery.

Acceptance video 2 (product ad with music); the product-first ad variant also exercises it (PRODUCT_VIDEO.md).


---

# Video media

User video clips play inside the film the same way images do: `<Media src=…>` detects the kind and a video goes to `<VideoMedia>`. Remotion stays the only clock. A clip never plays on its own; every frame shows the source frame computed from the scene frame. Renders, stills, `nitaaq seek` and QC therefore always agree.

## Giving the director a video

```json
"assets": [
  { "path": "demo.mov", "kind": "video" },
  { "path": "screen.mp4", "kind": "video", "clip": { "startFrom": 2, "endAt": 6, "loop": true, "playbackRate": 1.5 } }
]
```

- **Accepted formats:** MP4, MOV, WebM and M4V.
- **Wrong kind:** a video listed as `"kind": "image"` is detected from its extension and handled as a video.
- **Where it plays:** when the brief has a video, the `video-media` module is loaded. The storyboard then shows the user's footage once, ahead of other choices, as it already does for the user's real screenshot.

## Video Asset Pipeline (`src/node/video-assets.ts`)

`Source → Cache → Probe → Normalize → Proxy → Segment → Trim`. Every step is cached by file hash: a second run on the same file takes a few milliseconds.

| Step | What happens |
|---|---|
| Source | The original is copied **byte-identical** to `assets/<hash>-<name>` and verified. |
| Probe | ffprobe reads size (rotation-aware), fps, VFR, codec, pixel format, audio and bitrate. |
| Normalize | Only when needed: codec other than H.264/VP8/VP9, QuickTime container, variable frame rate, rotation metadata, odd dimensions, non-4:2:0 H.264, or > 60 fps. The result is H.264 yuv420p at a constant frame rate, written to `*.norm.mp4`. The asset keeps `original`. |
| Proxy | Triggered by a long edge > 1920 px, > 20 Mbit/s or > 80 MB. Produces a 960 px `*.proxy.mp4` (never upscaled). Only `preview` / `animatic` renders use it; `draft` / `production` use the full file. |
| Segment | When the user gives no trim, the best window is **measured**, not assumed to start at 0. The score is motion + contrast, with penalties for black/flat frames and for hard cuts. The reason is recorded in `segmentReason`. |
| Trim | The chosen window becomes the asset's `clip`. |

CLI: `nitaaq video probe <file>` · `nitaaq video prepare <file> --project <dir> [--id] [--segment N] [--proxy] [--loop] [--rate]`.

## Clip model (`src/media/video.ts`)

Clip settings are merged in this order, later winning: asset `clip` < scene `content.clip` / `content.clips[i]` < component prop.

| Field | Meaning |
|---|---|
| `startFrom` / `endAt` | Trim, in source seconds (clamped to the source). |
| `playbackRate` | 0.25–4. |
| `loop` | Wraps the trimmed window. Without it the last source frame holds. |
| `delay` | Shows the first frame until the clip starts. |
| `muted` / `volume` | Off by default; the Sound Director owns the mix. When enabled, the sound uses the same trim, rate and loop. |

`videoTimeAt(sceneSeconds, clip, sourceFps)` is a pure function: the same frame always maps to the same source time, in any order and on any worker.

## VideoMedia props

`src`, `width`, `height`, `fit` (`cover` by default; product and screenshot roles are always `contain`), `objectPosition`, `radius`, `frame`, `shadow`, `mask` (a morph-library shape name such as `squircle`, `circle`, `phone` or `blob`, or any CSS clip-path), `clip`, and `style` for opacity and transforms. It works inside cards, Surfaces and masks, and several can play in one scene.

The rounding and the mask are applied to the video picture itself rather than to a clipping box around it. Chrome's anti-aliasing of a clipped box around a changing frame varied between render runs; on the picture it is identical every time.

## Scene family `video-showcase`

| Variant | Use |
|---|---|
| `card` | One clip on a Surface card with a soft 3D entrance. |
| `split` | Up to 4 clips playing together, each with its own trim and rate. Each clip keeps its own shape (9:16 next to 16:9), and the grid is chosen so the smallest clip is as large as possible. |
| `mask` | A clip inside a shape (squircle by default). |
| `full` | Full-bleed clip under the title. |

Old media scenes (`image-reveal` and the others) accept a video in their image field with no change.

## Seek, QC and budget

- **Seek:** `seek(t)` reports each clip's source `time`, `phase` (`before` / `playing` / `held`) and `loopIndex`.
- **QC:** the probe waits for video frames to decode before measuring, and a broken clip is reported as a broken *video frame*.
- **Effect budget:** each simultaneous clip counts as a decode (more above 1080p).

## Verified

A test clip that draws its own frame number was decoded from rendered MP4 frames. In 16:9, 48 of 48 frames showed exactly the source frame `seek` predicted, covering trim, rate ×2, loop wrap and hold. In 9:16 the cover crop hides most of the number, so only a consistency check is possible there; it also gave 48 of 48. The clip's sound was checked by frequency analysis for trim, loop, rate and volume.


---



---

# Launch / Hype Film

Code: `tease-reveal` and `feature-montage` in `src/scenes/commerce/product-director.tsx`, genre arc `launch` (`src/director/plan.ts`), `launch-hype` style, transition engine rhythm rules, procedural soundtrack.

## Structure

`tease → reveal → montage → feature → product → offer → cta` (opener `tease` replaces the hook when there is material to withhold). Beats without material are dropped; a supplied screenshot or product is never lost (a `demo`/`product` beat is inserted).

- `tease-reveal` — slit (a thin light slit opens onto the reveal), countdown (3-2-1 in the project numerals), word-tease (tease lines, then the name). Tease copy comes from `content.tease` (split into clauses) or the hook; the reveal is `content.reveal`, the product name or the brand. `content.launchDate` is shown under the reveal.
- `feature-montage` — flash (one big word per beat) or rail (features stream past the product).
- Escalation: the AI Creative Director's energy curve builds to the hero (the reveal or the product), and the CTA resolves.

## Hype ≠ chaos

- Rhythmic hard cuts (≥ 25 % of cuts, more on beats), one flashy transition budget, never the same transition twice in a row.
- One hero moment; the soundtrack's downbeat/drop is placed on it (`heroSec`), the Sound Director puts a build (riser ending exactly on the reveal) and one impact there, and avoids doubling the soundtrack's own hits.
- Hierarchy stays: one message per scene, CTA readable and held.
- `launch-hype` style (near-black stage, one hot colour, hard light) is used when the wording is hype/bold («حماس»، «جريء»، "hype", teaser); otherwise the brand or industry style.

Acceptance videos 10 (9:16 hype with sport soundtrack) and 17 (mixed Arabic/English SaaS launch).


---

# Ad Creative Variants

Code: `src/director/variants.ts` (`STRATEGIES`, `planVariants`), CLI `variants`, brief field `variants`.

```bash
npx tsx cli/nitaaq.ts variants brief.json --strategies problem-first,product-first,offer-first --aspects 9:16,4:5,1:1,16:9 [--plan-only] [--out dir]
```

or in the brief: `"variants": { "strategies": ["problem-first", "offer-first"], "aspects": ["9:16", "1:1"] }`.

## Strategies (they change the story, not the colours)

| Strategy | Needs in the brief | Opening / order | Pace |
|---|---|---|---|
| problem-first | a problem | hook → problem → bridge → solution → feature → proof → cta | brief |
| product-first | a product | **product** in the first second → feature → detail → offer → proof → cta | brief |
| benefit-first | features or a solution | hook (benefit) → feature → product → demo → proof → cta | brief |
| offer-first | an offer or price | **offer** first → product → feature → social → cta; CTA earlier and held longer | fast |
| result-first | a sourced stat / series / testimonial | proof → data → solution → feature → cta | brief |

A strategy whose material is missing is **skipped with the reason** (`unsupported` in the report) — nothing is invented to make a variant possible.

Each variant keeps the brand identity (logo, colours, brand motion) and gets its own hook copy, arc (`preferences.arc`), pacing, seed (`<base>:<strategy>`) and therefore its own typography emphasis and transitions. The explicit arc may open on its own first beat (product / offer) instead of a generic hook.

## Aspects are recomposed, not cropped

Every aspect is **directed separately**: layouts, text fitting, safe areas, map projection heights and scene choices are computed for 9:16, 4:5, 1:1 and 16:9 (e.g. feature grids become stacks in portrait). Each job runs the full pipeline (QC included) and the command writes `<base>.variants-report.json` with every variant's scenes, delivery path and scores.
