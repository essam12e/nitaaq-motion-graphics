# E-commerce Product Video (Product Commercial Director)

Code: `src/scenes/commerce/product-director.tsx` (product-hero, product-detail), recipes in `src/director/recipes.ts`, genre arc `product` in `src/director/plan.ts`. Module `product-commercial` (selected for genre `product`: something to sell with the real product image).

## Narrative

`hook → product → detail → feature → offer → social → proof → cta` — beats without material are dropped (no fake reviews, no invented offers). Existing commerce families stay available: `product-showcase`, `product-grid`, `product-details`, `price-offer`, `shopping-cart`, `checkout-flow`, `order-success`, `before-after`, `comparison-table`, `testimonial`/`social-proof` (only with real, sourced quotes), `category-showcase`.

## New scenes

- `product-hero` — drop-land (the product drops with weight and lands; contact = the impact anchor), rim-light (a light rim sweeps the silhouette), dark-reveal (the product emerges from shadow).
- `product-detail` — macro (camera zooms into **declared** points of interest), callouts (pointer lines only to points the brief declares with `at`), specs (spec rail beside the product).

## The product is never altered

- User product images are ingested byte-identical (SHA-1 verified) and drawn with `object-fit: contain` — shape, colours, logo, text, packaging and proportions are untouched. Light effects are drawn **around/over** the image as separate layers, never baked into it.
- No product is generated or replaced; without a product image the product beats use the product name/price typographically.
- Callouts never point at invented features: no `at` point → no callout line.
- QC: `MEDIA_DISTORTED` / `MEDIA_BROKEN` block delivery.

Acceptance video 2 (product ad with music); the product-first ad variant also exercises it (PRODUCT_VIDEO.md).


---

# Video media

User video clips play inside the film the same way images do: `<Media src=…>` detects the kind and a video goes to `<VideoMedia>`. Remotion stays the only clock. A clip never plays on its own; every frame shows the source frame computed from the scene frame. Renders, stills, `nitaaq seek` and QC therefore always agree.

## Giving the director a video

```json
"assets": [
  { "path": "demo.mov", "kind": "video" },
  { "path": "screen.mp4", "kind": "video", "clip": { "startFrom": 2, "endAt": 6, "loop": true, "playbackRate": 1.5 } }
]
```

- **Accepted formats:** MP4, MOV, WebM and M4V.
- **Wrong kind:** a video listed as `"kind": "image"` is detected from its extension and handled as a video.
- **Where it plays:** when the brief has a video, the `video-media` module is loaded. The storyboard then shows the user's footage once, ahead of other choices, as it already does for the user's real screenshot.

## Video Asset Pipeline (`src/node/video-assets.ts`)

`Source → Cache → Probe → Normalize → Proxy → Segment → Trim`. Every step is cached by file hash: a second run on the same file takes a few milliseconds.

| Step | What happens |
|---|---|
| Source | The original is copied **byte-identical** to `assets/<hash>-<name>` and verified. |
| Probe | ffprobe reads size (rotation-aware), fps, VFR, codec, pixel format, audio and bitrate. |
| Normalize | Only when needed: codec other than H.264/VP8/VP9, QuickTime container, variable frame rate, rotation metadata, odd dimensions, non-4:2:0 H.264, or > 60 fps. The result is H.264 yuv420p at a constant frame rate, written to `*.norm.mp4`. The asset keeps `original`. |
| Proxy | Triggered by a long edge > 1920 px, > 20 Mbit/s or > 80 MB. Produces a 960 px `*.proxy.mp4` (never upscaled). Only `preview` / `animatic` renders use it; `draft` / `production` use the full file. |
| Segment | When the user gives no trim, the best window is **measured**, not assumed to start at 0. The score is motion + contrast, with penalties for black/flat frames and for hard cuts. The reason is recorded in `segmentReason`. |
| Trim | The chosen window becomes the asset's `clip`. |

CLI: `nitaaq video probe <file>` · `nitaaq video prepare <file> --project <dir> [--id] [--segment N] [--proxy] [--loop] [--rate]`.

## Clip model (`src/media/video.ts`)

Clip settings are merged in this order, later winning: asset `clip` < scene `content.clip` / `content.clips[i]` < component prop.

| Field | Meaning |
|---|---|
| `startFrom` / `endAt` | Trim, in source seconds (clamped to the source). |
| `playbackRate` | 0.25–4. |
| `loop` | Wraps the trimmed window. Without it the last source frame holds. |
| `delay` | Shows the first frame until the clip starts. |
| `muted` / `volume` | Off by default; the Sound Director owns the mix. When enabled, the sound uses the same trim, rate and loop. |

`videoTimeAt(sceneSeconds, clip, sourceFps)` is a pure function: the same frame always maps to the same source time, in any order and on any worker.

## VideoMedia props

`src`, `width`, `height`, `fit` (`cover` by default; product and screenshot roles are always `contain`), `objectPosition`, `radius`, `frame`, `shadow`, `mask` (a morph-library shape name such as `squircle`, `circle`, `phone` or `blob`, or any CSS clip-path), `clip`, and `style` for opacity and transforms. It works inside cards, Surfaces and masks, and several can play in one scene.

The rounding and the mask are applied to the video picture itself rather than to a clipping box around it. Chrome's anti-aliasing of a clipped box around a changing frame varied between render runs; on the picture it is identical every time.

## Scene family `video-showcase`

| Variant | Use |
|---|---|
| `card` | One clip on a Surface card with a soft 3D entrance. |
| `split` | Up to 4 clips playing together, each with its own trim and rate. Each clip keeps its own shape (9:16 next to 16:9), and the grid is chosen so the smallest clip is as large as possible. |
| `mask` | A clip inside a shape (squircle by default). |
| `full` | Full-bleed clip under the title. |

Old media scenes (`image-reveal` and the others) accept a video in their image field with no change.

## Seek, QC and budget

- **Seek:** `seek(t)` reports each clip's source `time`, `phase` (`before` / `playing` / `held`) and `loopIndex`.
- **QC:** the probe waits for video frames to decode before measuring, and a broken clip is reported as a broken *video frame*.
- **Effect budget:** each simultaneous clip counts as a decode (more above 1080p).

## Verified

A test clip that draws its own frame number was decoded from rendered MP4 frames. In 16:9, 48 of 48 frames showed exactly the source frame `seek` predicted, covering trim, rate ×2, loop wrap and hold. In 9:16 the cover crop hides most of the number, so only a consistency check is possible there; it also gave 48 of 48. The clip's sound was checked by frequency analysis for trim, loop, rate and volume.


---

# Lottie media

A user's Lottie animation (`.json` or dotLottie `.lottie`) plays inside the film like an image or a video clip: `<Media src=…>` detects it and hands it to `<LottieMedia>`. Remotion stays the only clock. The player never runs on its own; every frame seeks it to the exact Lottie frame computed from the scene frame, so renders, stills, `nitaaq seek` and QC agree.

## Giving the director a Lottie

```json
"brand": { "name": "وصل", "logo": "logo.json" },
"assets": [
  { "path": "check.json", "kind": "icon", "clip": { "marker": "draw" } },
  { "path": "hero.lottie", "kind": "lottie", "clip": { "loop": true, "playbackRate": 1.2 } }
]
```

- **Kinds:** `lottie`, an `icon` given as a Lottie file, or a logo that is a Lottie file. A `.json` / `.lottie` listed as `image` is also handled as a Lottie.
- **The module is lazy:** `lottie` is selected only when the brief has a Lottie. The node pipeline is imported only then, and the player (lottie-web, about 390 KB) is a separate render chunk that the browser loads only when a scene shows a Lottie.
- **Lottie logo:** no raster analysis runs on it, and the raster logo engine (`logo-animation`) is not used. When the brief names no colours, the logo's own static colours give the palette.

## Lottie Asset Pipeline (`src/node/lottie-assets.ts`)

| Step | What happens |
|---|---|
| Source | The original is copied **byte-identical** to `assets/<hash>-<name>` and verified. |
| Unpack | A dotLottie is read with a built-in ZIP reader (stored and deflate entries, 64 MB cap). The first animation in its manifest is used. |
| Images | Images referenced by path (next to the JSON or inside the dotLottie) are embedded as data URIs. A missing image is an error, never a blank. |
| Inspect | Size, frame rate, frame range, markers, layers, masks, mattes, effects, text, images, 3D, a complexity score and the static colours. |
| Refuse | Expressions (script inside the renderer, not deterministic) and broken timing or size are refused with a clear reason. 3D layers, AE effects, live text without glyphs and very heavy files render with a warning. |
| Cache | Keyed by file hash plus the hashes of side images. A second run takes a few milliseconds; a changed image invalidates it. |

When the file had to be rewritten (unpacked or images embedded), the render uses a self-contained copy `*.lottie.json` and the asset keeps `original`.

CLI: `nitaaq lottie inspect <file>` · `nitaaq lottie prepare <file> --project <dir> [--id] [--kind lottie|logo|icon] [--marker name] [--loop] [--rate x]`.

## Clip model (`src/media/lottie.ts`)

The same clip model as video (asset `clip` < scene `content.clip` < component prop), measured in the animation's own frame rate:

| Field | Meaning |
|---|---|
| `marker` | Play one named marker (overrides `startFrom` / `endAt`). Unknown names play the whole animation. |
| `startFrom` / `endAt` | Trim, in seconds from the first frame. |
| `playbackRate` | 0.25–4. |
| `loop` | Wraps the window. Without it the last frame holds. |
| `delay` | Shows the first frame until it starts. |

`lottieFrameAt(sceneSeconds, clip, timing)` is pure and sub-frame accurate: a 60 fps Lottie in a 30 fps film plays at its true speed.

**Logos:** a Lottie logo plays its own animation in the logo-moment families (`lottie-moment`, `logo-reveal`, `brand-intro`, `cta-logo`). Everywhere else (a small logo inside another scene) it shows its finished pose. Media and seek share this rule (`LOTTIE_LOGO_PLAYS_IN`).

## Scene family `lottie-moment`

| Variant | Use |
|---|---|
| `logo` | The Lottie logo plays, then the line under it. |
| `icon` | The Lottie on a soft tile, title beside or under it. |
| `hero` | The Lottie large, title above. |

Old media scenes (`image-reveal` and the others) accept a Lottie in their image field with no change.

## Seek, QC and budget

- **Seek:** `seek(t)` reports each Lottie's `frame`, `phase` (`before` / `playing` / `held`) and `loopIndex`.
- **QC:** the probe waits for players to draw. A Lottie that failed to load, or a missing player package, is a critical `MEDIA_BROKEN` issue that names the cause.
- **Effect budget:** each Lottie on screen counts 0.1 plus its measured complexity (capped at 0.6), weighted by duration.

## Determinism

lottie-web puts `translate3d(0,0,0)` on its `<svg>`. Chrome then rasters it as its own layer at a scale that depends on which frames that tab drew before, so pixels varied between runs. LottieMedia draws the SVG flat, and two full renders are now byte-identical.

## Verified

A test Lottie whose bar sits at x = 4 × frame was decoded from rendered MP4 frames in both 16:9 and 9:16. 284 of 284 frames matched the frame `seek` predicted, within 0.22 Lottie frame, covering play, rate ×2 with delay, loop and hold. The 16 frames not measured are the scenes' fade-ins. Two full renders of each aspect were byte-identical.


---

# Vector Engine 2.0

The user's SVG can be animated from its real geometry. The engine reads the file into a tree of groups, matrices, outlines and paint. Each frame, it draws that tree as inline SVG: traced, filled, assembled, or morphed into a second SVG. The engine never rasterises the art and never replaces it, so the last frame looks like the file as drawn.

Remotion stays the only clock. Every program is a pure function of the scene frame, so renders, stills, `nitaaq seek` and QC agree.

## Giving the director an SVG

```json
"assets": [
  { "path": "emblem.svg", "kind": "svg" },
  { "path": "shield.svg", "kind": "svg" }
]
```

- **Kind `svg` only.** An SVG given as `logo` or `image` keeps its existing treatment: it is shown as an image, and the logo engine still runs for an SVG logo. Nothing about existing SVG logos changes.
- **The module is lazy.** `advanced-vector` is selected only when the brief has an asset of kind `svg`. The node pipeline is imported only then.
- **Scene choice.** With one SVG the director picks `vector-draw` with the `draw` or `build` variant. With two SVGs it picks `sequence` (draw, then morph into the second) or `morph`. The scene is the user's own material, so it is shown once and preferred, like their video or Lottie.

## Scene family `vector-draw`

| Variant | What happens |
|---|---|
| `draw` | Every outline is traced by arc length, in reading order (right to left by default). The pen moves at a speed proportional to length, and each shape gets a minimum time so small details still read. Each shape's fill then floods in. A shape without a stroke is traced in its fill colour, and that guide line fades as the fill arrives. Text and images fade in at the end. |
| `build` | Top-level groups assemble one after another. Each scales and rises from the centre of its own bounds (the transform origin) and settles with a spring. |
| `morph` | Each shape of the first SVG becomes its partner in the second. Shapes are paired by position, size and colour. Shapes left over shrink into their nearest partner or grow out of it. Fills, strokes and gradients interpolate in OKLab. The second SVG is fitted into the first one's view box. |
| `sequence` | Draw, a short hold, then morph into `morphTo`. Without `morphTo` it is just `draw`. |
| `graph` | Procedural art from a Non-Destructive Vector Graph (see below). |

Content fields:

- `svg`: an asset id or path.
- `morphTo`
- `order`: `rtl` (default), `ltr`, `ttb`, `center-out` or `document`.
- `drawSeconds`, `morphSeconds`
- `arc`: Manim-style bend of the morph point paths, in radians.
- `role`: `illustration`, `logo` or `icon`.
- `title`, `eyebrow`, `subtitle`, `caption`.
- `graph`

The timings are in `src/vector/scene-program.ts` and are shared by the scene, `seek`, QC and the effect budget.

## Reading an SVG (`src/vector/svg.ts`)

| Part | Handling |
|---|---|
| Structure | `g`, `a`, `switch`, nested `svg` (its own viewport and viewBox), and `use` of elements or `symbol`s (scaled into their box). Every group keeps its matrix, opacity and clip / mask / filter. |
| CSS | `<style>` rules with tag, `.class` and `#id` compounds, plus descendant and child combinators. Specificity and order are respected, `style=""` wins, and inherited properties flow down. Other selectors are reported, not guessed. |
| Shapes | `path`, `rect` (with rounded corners), `circle`, `ellipse`, `line`, `polyline` and `polygon` become one absolute cubic path each. Each path is measured: length, exact bounds from the curve extrema, segment count. |
| Paint | Fill / stroke, opacities, fill rule, caps, joins, dashes and non-scaling strokes. Colours can be hex, rgb(a), hsl(a) or named. |
| Gradients | Linear and radial gradients, with `href` inheritance of stops and attributes, units, transform and spread. They are read as data so they can be interpolated, and also kept as SVG. |
| Kept as SVG | Clip paths, masks, patterns, filters and markers. Their ids are scoped to each instance, so two copies of the same art never collide. |
| Text / images | Drawn as authored, with inherited styles written onto the element. Text uses the viewer's fonts, and the engine warns about this. Convert text to outlines for exact type. |
| Removed | `script`, `foreignObject`, `on…` handlers, external links (only `#refs` and embedded images stay) and SMIL animation, because the film's timeline drives motion. Each removal is reported. The user's file is never changed. |
| Never throws | Broken input becomes an error ("nothing to draw", missing size), not a crash. More than 20,000 segments gives a warning. |

Geometry (`src/vector/geometry.ts`, `src/vector/matrix.ts`):

- Affine matrices that parse every SVG transform function, compose around an origin, decompose, recompose, and interpolate with the shortest rotation.
- Arc length (Gauss–Legendre).
- Exact cubic splitting.
- After-Effects-style trim paths (start / end / offset, wrapping, sequential or parallel over sub-paths).
- Bounds, flattening and simplification.

## Vector Asset Pipeline (`src/node/vector-assets.ts`)

| Step | What happens |
|---|---|
| Source | The SVG is copied **byte-identical** to `assets/<hash>-<name>.svg` and verified. It stays the asset's `src`. |
| Parse | The sanitised VectorDoc is written next to it as `*.vector.json` (`asset.vector.doc`). The render reads this file, so it never re-parses and never meets anything the sanitiser removed. |
| Inspect | Shapes, groups, segments, clips, masks, gradients, text and images, a complexity score, and the colours actually painted (a mask's ramp is not a brand colour). |
| Refuse | An SVG with nothing to draw, or a file that is not `.svg`. |
| Cache | Keyed by the file hash. |

CLI:

- `nitaaq vector inspect <file.svg>`
- `nitaaq vector prepare <file.svg> --project <dir> [--id] [--kind svg|logo|icon|image]`
- `nitaaq vector frame <graph.json> <t>` prints a graph as SVG at second t.

## Booleans (`src/vector/boolean.ts`)

- **render** is stable and the default. The renderer performs the operation: intersect is a clip path, subtract is a mask, union draws both shapes as one group, and exclude uses even-odd. It is exact at every pixel for any curves.
- **exact** is EXPERIMENTAL. It runs Greiner–Hormann polygon clipping on the outlines: corners are kept exactly and curves are sampled. The result is a real outline that can be traced or morphed.
  - Each input must be one ring.
  - A degenerate touch is resolved by a fixed, deterministic nudge.
  - When it cannot give a trustworthy answer, it returns the reason, and the graph falls back to `render` with a warning.
  - Tests compare its areas against the textbook values for squares and against the circle-lens formula.

## Non-Destructive Vector Graph (`src/vector/graph.ts`)

Procedural, animatable vector art stored as plain JSON. The schema is zod-validated and versioned. Missing inputs, duplicate ids and cycles are refused.

```
shape → transform → boolean → mask → fill / stroke (gradient) → effect → group → output
```

| Node | Parameters |
|---|---|
| `shape` | `rect` (radius), `ellipse`, `polygon`, `star` (sides, inner radius), `path` (d); `x y width height` |
| `transform` | `x y rotate scale scaleX scaleY`, origin as a fraction of the input's bounds |
| `boolean` | `a b op` (union / subtract / intersect / exclude), `mode` (render / exact) |
| `fill` | `color` or `gradient` (linear with angle, or radial, keyframable stops), `opacity` |
| `stroke` | `color width cap join`, trim `start end offset` (drawing on), `keepFill` |
| `mask` | `input mask`, `mode` (clip / alpha / invert) |
| `effect` | `shadow`, `glow` or `blur`, with `amount color x y` |
| `group` | `inputs`, `opacity` |

Any number can be a constant or keyframes `{ "k": [{ "t": 0, "v": 0 }, { "t": 1.2, "v": 1, "ease": "back-out" }] }`, with time in seconds. Colours can be keyed too. Easing names come from the motion system, plus `linear` and `hold`.

Evaluation is pure. Each node's result is memoised by its resolved parameters and its inputs. A node whose values do not change between frames is not recomputed; after the last key, a frame recomputes nothing.

The Creative Director writes graphs into `video.json` as scene `vector-draw`, variant `graph`. The example is `test/fixtures/vector/graph-badge.json`. It contains:

- A rounded plate with a hole cut by an exact boolean.
- An animated gradient.
- A ring drawn on by a trimmed stroke.
- A star that spins in with a glow.

## Seek, QC, budget

- `nitaaq seek` lists `vectors` per scene: asset, `morphTo`, `mode` (draw / build / morph / graph), `progress`, `phase` and `step` / `steps` for a sequence.
- QC reads `data-qc-kind="vector"`. The probe waits while vector art is loading. Art that fails to load is a critical `MEDIA_BROKEN` with the reason.
- The effect budget adds "vector art (path rebuild per frame)" while a program runs. It uses the measured complexity of both documents for a morph, and the node count for a graph.

## Limits (honest)

- Text inside an SVG uses the viewer's fonts. Outlines are exact.
- A morph pairs whole shapes and cannot morph text or images, which crossfade in place. A shape's clip or mask changes by a crossfade when its partner sits in a different context.
- An object-bounding-box gradient on a rotated shape is measured on the world-space outline during a morph.
- Exact booleans take one ring per input. Anything else uses render booleans.
- Patterns, filters and markers are drawn as authored; they are not animated.


---

# Launch / Hype Film

Code: `tease-reveal` and `feature-montage` in `src/scenes/commerce/product-director.tsx`, genre arc `launch` (`src/director/plan.ts`), `launch-hype` style, transition engine rhythm rules, procedural soundtrack.

## Structure

`tease → reveal → montage → feature → product → offer → cta` (opener `tease` replaces the hook when there is material to withhold). Beats without material are dropped; a supplied screenshot or product is never lost (a `demo`/`product` beat is inserted).

- `tease-reveal` — slit (a thin light slit opens onto the reveal), countdown (3-2-1 in the project numerals), word-tease (tease lines, then the name). Tease copy comes from `content.tease` (split into clauses) or the hook; the reveal is `content.reveal`, the product name or the brand. `content.launchDate` is shown under the reveal.
- `feature-montage` — flash (one big word per beat) or rail (features stream past the product).
- Escalation: the AI Creative Director's energy curve builds to the hero (the reveal or the product), and the CTA resolves.

## Hype ≠ chaos

- Rhythmic hard cuts (≥ 25 % of cuts, more on beats), one flashy transition budget, never the same transition twice in a row.
- One hero moment; the soundtrack's downbeat/drop is placed on it (`heroSec`), the Sound Director puts a build (riser ending exactly on the reveal) and one impact there, and avoids doubling the soundtrack's own hits.
- Hierarchy stays: one message per scene, CTA readable and held.
- `launch-hype` style (near-black stage, one hot colour, hard light) is used when the wording is hype/bold («حماس»، «جريء»، "hype", teaser); otherwise the brand or industry style.

Acceptance videos 10 (9:16 hype with sport soundtrack) and 17 (mixed Arabic/English SaaS launch).


---

# Ad Creative Variants

Code: `src/director/variants.ts` (`STRATEGIES`, `planVariants`), CLI `variants`, brief field `variants`.

```bash
npx tsx cli/nitaaq.ts variants brief.json --strategies problem-first,product-first,offer-first --aspects 9:16,4:5,1:1,16:9 [--plan-only] [--out dir]
```

or in the brief: `"variants": { "strategies": ["problem-first", "offer-first"], "aspects": ["9:16", "1:1"] }`.

## Strategies (they change the story, not the colours)

| Strategy | Needs in the brief | Opening / order | Pace |
|---|---|---|---|
| problem-first | a problem | hook → problem → bridge → solution → feature → proof → cta | brief |
| product-first | a product | **product** in the first second → feature → detail → offer → proof → cta | brief |
| benefit-first | features or a solution | hook (benefit) → feature → product → demo → proof → cta | brief |
| offer-first | an offer or price | **offer** first → product → feature → social → cta; CTA earlier and held longer | fast |
| result-first | a sourced stat / series / testimonial | proof → data → solution → feature → cta | brief |

A strategy whose material is missing is **skipped with the reason** (`unsupported` in the report) — nothing is invented to make a variant possible.

Each variant keeps the brand identity (logo, colours, brand motion) and gets its own hook copy, arc (`preferences.arc`), pacing, seed (`<base>:<strategy>`) and therefore its own typography emphasis and transitions. The explicit arc may open on its own first beat (product / offer) instead of a generic hook.

## Aspects are recomposed, not cropped

Every aspect is **directed separately**: layouts, text fitting, safe areas, map projection heights and scene choices are computed for 9:16, 4:5, 1:1 and 16:9 (e.g. feature grids become stacks in portrait). Each job runs the full pipeline (QC included) and the command writes `<base>.variants-report.json` with every variant's scenes, delivery path and scores.
