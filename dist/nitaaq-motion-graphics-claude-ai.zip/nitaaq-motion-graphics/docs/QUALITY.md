# Quality

Nothing is delivered unless every acceptance rule passes. QC runs in stages so problems are caught before the expensive render.

## Pipeline

```
validate (static, src/validation) ─► structural QC (DOM probes on sampled frames + stills, no MP4)
   ─► contact sheet + phone-view sheet ─► auto-repair (≤ 2 passes, a 3rd only while critical issues remain)
   ─► shared-element rects measured ─► sound stage + audio QC + motion-variety QC (≤ 3 re-plans)
   ─► [animatic for ADVANCED/LONG_FORM] ─► production render ─► final technical QC on the MP4
   ─► (post-render repair → re-render if needed) ─► delivery
```

Probes and pattern scans are cached per frame, so a repair pass re-checks only what changed.

## Passes and checks

| Pass | Checks |
|---|---|
| structure | text fit/overflow/off-canvas/outside safe area, overlap, fonts loaded, user media intact (no distortion, no upscaling surprises), CTA visible at the end, debug overlay absent |
| design | banned patterns (`design/banned-patterns.json`, spec level), `PATTERN_IN_FRAME` (pixel detector on stills: dot lattice, particle field, line grid, with text/media/card areas masked), contrast on real pixels, `TEXT_TOO_SMALL`, `PHONE_UNREADABLE` (text measured at phone size: 390 px wide portrait / 640 px landscape; minimum px per role), `LAYOUT_UNDERFILLED` |
| motion | `HOLD_TOO_SHORT`, `VOICE_DRIFT`, `MOTION_NO_PURPOSE`, `CAMERA_OVERUSE`, `TRANSITION_MONOTONY` (> 50 % of ≥ 4 cuts one type), `TRANSITION_REPEAT` (back-to-back), `TEXT_MOTION_REPEAT`, `TEXT_MOTION_OVERUSED`, `PERSONALITY_MISMATCH` |
| audio | `SFX_REPEAT_CONSECUTIVE` (error: same file back-to-back), `SFX_REPEAT_OVERUSED` (one file > max(2, ⌈n/5⌉) times), `SFX_DENSITY` (> round(6 + 10 × intensity) cues per 10 s), `SFX_SYNC` (> 80 ms from its anchor; builds excluded), `SFX_VOICE_CLASH`, `SFX_KEY_SILENT` (logo / hero / price / CTA / final counter with no sound), `SFX_DOUBLES_MUSIC` (info), `AUDIO_EMPTY` — see `SOUND_DIRECTOR.md` |
| technical (final) | MP4 container, H.264/yuv420p, size, fps, duration, encoder signatures stripped, audio present / not clipping / loudness, blank frames, pattern + contrast re-checked on decoded frames (all sampled frames extracted in one decode), `LOOP_SEAM` for loops |

## Scores and critique

Each pass starts at 100 (the `audio` pass is included when the sound stage ran): critical −40, error −15, warning −5. `overall` = mean of the passes that ran, capped at 59 when any critical issue exists. Every issue carries a concrete `fix` (e.g. "enable layout.scrim or use a contrast-safe text colour from brand.json"), collected in `critique[]`.

## Acceptance rules (all must pass)

zero critical issues · no dot / particle / grid background · no watermark or developer signature · no clipped or off-canvas text · all fonts loaded · user media intact · CTA readable when the film ends on one · no debug overlay · (final) valid H.264/yuv420p MP4 at the right size, fps and duration · audio present and not clipping when planned · no sound file repeated back-to-back · no blank frames.

## Auto-repair (`src/qc/repair-loop.ts`)

Safe, deterministic spec changes only: shrink text/layout, add a scrim, extend a hold, clean the background (`clean-background` → soft-gradient, decorations off), lower music/SFX, move cuts to voice phrases; audio: re-plan SFX with another seeded variation, thin the density (intensity −, min 0.2), lower SFX (×0.75, min 0.3). Issues without a safe fix stop delivery with a readable message.

## Measurement notes

- **Text overflow** is measured, not estimated: the probe measures each text node's real width with a DOM `Range` (spaces included) scaled to the line's layout width; line masks hug their content, so a line wider than its box is measured instead of silently clipped; only text with opacity > 0.05 is checked, and the finding targets the scene that owns the text.
- **Particle fields** are only reported when the blobs are spread over the frame (≥ 12 of 36 grid cells, across ≥ 3 columns and ≥ 3 rows), and diagram shapes and map drawings (`data-qc="box"`) are masked, so circles in a process diagram or coastline islands on a map are not mistaken for a pattern.

## Outputs

`quality_report.json` (v2.0: stage, scores, acceptance, critique, timings, probe cache stats, issues), `qc/…/contact-sheet.png`, `phone-view.png`, `review_log.md` (one entry per run), `audio-qc.json`, `sound-plan.json`.

## Visual QA 2.0 (`src/qc/vqa.ts`)

Beyond the fixed sample grid, QA now samples the **moments that matter**: the middle of each scene, the end of each transition, the hero, the logo and the CTA (`momentSamples`). On those frames:

| Check | Code | Severity / repair |
|---|---|---|
| protected elements (text, product, logo, CTA) inside the safe area for the **whole camera move** — measured rects are unprojected to their rest position, then `auditFraming` / `solveFraming` run on the plan | `CAMERA_FRAMING` | error → `camera-solve` (solved plan, else half amplitude) |
| product / logo recoloured by a CSS filter | `PRODUCT_ALTERED` | critical, never auto-"fixed" |
| product / logo aspect changed (> ±4%) | `PRODUCT_DISTORTED` | critical |
| text covering the product / logo | `PRODUCT_OBSTRUCTED` | > 15% warning, > 30% error → shrink layout |
| frame almost empty | `FRAME_EMPTY` | warning |
| visual weight far off centre | `COMPOSITION_UNBALANCED` | warning |
| Latin punctuation in RTL copy | `RTL_PUNCTUATION` | warning |
| Arabic word split between two letters that connect | `ARABIC_SPLIT_GLYPHS` | critical (splits at non-joining letters are legal) |

**Deterministic seek check:** frame A is rendered, then B, then A again; the two A's must match (mean diff < 0.5, max < 48) — `MOTION_NONDETERMINISTIC` otherwise (critical). `nitaaq seek <project> <t>` prints the film's exact state at any time. `NITAAQ_SKIP_DETERMINISM=1` skips the check.

## Quality scoring as a gate

`quality_report.json → categories`: composition, motion, typography, camera, brand, audio, technical and overall (weighted). Delivery needs **every category ≥ 50 and overall ≥ 70**, in addition to zero critical issues — a single bad category blocks even when the average is high. New acceptance rules: product protection, camera framing, the quality gate.


---

# Performance

Speed is a feature: a normal request takes the fast path, every expensive step is cached by content, and every run writes `performance_report.json` with measured stage times (nothing estimated).

## Fast path

1. **Task classifier** (`src/director/classify.ts`) → `SIMPLE` / `STANDARD` / `ADVANCED` / `LONG_FORM` from duration, content blocks and signals (voice, reference, extra formats, chapters). The class sets the budget: QC samples per scene (2–3), repair passes (2, a 3rd only while critical issues remain), whether the reference and beat engines run, whether an animatic is rendered first (ADVANCED / LONG_FORM), and the **effect budget**.
2. **Lazy heavy features**: the reference engine, beat engine, website capture, TTS and recompose only run when the brief asks for them. Reference analysis and beat analysis run in parallel.
2b. **Lazy modules** (`src/director/modules.ts`): the genre classifier selects modules per film; `map` (GeoJSON + projection), `soundtrack` (synthesiser), `gsap` (bundle chunk), `logo` (structure analysis with sharp) and `variants` are `import()`-ed only when selected — a simple typography film never loads them. The selection is logged and recorded as the `modules` stage.
2c. **SFX bank** is synthesised once (~4 s) and reused until the generator version changes; the procedural soundtrack is cached by its parameters (same seed → same WAV, not re-synthesised).
3. **Shared browser**: one headless Chrome per process for all stills, probes and renders.
4. **Render concurrency** = number of cores (measured; override `NITAAQ_CONCURRENCY`).

## Cache (`.cache/nitaaq-motion/`, override `NITAAQ_CACHE_DIR`, disable `NITAAQ_NO_CACHE=1`)

Content-addressed (SHA-256 of a stable JSON of the inputs + `CACHE_VERSION`). Namespaces:

| Namespace | Key | Saves |
|---|---|---|
| `bundle` | source tree hash | Remotion webpack bundle |
| `preflight` | node version, lockfile, ffmpeg, browser, fonts, voice providers | preflight (≈25 ms when unchanged) |
| `brand` | logo file hash | logo analysis + palette |
| `reference` | reference file hash (ref-v2) | reference analysis |
| `beats` | audio file hash | beat/onset/energy analysis |
| `probe` | spec slice + frame + bundle | QC DOM probes per frame |
| `pattern` | still hash + masks | dot/grid detector |
| `fonts` | font file hash | Arabic coverage check |
| `probe` (shared) | spec + transition frames | shared-element rect measurement |
| `renders` | spec (minus metadata) + profile + bundle + referenced file hashes | the MP4 itself |

`npx tsx cli/nitaaq.ts cache summary` · `cache clear [namespace]`.

## Render profiles

| Profile | Scale | fps | x264 | Use |
|---|---|---|---|---|
| preview | 0.5 | spec | ultrafast, crf 30 | quick look |
| animatic | 0.5 | 15 | veryfast, crf 30 | timing / story check before the final |
| draft | 0.75 | spec | faster, crf 23 | review copy |
| production | 1 | spec | medium, crf 18 | delivery |

## Effect budget (`src/perf/effect-budget.ts`)

Every scene family declares a cost class (LOW / MEDIUM / HIGH, see SCENE_LIBRARY.md) and every style declares its expensive effects (backdrop blur, glow, grain). The estimate is duration-weighted: LOW = 1, MEDIUM = 2, HIGH = 3 per second, + camera moves, + style effects. Levels: ≤ 1.6 LOW, ≤ 2.5 MEDIUM, ≤ 3.6 HIGH. The Director sets `design.effectBudget` from the task class (SIMPLE → LOW, or MEDIUM for heavy styles; LONG_FORM → MEDIUM; otherwise HIGH); validation warns `EFFECT_BUDGET` when a film exceeds it, and `performance_report.json → meta.effects` records score, level and contributors.

## Preflight

`npm run preflight` (fast, cached) / `--full`. `npm run setup` runs `npm ci` only when `node_modules` is missing or older than `package-lock.json`.

## performance_report.json

`totalMs`, `intakeMs`, `directorMs`, `assetsMs`, `audioMs`, `referenceMs`, `validationMs`, `qcMs`, `contactSheetMs`, `animaticMs`, `productionRenderMs`, `cache {hits, misses, byNs}`, `stages[]` (every stage with ms — includes `modules`, `sound`, `shared-elements`, `logo-structure`), `meta` (task class, profile, concurrency, canvas, effects, renderCached, repairPasses).

## Benchmark

`npx tsx cli/benchmark.ts --label after` runs cases A–D (10 s typography, 20 s product ad, 30 s SaaS/launch, 30 s audio-driven), each run in a fresh Node process: **cold** (cache cleared), **warm** (cache kept, new project), **repeat** (same project, nothing changed). Stage groups: planning, preprocessing, sound, validation, qc, animatic, render. Output: `workspace/performance-report.<label>.json` (or `--out`); the v3 measurement with the v2 comparison is committed as `docs/performance-report.json`. `--runs edit` adds the one-copy-change run.

## Measured results

| Case | Run | v2 before (s) | v3 after (s) | Change |
|---|---|---|---|---|
| A 10 s typography | cold | 71.6 | 40.2 | -44% |
| A 10 s typography | warm | 2.1 | 2.5 | 16% |
| A 10 s typography | repeat | 2.2 | 1.5 | -30% |
| A 10 s typography | edit | 40.7 | 40.0 | -2% |
| B 20 s product ad | cold | 112.6 | 78.4 | -30% |
| B 20 s product ad | warm | 5.0 | 3.2 | -36% |
| B 20 s product ad | repeat | 4.1 | 3.2 | -21% |
| B 20 s product ad | edit | 107.7 | 77.0 | -29% |
| C 30 s SaaS/launch | cold | 112.0 | 84.3 | -25% |
| C 30 s SaaS/launch | warm | 5.7 | 5.4 | -5% |
| C 30 s SaaS/launch | repeat | 5.3 | 3.1 | -42% |
| C 30 s SaaS/launch | edit | 114.1 | 87.7 | -23% |
| D 30 s audio-driven | cold | 235.0 | 73.1 | -69% |
| D 30 s audio-driven | warm | 11.6 | 3.2 | -72% |
| D 30 s audio-driven | repeat | 11.8 | 3.1 | -74% |
| D 30 s audio-driven | edit | 221.3 | 66.8 | -70% |

Cold-run stage groups (seconds, v3):

| Case | planning | preprocessing | sound | QC | animatic | render |
|---|---|---|---|---|---|---|
| A | 0.02 | 0.00 | 1.09 | 4.7 | 8.0 | 26.4 |
| B | 0.02 | 0.02 | 0.06 | 16.0 | 17.9 | 44.7 |
| C | 0.03 | 0.02 | 2.42 | 12.5 | 18.3 | 51.3 |
| D | 0.02 | 0.51 | 0.05 | 12.1 | 14.6 | 46.1 |

Measured on the same 4-core container as the v2 baseline (`docs/performance-report.json`, generated by `cli/benchmark.ts`; times are `direct()` + `produce()` wall-clock inside the run, Node start-up excluded). Notes, honestly:
- Cold and edit runs are dominated by the real render (Remotion, 4 workers) and the animatic; v3 is faster mainly because QC and repair converge in fewer passes, not because rendering itself got faster (inferred from stage totals: v2 D spent 145 s in render and 54 s in structural QC, about three times one pass; v3 D renders once).
- A warm is 0.4 s slower than v2: case A now gets a procedural soundtrack (≈1 s of synthesis, cached afterwards — the repeat run is faster than v2).
- The sound stage (Sound Director + audio QC) costs 0.05–0.1 s per film; soundtrack synthesis 1–2.5 s on first use.
- No speed claim beyond these measurements is made.

## Resource profiling (Motion 2.0)

`performance_report.json → resources`: system-wide CPU % (Chromium renders run in child processes) and memory sampled every 500 ms — overall average/peak, peak memory above the start, node RSS peak, core count, and the same per stage (`perStage`). `NITAAQ_NO_PROFILE=1` turns sampling off.


---

# Troubleshooting

Every error prints **what** failed, **where**, **why**, whether it was **repaired**, and the **action** to take. Stage logs look like `[RENDER] …`, `[QUALITY] …`.

| Symptom / code | Cause | Fix |
|---|---|---|
| `preflight` ✗ dependencies | `node_modules` missing | `npm run setup` |
| ✗ fonts | font files not synced | `npm run fonts:sync` |
| ✗ ffmpeg | no system ffmpeg and Remotion binaries missing | `npm install` (Remotion ships ffmpeg) or install ffmpeg |
| First render slow | Remotion bundle is built once and cached | Normal; later renders reuse it (see PERFORMANCE.md) |
| Exit code 2 with `questions` | brief is missing a decision (logo, voice file, TTS provider) | Ask the user, update `brief.json`, run again (`--no-logo` if they have none) |
| `INPUT_INVALID … brief.json is incomplete` | required brief fields missing | Add `request`, `content.hook`, `content.cta.text` |
| `SCENE_CONTENT_INVALID` (critical) | a scene's content does not match its schema | Fix the field named in the path (see `docs/SCENE_LIBRARY.md`); content is never guessed |
| `PLACEHOLDER_DATA` | a data/testimonial `source` says example/sample/tbd | Provide the real source or remove the scene |
| `DEVELOPER_SIGNATURE` | "made with …", a handle or a watermark in the copy | Remove it — videos are delivered without any tool/developer identity |
| `ASSET_MISSING` / `MEDIA_BROKEN` | file path wrong or unreadable image | Check the path is inside the project; re-export as PNG/JPG/WEBP/SVG |
| `MEDIA_UPSCALED` (warning) | a small user image shown large | Provide a larger original (it is never AI-upscaled or altered) |
| `FONT_NOT_ARABIC` | user font lacks Arabic glyphs/shaping | Use an Arabic-capable font or a bundled one |
| `FONT_LOAD_FAILED` (critical) | a font did not load in the renderer | `npm run fonts:sync`; check the user font file |
| `TEXT_FIT_FAIL` / `TEXT_OVERFLOW` | copy too long for the scene | Auto-repair shrinks text/layout; if it persists, shorten the copy or pick a variant with more capacity |
| `HOLD_TOO_SHORT` | not enough time to read | Auto-repair extends the scene (not in voice-synced videos — shorten the copy there) |
| `TEXT_CONTRAST_LOW` | text over a busy/low-contrast area | Auto-repair adds a scrim; or change style/brand colours |
| `LAYOUT_UNDERFILLED` (warning) | content fills little of the frame | Auto-repair scales the composition up within the safe area |
| `VOICE_DRIFT` | a voice-synced scene starts > 0.25 s away from its phrase | Provide a transcript (one line per phrase) or let the Director re-plan |
| `TTS_UNAVAILABLE` | no premium voice provider | Produce without voice, upload a recording, or set `ELEVENLABS_API_KEY` / `OPENAI_API_KEY` |
| `AUDIO_CLIPPING` / `AUDIO_QUIET` | levels | Auto-repair lowers music/SFX; check the source recording |
| `MP4_BITRATE_HIGH` (warning) | the file is unusually heavy (> 30 Mbit/s) | Lower texture/grain in the style or use the `draft` profile |
| `ENCODER_STRING` (warning) | an encoder name (x264/Lavf) survived in the MP4 | The cleanup remux failed; check the `[RENDER]` warning and that ffmpeg supports `filter_units` |
| `MP4_SIGNATURE` | encoder tag found | Should not happen (tags are stripped); report it |
| `QC_FAILED` (not delivered) | a critical issue without a safe automatic fix | Read `qc/final/quality-report.json` and the contact sheet; fix the named asset/copy |
| `PATTERN_IN_FRAME` / `BANNED_DOTTED-BACKGROUND` | a dot/grid/particle background nobody asked for | Auto-repair switches to a clean background; if the user wants the pattern, set `design.allowPatterns` and `design.justification` |
| `PHONE_UNREADABLE` | text too small at phone size | Cut words or raise `textScale`; the repair loop tries first |
| `EFFECT_BUDGET` (warning) | heavy families/blur/glow over the task's budget | Use lighter families or a flatter style; render will be slower |
| `CAMERA_OVERUSE` / `TRANSITION_MONOTONY` | motion without restraint/variety | Let the Creative Director re-plan (`direct` again) or edit `motion_spec.json` choices in video.json |
| `TRANSITION_REPEAT` / `TEXT_MOTION_REPEAT` / `TEXT_MOTION_OVERUSED` | the same transition or headline text motion twice in a row / too often | The engines avoid this by design; if it appears after manual edits, change `scenes[i].transition` or `motion.text` |
| `SFX_REPEAT_CONSECUTIVE` / `SFX_REPEAT_OVERUSED` | the same sound file back-to-back / too often | The sound stage re-plans with another variation (up to 3); if it persists, lower `audio.sfxIntensity` in the brief or remove explicit per-scene `sfx` arrays |
| `SFX_DENSITY` | too many sound cues per 10 s | Auto-repair lowers the intensity; or set `audio.sfxIntensity` lower in the brief |
| `SFX_SYNC` | a cue is > 80 ms off its motion anchor | Re-run `direct` (re-plans on the measured peaks); report it if it repeats |
| `SFX_VOICE_CLASH` | an SFX sits on top of a voice phrase | Auto-repair lowers SFX; or a lower `audio.sfxVolume` / `audio.sfxIntensity` for voice-led films |
| `SFX_KEY_SILENT` (warning) | a key moment (logo / hero / price / CTA) has no sound | Usually the density budget; raise `audio.sfxIntensity` slightly |
| `AUDIO_EMPTY` | no voice, no music and no SFX | Intended only when the user asked for silence; otherwise allow the procedural soundtrack or SFX |
| Shared transition falls back to a normal one | `shared-rects` could not see the asset at one edge of the transition (listed in the produce log) | Expected — nothing is guessed; keep the asset visible at the end of the outgoing scene |
| `gsap` cards render static (`data-qc-gsap="missing"`) | the optional `gsap` package is not installed | `npm i gsap` or let the director use a non-GSAP family |
| A map place or route end is missing (validation warning, `warnings` in the map content) | the place is not in the bundled data and the brief gave no `lat`/`lon` | Provide real coordinates or a GeoJSON file; locations are never invented |
| `variants` makes fewer files than expected | a strategy needs material the brief does not have (e.g. product-first without a product image) | Read `<base>.variants-report.json` → `unsupported` |
| `LOOP_SEAM` | last frame differs from the first in a loop | End on the opening composition |
| `REFERENCE_UNREADABLE` | reference file missing or not an image/video | Check the path or send a screenshot |
| `CAPTURE_FAILED` | website could not be captured (blocked network, blank page) | Ask the user for a screenshot of the page; nothing is fabricated |
| Same video renders instantly | the render cache matched (same spec, assets, profile) | Expected; `NITAAQ_NO_CACHE=1` or `cache clear renders` to force |
| Stale results after changing engine code | cache key misses a dependency | `npx tsx cli/nitaaq.ts cache clear` and report it |
| Studio: port in use | another process on 4455 | `STUDIO_PORT=4466 npm run studio` |
