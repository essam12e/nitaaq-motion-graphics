# Illustration Mode & Zero-Asset JavaScript Animation

Code: `src/illustration/registry.ts` (IllustrationRegistry), `src/illustration/Illustration.tsx` (renderer), `src/scenes/illustration/illustration-scenes.tsx`. Module ids `illustration` and `zero-asset` (lazy; selected only when the film needs them).

## Illustration Mode

Illustrations are **code**: SVG parts (shape + tone + stage + optional line) rendered in the film's palette, drawn on with stroke dash-offsets, deterministic per seed, editable in `video.json`. No stock art and no AI images are needed.

- **16 subjects**: growth, network, security, speed, delivery, team, idea, data, cloud, payment, chat, search, location, time, gift, rocket. `matchIllustrations(text)` maps Arabic and English copy to subjects (e.g. «نمو» → growth, "secure" → security).
- **3 styles**: flat, line, duotone (`ILLUSTRATION_STYLES`); the illustrated genre uses flat, explainers use duotone.
- Scenes:
  - `illustration-scene` — hero (one subject with the message), trio (three features, one subject each), explain (subject + explanation side by side).
  - `diagram-flow` — a system/process as nodes and connectors drawn step by step: linear (reads right-to-left in Arabic), hub, cycle.

When it is selected: genre `illustrated` («رسوم», «فلات», "illustration", `visualMode: "illustration"`), and explainer / SaaS / procedural films when copy matches a subject. The `illustration` style preset (warm field, two brand tones + one accent, rounded geometry) is used for illustrated films unless the user picked a style.

## Zero-Asset JavaScript Animation

`zero-asset-sequence` builds a full scene from typography + seeded procedural geometry only (variants shapes / lines / orbit). Placement, timing jitter and colour order come from `createRng(seed)` — never `Math.random()` — so the same project renders the same frames. Large forms only: the scene never produces dot grids, particle fields or patterned backgrounds (pattern QC would block them).

Selected for genre `procedural` («بدون صور», "zero-asset", "generative", `visualMode: "zero-asset"`) and for kinetic films with no image assets.

## Tests

`test/unit/v3-modules.test.ts` (subject matching, seed reproducibility), acceptance videos 13 (illustrated) and 16 (English kinetic + zero-asset) in `docs/TEST_RESULTS.md`.


---

# Whiteboard Animation

Code: `whiteboard` scene family in `src/scenes/illustration/illustration-scenes.tsx`, `whiteboard` style preset, module `whiteboard` (loaded only for whiteboard films).

- **Board**: clean off-white (#FBFAF6), one dark ink (#1D1D22), one marker colour (accent). No textures, no grid paper.
- **Variants**: `draw` (ink illustration from the illustration registry drawn stroke by stroke, then its label written) and `write` (the message written line by line with an underline/arrow).
- **Drawing order follows the story**: elements are revealed in reading order (right-to-left for Arabic) and the label is written after its drawing; strokes use dash-offset animation (clean vector drawing — no fake hand sprite).
- Explainer beats in a whiteboard film (problem/solution, steps) use the whiteboard style tokens: outline surfaces, ink colours, wipe entrances.
- **Voice**: when a voiceover is supplied the storyboard is voice-led (scene cuts on phrase boundaries), so drawings progress with the speech of their scene.
- Sound: draw events are `draw_stroke`; the Sound Director uses the `marker-stroke` family at low density.

Triggered by «سبورة», «وايت بورد», "whiteboard", «رسم توضيحي», "doodle" or `visualMode: "whiteboard"`. Acceptance video 14.


---

# Map Animation

Code: `src/maps/geo.ts` (gazetteer + projection), `data/geo/*.json` (bundled data), `cli/build-geo.ts` (rebuild script), `src/scenes/map/map-scenes.tsx`. Module `map` (lazy; only when the brief carries `content.map`).

## Data (real, bundled, public domain)

Built from **Natural Earth** 1:50m/1:10m (public domain) by `cli/build-geo.ts` with Douglas–Peucker simplification:

- `world.json` — 207 countries (447 KB)
- `sa-regions.json` — Saudi Arabia's 13 administrative regions (SA-01 … SA-14) with Arabic and English names and aliases («مكة»، «مكة المكرمة»، "Makkah", «الشرقية» …)
- `places.json` — 231 populated places (Saudi cities + world capitals) with lat/lon

**Nothing is fabricated**: a place, region or route end that is not in the data is reported in `warnings` (and as a validation warning) and is **not drawn** unless the brief gives its `lat`/`lon`. Every map shows its source caption («المصدر: Natural Earth»).

## Brief

```json
"map": {
  "focus": "السعودية",
  "regions": ["الرياض", "مكة المكرمة", "المنطقة الشرقية"],
  "locations": [{ "name": "الرياض" }, { "name": "جدة", "value": "24 ساعة" }],
  "routes": [{ "from": "الرياض", "to": "جدة" }]
}
```

`precomputeMap()` projects once at direction time (per aspect: 9:16 → 1150 px tall map area, 4:5 → 950, 1:1 → 820, 16:9 → 560) into SVG paths, pins and quadratic route arcs (with path length for drawing); the scene only animates precomputed paths, so rendering stays fast and deterministic. Saudi Arabia is drawn from its 13 regions so region highlights line up exactly.

## Scene `map-story`

Variants: `focus` (camera pushes into the country/region), `regions` (regions fill in order with labels), `pins` (cities drop in with values), `route` (routes draw from origin to destination with a moving head). Sound events: `map_pin`, `map_route`, `camera_move`.

Acceptance video 12 (Saudi coverage map, 16:9).


---

# Data Animation & Data Storytelling

Code: `src/data/visualize.ts` (choice + honesty checks), `src/scenes/data/data-story.tsx`, existing data families (`kpi-counter`, `stat-highlight`, `bar-chart`, `line-chart`, `donut-chart`, `progress-bars`, `ranking`, `comparison-table`, `data-table`, `timeline`, `before-after`). Module `data` loads only when the brief has `stats`, `series` or `table`.

## Never fabricate

- Every number comes from the brief; data families require a `source`, which is shown on screen. `example`/`placeholder` sources are critical in validation.
- `checkDataStory()` (validation + director) rejects or warns on: missing source, label/value length mismatch, a part-to-whole that does not sum to ~100, and an **insight that the data does not support** (a percentage that does not match the computed change, or a growth/decline claim the series contradicts).
- Changes are **computed** (`changePct`), never typed in.
- Charts start at zero for bars; line charts never imply a trend the data lacks; the final value holds long enough to read.

## Choosing the visualization by meaning

`chooseVisualization()`:

| Data | Visualization |
|---|---|
| one value | big-number (counter) |
| two values | change (before → after with the computed %) |
| ordered labels (years, quarters, months, Hijri months) | line |
| categories | bar (ranked) |
| parts summing to ~100 | share (donut only when it is part-to-whole) |

## Story structure

`data-story` plays **context → build → insight**: the question/context line, the chart builds in order (escalation, e.g. 120 → 180 → 240 → 340), then the computed insight lands (+183 %) with an annotation and a hold. Numbers use the project's numeral system (Arabic-Indic or Latin) and stay readable on a phone.

Acceptance video 11 (4:5 data film).


---

# Web Animation / GSAP module

GSAP is an **optional** helper for complex staggered UI timelines. Remotion stays the timeline and the renderer.

- Package: `gsap@^3.15.0` as an `optionalDependency` (GSAP's standard "no charge" license; no Club/bonus plugins are used). If the import fails, `loadGsap()` resolves to null: the cards render in their final layout without the stagger and the element is marked `data-qc-gsap="missing"`.
- Loaded **lazily**: `gsap-sequence` calls `import('gsap')` inside `delayRender` only when that scene is in the film. Films without the scene never load the library (verified: module `gsap` is not selected for logo, product or data films — `test/unit/v3-modules.test.ts`).
- **Deterministic**: the GSAP timeline is created `paused`, and each Remotion frame calls `timeline.seek(frame / fps)` — no GSAP ticker, no wall-clock time, so frame N is identical in every render and in the parallel render workers.
- Variants: `stagger-grid` (cards/tiles stagger in from the grid centre), `cascade` (list/feature items cascade with overlap). Elements carry `data-qc-gsap` so QC can find them.
- Selected when `preferences.gsap: true`, or for `web-ui` films (website walkthroughs) unless `preferences.gsap: false`.

Acceptance video 15.
