# Brand system

## With a logo (png, jpg, webp, svg)

1. The file is copied byte-identical into the project (`assets/<hash>-<name>`), SHA-1 verified.
2. `analyzeLogo` reads dimensions, meaningful transparency (>2 % non-opaque pixels), the background colour of boxed logos, and weighted dominant colours (k-means on the opaque pixels, with the box background excluded for non-transparent logos).
3. `derivePalette` builds `brand.json`-style fields: `primary`, `secondary`, `accent`, `background`, `surface`, `textPrimary`, `textSecondary`, `mode` (dark/light), `personality`, `dominantColors`, and `contrastRules` (text ≥ 4.5:1, large text ≥ 3:1). Colours are adjusted in lightness only as much as needed to pass contrast; hue identity is kept.
4. The logo is shown as supplied (`object-fit: contain`, never recoloured, cropped, redrawn or regenerated).

CLI: `npx tsx cli/nitaaq.ts brand path/to/logo.png --name "اسم العلامة"` prints the profile.

## brand.json (written for every project)

`primary`, `secondary`, `accent`, `background`, `surface`, `textPrimary`, `textSecondary`, **`contrastSafeColors`** (for `onBackground`, `onSurface`, `onPrimary`: which brand colours pass WCAG for normal text ≥ 4.5:1 and for large text ≥ 3:1), `contrast` (the key pairs with their measured ratios), `logoAsset` (the untouched file or `null`), `fontPreferences` (Arabic, Latin, whether a user font is used), `visualPersonality`, `motionPersonality`, `style`, `mode`, `dominantColors`, `note`. QC's contrast fix points at `contrastSafeColors`.

## From a reference

With no logo and no colours, a supplied reference provides the colour family (see REFERENCE_SYSTEM.md). A logo or user colours always win over a reference.

## Without a logo

The Director never creates a fake logo. It:

- picks a visual direction (style preset) from tone → industry → wording → audience;
- builds a palette from the user's colours if given (`paletteFromUserColors`, contrast-enforced), otherwise uses the style palette;
- sets the brand **name** in type where a logo would go (`brand-intro` wordmark, `cta-logo` falls back to the name) — or leaves it out if there is no name.

## Fonts

Bundled (local woff2, OFL): IBM Plex Sans Arabic, Noto Sans Arabic, Noto Kufi Arabic, Tajawal, Alexandria, Changa, Cairo, Inter, Manrope, JetBrains Mono, Anton.

User fonts (`brand.font` = a `.ttf/.otf/.woff/.woff2` file): parsed with fontkit and checked for Arabic coverage (core letters, hamza forms, Arabic punctuation) and contextual shaping tables (GSUB init/medi/fina). A font without Arabic support is rejected with `FONT_NOT_ARABIC` for Arabic projects — it is never silently replaced. `brand.font` may also name a bundled font id; unknown names fail with the list of available fonts. At render time a font that fails to load is a critical QC issue (`FONT_LOAD_FAILED`).

## Style overrides

`video.json → style.overrides` accepts partial tokens (palette, typography, surface, motion…). Contrast is re-enforced after overrides.


---

# Brand Motion Guidelines & Logo Animation

Code: `src/brand/brand-motion.ts` (pure), `src/node/brand-motion-store.ts` (persistence), `src/node/logo-structure.ts` (logo analysis), `src/brand/logo-reveal.ts` (LogoRevealRegistry + chooser), `src/scenes/brand/logo-animation.tsx`. Existing: `src/brand/logo-analyzer.ts` (palette from the logo), `docs/BRAND_SYSTEM.md`.

## brand-motion.json

Written for every film that has a brand (logo, colours or a name) to `workspace/brands/<key>/brand-motion.json` and copied into the project folder. The key is the brand name or a hash of the logo bytes — never a user path.

| Field | Meaning |
|---|---|
| `personality` | motion personality the brand moves with (premium, energetic, playful, corporate, cinematic, tech, sport) |
| `easing.headline / ui / product` | physics presets per element class |
| `timing.pace`, `timing.holdSec` | pacing and minimum read hold |
| `textMotion.preferred / avoid` | headline families the brand uses / avoids |
| `transitions.preferred / avoid`, `hardCutShare` | transition language |
| `soundPersonality` | luxury / tech / sport / playful / cinematic / corporate (drives the Sound Director) |
| `logo.reveal`, `logo.history`, `logo.rules` | last reveal, recent reveals, logo rules (never stretch, never recolour, clear space, contrast plate only when needed) |
| `cta.style` | calm / punch / clean |
| `history` | films made, recent headline families and transitions |

Brand colours, contrast-safe text colours, typography, radius, background behaviour and image treatment live in `brand.json` (BRAND_SYSTEM.md) and the style tokens; `brand-motion.json` adds how the brand **moves and sounds**.

**Consistency ≠ identical films**: the second film for a brand inherits personality, easing, sound personality and CTA style (unless the brief overrides them), while `history` penalises the previous logo reveal, headline families and transitions so the new film is related, not a copy. `--dry-run` style calls (`direct({ dryRun: true })`) do not write the store.

## Logo Animation Engine

1. **Analyse** (`analyzeLogoStructure`, cached by file hash): ink mask (alpha, or distance from the border colour), content box, column/row projection gaps → symbol / wordmark split, layout (`icon`, `wordmark`, `icon+wordmark-horizontal`, `icon+wordmark-vertical`, `emblem`), horizontal/vertical symmetry (IoU of the mirrored mask), dominant direction, colour count, negative space, alpha. Written to `logo-structure.json`.
2. **Choose** (`chooseLogoReveal`): score = personality fit + structure fit − history penalty, seeded tie-break; reveals that need structure are only eligible when it exists.
3. **Render** (`logo-animation` scene): every layer is the **same image** clipped, translated or uniformly scaled, ending exactly at identity (scale 1, full opacity, no filter). The logo is never redrawn, recoloured, stretched or distorted; QC checks identity media for distortion.

| Reveal | Needs | Feel |
|---|---|---|
| mask | — | clean wipe in the dominant direction |
| stroke | — | a line traces the silhouette box, then the logo fills in (raster logos have no paths, so the logo itself is never fake-stroked) |
| shape-assembly | — | tiles cut from the same logo image fly into place and lock together |
| scale | — | the logo lands with weight and a tiny settle (uniform scale) |
| spotlight | — | soft light finds the logo on a dark field |
| light-sweep | transparent PNG/SVG | a light band passes across the logo's alpha |
| split-assembly | symmetry ≥ 0.6 | the two mirrored halves slide together |
| typography-reveal | wordmark | the wordmark is revealed in reading direction, block by block of the same image |
| icon-wordmark | 2 separable parts | the symbol arrives first, the wordmark unmasks beside it |
| depth | — | emerges from depth with blur-to-focus (ends sharp) |
| minimal-premium | — | slow fade with a hairline underline |
| energetic | — | hard punch-in with a colour flash and burst lines around it |

Short logo requests («أنيميشن للشعار ٦ ثواني») become a single `logo-animation` scene with the tagline; logos in longer films get a `logo-animation` brand beat or the CTA lockup.

The logo question (asked once when no brand is given):
> هل عندك شعار أو هوية بصرية تبغى نعتمدها في الفيديو؟ إذا عندك أرسل الشعار، وإذا ما عندك أكمل لك بهوية مناسبة للمحتوى.


---

# Reference system

The user can point at something they like (an image, a video, or a website) and the film borrows its **principles**, never its content. Code: `src/reference/analyze.ts`, CLI `npx tsx cli/nitaaq.ts reference <file|url>`.

## Input

`brief.reference = { "path": "ref.png" | "ref.mp4", "url": "https://…", "kind": "image|video|website|ui", "note": "what the user likes" }`

- **image / ui screenshot**: analysed directly.
- **video**: frames sampled with ffmpeg (≈1 fps, up to 12) + motion energy (mean frame difference) + scene-cut rate (ffmpeg scene detection).
- **website**: captured with the bundled headless browser (`src/node/capture.ts`, desktop 1440×900 or mobile 390×844), then analysed as a UI reference. In environments whose network policy blocks outside sites, capture fails with `CAPTURE_FAILED` and the user is asked for a screenshot instead.

## What is measured (per frame, at 256 px)

Dominant palette (k-means), background and accent colour, neutral share, mean luminance (dark/light), contrast, saturation (OKLCH chroma), edge density, whitespace (share of large empty blocks), composition balance (centred / left / right / top / bottom weighted), and whether the reference itself uses a dot/grid pattern (same detector as QC).

## Output: `reference_style.json`

```jsonc
{
  "palette": { "dominant": [...], "background": "#F4EFE6", "accent": "#C8553D", "neutralShare": 0.71 },
  "mode": "light", "contrast": 0.62, "saturation": 0.21, "density": 0.18, "whitespace": 0.82,
  "composition": "right-weighted",
  "motion": null,                     // or { energy, cutsPerSecond, avgShotSec, pacing } for video
  "principles": ["light background with a lot of empty space", "one dominant shape", "quiet, low-saturation colour", …],
  "mapping": { "style": "minimal", "personality": "corporate", "background": "soft-gradient", "pace": "slow", "density": "sparse", "reason": "light, sparse, quiet colour" },
  "notCopied": ["layout", "text", "imagery", "logo", …]
}
```

## How it is applied

- **style** (when the brief has none): rule table → `neon`, `luxury`, `cinematic`, `sports`, `dark-premium`, `tech`, `bold-social`, `editorial`, `minimal`, `light-premium`, `saas`.
- **pace** (when the brief has none) from video pacing or whitespace.
- **motion personality** from the style, or from the measured motion energy when it is extreme.
- **palette** only when the user gave no brand at all (no logo, no colours): the reference colour family, contrast-enforced. A user logo or user colours always win.
- **patterns**: if the reference uses dots/grid, that is listed in `principles` and `notCopied`; it is not enabled unless the user explicitly asks.

Nothing from the reference is copied: no layout, text, image, logo or brand mark. Results are cached by file hash (`.cache/nitaaq-motion/reference`, key `ref-v2`).
