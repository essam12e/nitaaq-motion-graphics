# Motion system

Motion in NITAAQ is planned at film level, then executed per element with physics presets. Every move must have a job; motion without a job is removed.

## 1. AI Creative Director (`src/director/creative.ts`)

Runs after the storyboard and writes its decisions to `motion_spec.json` and `shotlist.json`:

- **One motion personality** for the whole film: explicit `brief.motion` → tone words → style → reference motion energy.
- **A motion job per scene** from its story beat (`hook → stop-the-scroll`, `demo → show-how-it-works / connect-states`, `data → make-the-number-land`, `cta → resolve / direct-action`, …).
- **One hero moment**: the strongest product/solution/brand/demo/offer beat in the middle of the film (never the first or last scene).
- **Escalation curve**: hook 0.8 → build → hero 1.0 → CTA 0.7 (the CTA resolves, it does not shout).
- **Camera budget**: at most `ceil(scenes × activity × 0.6)` camera moves, given to hero, hook and CTA first; scenes marked strict-safe-area never move the camera.
- **Transitions** are chosen by meaning by the Transition Engine (`TRANSITIONS.md`): relationship of the two scenes first, a flashy budget, never the same non-cut type back-to-back.
- **Beat sync** (music, no voice): cut points snap to the nearest beat or downbeat within ±0.18 s when the previous scene can absorb the change (never below its minimum duration). Voice-led films follow the voice, never the beat.
- Deterministic: all choices use a seeded RNG. Same brief + seed = same film.

## 2. Personalities (`src/motion/personality.ts`)

| Personality | Feel | Stagger | Max overshoot | Camera activity / moves | Transitions |
|---|---|---|---|---|---|
| premium | controlled, heavy, deliberate | 0.12 s | 1 % | 0.45 · push, drift | crossfade, light-sweep, blur, wipe |
| energetic | fast, punchy, strong impacts | 0.05 s | 12 % | 0.55 · push, pans | push, zoom-in, speed-ramp, slide |
| playful | springs and bounce | 0.06 s | 35 % | 0.40 · drift, push | zoom-in, push, iris, color-sweep |
| corporate | restrained, precise | 0.08 s | 2 % | 0.20 · drift | push, crossfade, wipe |
| cinematic | depth, camera, reveals | 0.12 s | 2 % | 0.75 · push, pull, drift, rise | crossfade, light-sweep, blur, zoom-out |
| tech | precise, UI-aware micro-interactions | 0.05 s | 6 % | 0.40 · push, drift | mask-wipe, push, zoom-in, crossfade |
| sport | aggressive, impact-based | 0.04 s | 14 % | 0.70 · push, pans | speed-ramp, push, wipe, cut |

## 3. Physics library (`src/motion/physics.ts`)

Twelve presets, measured (overshoot and settle frames at 30 fps are computed, and unit-tested):

| Preset | Drive | stiffness/damping/mass | Overshoot | Settle (frames) | Use |
|---|---|---|---|---|---|
| snappy | spring | 260/26/0.7 | 0 % | 10 | UI and punchy type |
| responsive | spring | 320/30/0.6 | 0 % | 9 | buttons, toggles, cursors |
| soft | curve | 120/24/1 | 0 % | 16 | body copy, secondary info |
| heavy | spring | 110/22/1.6 | 1 % | 16 | dashboards, devices, big panels |
| premium | curve | 90/26/1.3 | 0 % | 22 | luxury reveals |
| playful | spring | 180/11/0.8 | 20 % | 18 | icons, stickers |
| elastic | spring | 140/9/0.8 | 23 % | 26 | pops and badges (sparingly) |
| cinematic | curve | 70/20/1.4 | 0 % | 38 | camera, atmosphere |
| mechanical | curve | 400/40/0.5 | 0 % | 11 | data, tickers |
| sport | spring | 380/18/0.6 | 9 % | 8 | sports and hype |
| corporate | curve | 150/28/1 | 0 % | — | institutional, measured ease-out |
| tech | spring | 300/30/0.7 | 2 % | — | product UI and SaaS, crisp |

Default per element type: button/cursor → responsive · card/icon/notification/hero-title → snappy · text/body → soft · panel/dashboard/device/product → heavy · logo → premium · chart/number → mechanical · camera/background → cinematic. Each personality overrides some of these (e.g. premium makes buttons and icons `soft`; sport makes cards and numbers `sport`).

## 3b. Animation Principles Engine (`src/motion/principles.ts`)

One function, `motionProfile(personality, element, areaFraction)`, decides **how** a thing moves from **what** it is, how big/heavy it looks, and the film's personality. Every scene that animates an element asks it rather than hard-coding easing.

- **Apparent mass** (feather → light → medium → heavy → massive) from the element kind and its on-screen area; heavier = longer (`timeScale` 0.75 → 1.35).
- **Anticipation**: a small counter-move before expressive moves (6–10 % of travel for bouncy personalities, 3 % tech); never on buttons, cursors, charts, numbers, or under premium / corporate / cinematic.
- **Overshoot** bounded by the personality's budget ∩ the preset.
- **Follow-through** (`followThrough`): children lag and settle after their parent; **secondary motion** (`secondaryMotion`): shadows/labels/glows react slightly later.
- **Arcs** (`arcPoint`): organic objects (product, icon, logo, card, notification) travel on arcs; UI travels straight.
- **Squash & stretch** (`squashStretch`): volume-preserving, only for light objects in playful (and slightly in sport) films — never on logos or titles.
- **Sound anchors** (`anchorsOf` / `profileAnchors`): the same motion curve yields `start`, `peak` (peak velocity), `contact`, `settle`, `completion` — the Sound Director syncs to these (`SOUND_DIRECTOR.md`), not to scene start.

The profile's `why` string is written to `motion_spec.json`, so every move documents its reason.

## 4. State-based motion and shared elements

`state-flow` (alias `shared-element`, `journey`) moves one element through the product journey (logo → search → result → product → cart → checkout → success): the same surface morphs size, radius and content between states instead of cutting between unrelated cards. `form-fill`, `workflow`, `order-success`, `browser-scene` and `landing-page` are also state-driven (empty → typed → submitted → done). Across scenes, the same logo / product / screenshot is carried by a measured **shared-element transition** (`TRANSITIONS.md`).

## 5. Seamless loop

`brief.loop: true` → `timeline.seamlessLoop`: the last scene returns to the opening frame state; final QC compares first and last frames (`LOOP_SEAM` if the 64×64 grey difference is above 14).

## 6. QC checks on motion

`HOLD_TOO_SHORT`, `VOICE_DRIFT`, `MOTION_NO_PURPOSE`, `CAMERA_OVERUSE` (> 70 % of scenes), `TRANSITION_MONOTONY`, `TRANSITION_REPEAT`, `TEXT_MOTION_REPEAT`, `TEXT_MOTION_OVERUSED`, `PERSONALITY_MISMATCH`. See `QUALITY.md`.

## 7. Motion Engine 2.0

- **Springs** (`src/motion/spring.ts`): closed-form damped oscillator (under/critical/over-damped), `springFromBounce(bounce, visualDuration)`, settle time, overshoot, `inertiaAt` (throw + decay to a boundary), `momentumAt` (multi-leg). Pure functions of time.
- **Easing** (`src/motion/easing.ts`): cubic-bezier solver, anticipate, back, elastic, bounce, steps, mirror/reverse/blend, named `RATE` table per role.
- **Orchestration** (`src/motion/orchestrate.ts`): stagger (from first/last/centre/edges/random-seeded, with easing over the stagger), keyframe tracks, sequences with overlaps, numeric velocity.
- **Motion Intent System** (`src/motion/intent.ts`): every element gets a role (hero-product, headline, supporting-text, cta, logo, ui, illustration, icon, background, data) and an intent (reveal, emphasis, transition, navigation, transformation, continuity, attention, …) → the motion, its timing and its sound are chosen from the intent, written to `scene.motion.intents`.

## 8. Motion Director 2.0

- **Visual Rhythm Plan** (`src/director/rhythm.ts` → `rhythm_plan.json`): per scene start, length, energy, copy density, the cut into it, camera, beat accents; film checks for monotony (three equal lengths), a repeated cut, hero placement (30–85%), a breath before the hero, readability (≤ 22 characters/s) and contrast (length variation).
- **Motion Language** (same file): the film's vocabulary — personality, easing, entrances, text families, transitions, camera moves, its signature move and its rules — so edits stay in the same language.
- **Anti-Template System** (`src/director/anti-template.ts`, history in `workspace/.history/films.json`): each film's fingerprint (family/variant sequence, cuts, camera, backgrounds, text families, personality) is compared with the last 40 films; above 60% similarity the director varies only non-semantic choices — cuts without a story reason, sibling camera moves, variants with at least the same text capacity — until it drops below. Content, order, timing, brand and product never change. Report: `anti_template.json`. `NITAAQ_NO_ANTI_TEMPLATE=1` turns it off.
- **Camera**: docs/MOTION_SYSTEM.md. **Morphing**: docs/MOTION_SYSTEM.md.


---

# Choreography Engine

A choreography describes a whole moment on one timeline:

> cursor moves → hover → press → the folder compresses → click sound → glass pulse → the folder opens → video cards emerge → the camera pushes in → focus moves to the cards

Without it, each animation is written separately with hand-typed delays. With it, the relationships are stated directly:

- one action follows another;
- this action overlaps that one;
- this action starts when that cue fires.

The engine resolves those relationships into exact times.

It is a layer on top of the existing motion engine, not a second one. `compileChoreo` decides only **when** things happen. The values still come from the existing primitives: `curve`, `springAt`, `staggerDelay` and `trackAt`.

Remotion stays the clock. The compiled choreography is a set of pure functions of time, which a scene evaluates at its own `frame / fps`. Nothing is stored between frames, so the render, stills, `nitaaq seek` and QC agree, and the same JSON always gives the same film.

The engine has three parts:

| File | Role |
|---|---|
| `src/motion/choreography.ts` | Timeline schema, compiler, property tracks, focus handoff, events, camera |
| `src/motion/interaction.ts` | Cursor vocabulary, pointer state, how the target element responds |
| `src/motion/phrases.ts` | Motion Phrases: reveal, interaction and camera |

## The timeline (JSON, zod-validated)

```json
{
  "initial": { "folder.open": 0 },
  "timeline": [
    { "type": "action", "id": "reveal", "target": "folder", "dur": 0.6, "spring": { "bounce": 0.3 }, "props": { "reveal": 1 } },
    { "type": "action", "target": "cursor", "kind": "move", "dur": 0.8, "data": { "to": "folder" }, "at": "-=0.2" },
    { "type": "action", "id": "press", "target": "cursor", "kind": "press", "data": { "target": "folder" } },
    { "type": "par", "children": [
      { "type": "cue", "id": "click" },
      { "type": "action", "target": "folder", "shape": "pulse", "dur": 0.5, "props": { "glow": 1 } }
    ] },
    { "type": "action", "id": "open", "target": "folder", "trigger": "click", "offset": 0.1, "dur": 0.7, "spring": { "bounce": 0.25 }, "props": { "open": 1 }, "event": { "type": "ui_appear" } }
  ]
}
```

### Nodes

| Node | Meaning |
|---|---|
| `action` | A timed move of `target`. `props` gives the values it moves to; `from` gives explicit start values. Timing comes from `dur` with `ease` (a curve name, `linear` or `hold`) or from a `spring`. |
| `wait` | A gap of `dur` seconds. |
| `marker` | A named moment that other nodes can refer to. |
| `cue` | A named moment, optionally with a Sound Director `event`. A `trigger` starts on it. |
| `seq` | Children run one after another. The root is a `seq`. |
| `par` | Children start together. |
| `stagger` | Children start `each` seconds apart, using the motion engine's distribution: `from` first / last / center / edges / reading / an index, plus `ease` and `maxTotal`. |

Ids use letters, digits, `_` and `:` only. A `-` would read as an offset, as in `card-0.2`.

### Placement (any node)

| Field | Example | Start |
|---|---|---|
| default | | after the previous sibling (`seq`), with the container (`par`), on the stagger (`stagger`) |
| `at` number | `2.4` | absolute seconds |
| `at` relative | `"<"`, `">"`, `"<0.2"`, `">-0.1"`, `"+=0.3"`, `"-=0.25"` | with / after the previous sibling, gap or overlap |
| `at` reference | `"press.end+0.06"`, `"open.peak"`, `"click"` | a point of any id, marker or cue in the tree (`start`, `end`, `peak`, `contact`, `settle`) |
| `trigger` | `"click"` | when that cue fires. Forward references work. |
| `follow` | `{ "id": "lead", "lag": 0.1 }` | follow-through: the leader's point plus a lag. An action without its own `dur`, `ease` or `props` inherits the leader's. |
| `handoff` | `{ "from": "open", "at": 0.6 }` | while `from` is still finishing, at that fraction of it. Focus passes from its target to this one. |
| `offset` | `0.1` | added after the placement is resolved |

The compiler refuses three things, each with a clear `ChoreoError`:

- unknown references;
- duplicate ids;
- cycles.

`timeScale` stretches every duration, wait and absolute time. A scene uses it to fit a phrase into its length.

### Property tracks

```
valueAt(c, 'folder.open', t)    targetValues(c, 'folder', t)
```

| `shape` | Behaviour |
|---|---|
| `to` | Moves from the track's current value. A later move interrupts an earlier one without a jump, and a spring inherits the velocity of the move it interrupts. |
| `pulse` | Goes there and back over `dur`, added on top. |
| `kick` | A spring impulse that peaks at the amount and settles by itself. Used for camera accents. |

Rest values: `scale`, `zoom`, `close` and `opacity` are 1; `focusX` and `focusY` are 0.5; everything else is 0, unless `initial` says otherwise.

Queries:

- `phaseOf(c, id, t)`: `before`, `active` or `done`, with eased progress.
- `activeAt(c, t)` and `passedAt(c, t)`: what is running and which markers or cues have passed.
- `focusAt(c, t)`: focus weights after handoffs.

## Interaction choreography (the existing Cursor, extended)

Cursor actions are ordinary actions with `target: "cursor"` and a `kind`:

| kind | data | What happens |
|---|---|---|
| `appear` | `to` | The pointer fades in at `to`. |
| `move` | `to` (element name or `{x, y}` as a fraction of the canvas), `arc` | It travels on a slight arc that is fast at first and decelerates into the target. Arriving on an element starts its hover; moving away ends it. |
| `hover` | `target` | It stays over the element; the element takes its hover state. |
| `press` | `target` | Button down. The element compresses and stays compressed while held. The default event is `button_press`, with its contact at the bottom of the press. |
| `release` | `target` | Button up. The element springs back slightly past rest (a pop) and `released` runs 0 → 1, a state transition. |
| `click` | `target` | Press and release in one action. The press takes 45%, and the contact sits at the bottom of it. |
| `drag` | `target`, `to` | The pointer holds the element and carries it, with a small lag, to `to`, then releases there. The default event is `swipe`. |
| `leave`, `hide` | | It moves off and fades out. |

`elementAt(ix, 'folder', t)` gives the element's response:

- `hover`, 0..1;
- `press`, 0..1 for compression, below 0 for the release pop;
- `click`, 0..1 for the reaction pulse, with `clickAge` in seconds;
- `released`;
- `dragging` and the `drag` offset.

`cursorAt(ix, t, resolve)` gives the pointer:

- its position;
- `visible`;
- `press`;
- `ripple`;
- a `hover` halo;
- `speed`.

Positions are resolved through the scene's own layout, so the same choreography and the same sound events work in every aspect.

`<Cursor keys={…}>` is unchanged. `<Cursor state={cursorAt(…)}>` draws the same pointer with a hover halo and a press that holds while the button is down.

## Sound from the same timeline

The Sound Director reads the choreography's events. They come from the cursor kinds' defaults, from an action's `event`, and from a cue's `event`.

Every event carries **exact anchors** measured from its own timing:

- **start**;
- **peak**, the velocity peak of its curve or spring;
- **contact**: the end of a move, or the bottom of a press;
- **settle**, from the spring;
- **completion**.

So the click lands on the frame where the button bottoms out. `event: false` silences a default.

A scene passes them on with `events: (c, v, d) => compiled.events`.

## Camera choreography

Actions on the `camera` target drive the Camera Engine from the same timeline:

| Property | Effect |
|---|---|
| `focusX` / `focusY` | The subject, as a fraction of the canvas |
| `close` | Framing tightness, where 1 is rest |
| `dolly`, `zoom`, `tilt`, `yaw`, `roll` | Direct channels |

`cameraFromChoreo(c, t, W, H)` maps them with the same constants as a `track` camera plan. `<CameraRig state={…}>` renders them on the rig's depth planes.

A scene uses its timeline's camera only when the scene shell has no `cameraPlan` of its own, so there are never two cameras.

## Motion Phrases

Connected motion replaces the pattern where one element arrives, stops, and then the next one arrives:

| Phrase | Shape |
|---|---|
| `revealPhrase(target)` | anticipation (a small dip) → reveal (spring) → settle → secondary response, which overlaps the end |
| `interactionPhrase({ target, from, response, consequence })` | approach → hover → press → response (from the click) → release → consequence (it starts while the finger is still lifting) → leave / hide |
| `cameraPhrase({ focus, close, passForeground, transferTo })` | establish → accelerate → pass foreground → focus transfer → settle (a kick) |

Each part has an id (`folder_interaction_press`, `camera_phrase_arrive`…), so an edited JSON can move any part.

## Scene family `interaction-flow`

| Variant | Timeline |
|---|---|
| `folder` | The folder reveals. The cursor approaches and hovers, and the folder lifts. A press compresses it. The click brings the sound and a glass pulse. On release the folder opens, video cards emerge in a stagger from the centre, the camera pushes in, and focus hands off from the folder to the cards. |
| `button` | The button reveals → approach → hover → press → click → success state, with a small camera kick. |
| `drag` | The cursor grabs a card and drags it into the folder. The folder takes it with a squash, a glow and a `+1`. |

Content fields:

- `folder`;
- `items` (1–6, each with a `title` and an optional image or video `media`);
- `button` and `success`;
- `from` (where the pointer enters);
- `eyebrow`, `title`, `subtitle` and `caption`;
- `choreography`, an edited timeline that replaces the built-in one. It uses the same element names: `folder`, `cardN`, `button`, `cursor`, `camera` and `cards`.

The natural timeline is compressed to fit a short scene, never stretched. The folder here is a simple flat folder. The glass portfolio folder is a later phase.

## Seek

For a choreographed scene, `nitaaq seek` reports a `choreography` entry with:

- the timeline time;
- the running actions;
- passed markers and cues;
- the cursor action, with `visible`, `press` and `hover`;
- each element's hover, press, click and released values;
- focus weights;
- the timeline's camera state.

## Limits (honest)

- The Director does not pick `interaction-flow` on its own yet; it is used when a film or edit names it. Motion Phrases inside the Director's planning come in a later phase.
- Overlapping `to` moves on the same property hand over (the later one takes over from the current value). There is no additive blending of two `to` moves.
- A `drag` carries one element at a time.


---

# Cinematic Camera 2.0 (2.5D, depth, parallax)

A real 2.5D camera over depth planes, with the same maths as CSS 3D, so what the QA measures is what renders.

| File | Role |
|---|---|
| `src/camera/rig.ts` | camera state (x, y, dolly, zoom, tilt, yaw, roll, focus, aperture), `project` / `projectRect`, `unproject` (Newton) / `unprojectRect`, clearance (a plane must never reach the lens), depth of field |
| `src/camera/moves.ts` | 22 named moves (`push-in`, `pull-out`, `dolly-*`, `truck-*`, `pan-*`, `tilt-*`, `pedestal-*`, `orbit-*`, `arc`, `crane-up`, `zoom-*`, `rack-focus`, `track`, `drift`, `static`) → `cameraAt(plan, t)`; waypoints; beat accents; `peakSpeed` |
| `src/camera/CameraRig.tsx` | `<CameraRig plan>` (perspective + world transform) and `<DepthLayer plane>`; outside an active rig a DepthLayer is a plain fill, so old films render exactly as before |
| `src/camera/director.ts` | `planCamera()` — which move serves this subject (see below) |
| `src/camera/framing.ts` | `auditFraming` / `solveFraming` — protected elements (text, product, logo, CTA) must stay inside the safe area for the whole move |

## Depth planes

Perspective `D = hypot(W, H) × 1.25`. Planes (fraction of D): foreground −0.32, midground −0.12, **hero 0** (authored layout is exact), background 0.7, atmosphere 1.6. Each layer keeps its rest size (`translateZ(−dD) scale(1 + d)`), so only the camera moves things: near planes move more (true parallax).

The scene background sits on the background plane, overscanned 12.5% a side about the centre (orbits/arcs move the far plane by up to ~11%; measured, see `test/unit/motion2b.test.ts`).

## Which move (camera director)

| Subject | Move |
|---|---|
| hero product | orbit-left / arc / push-in (+ depth of field for premium/cinematic) |
| logo / brand | crane-up (push-in when restrained) |
| CTA | pull-out |
| UI | truck-left in RTL films, truck-right in LTR |
| data | pedestal-up |
| headline | push-in or drift |

Corporate never orbits, arcs or cranes. Amplitude per personality: premium .8, cinematic 1, corporate .6, tech .85, playful .9, energetic 1.05, sport 1.1 (×0.85 off the hero). Music-led films (not premium/corporate) add up to 3 downbeat accents per scene.

`scene.motion.cameraPlan` is plain JSON (move, amplitude, ease, focus, accents, waypoints, dof, reason) — editable by hand; the legacy `scene.motion.camera` name still works.

## QA

Visual QA 2.0 unprojects every measured element back to its rest position and audits the whole move (30 samples). A violation becomes `CAMERA_FRAMING` with the repair `camera-solve`: apply the solved plan (smaller amplitude / moved focus), else halve the amplitude.


---

# Advanced Morphing

True path morphing (not a crossfade), reimplemented from the published ideas of flubber / Manim's `Transform` — no code copied, no dependency added.

| File | Role |
|---|---|
| `src/morph/path.ts` | SVG path parser (all commands → cubic segments), arc-length `resample`, `alignRing` (rotation + winding that minimises travel), `prepareMorph` (sub-path matching: biggest bodies pair; extra sub-paths shrink into / grow from the nearest body), `morphAt(plan, t, arc)` (`arc` bends travel around the common centre, like Manim's `path_arc`), `midSilhouetteOk` |
| `src/morph/shapes.ts` | `shapePath` (circle, squircle, hexagon, star, blob…), `blobPath` (seeded organic body), `iconPath` (any Lucide icon as one path; every element's leading relative `m` is anchored, so joined elements stay in place) |
| `src/morph/trace.ts` | `traceContours` / `silhouettePath` — an image's alpha → its outline path |
| `src/morph/useSilhouette.ts` | browser hook: traces a logo/product silhouette (delayRender, cached) |
| `src/morph/Morph.tsx` | `<MorphShape stages>` (spring-timed stages), `<MorphMask>`, `<LiquidBlob>` |

## Where it is used

- `morph-story` scene family: one body becomes each step (icons as line art, or filled shapes), caption per stage.
- Logo reveal `liquid-morph`: a breathing blob springs into the logo's traced silhouette, then the real logo fades in — the settled frame is always the untouched logo (needs a logo with transparency).
- Transitions `morph` / `shape-match` / `liquid` (Transition Intelligence).
- Background kind `liquid` (two large organic bodies breathing slowly).

All of it is a pure function of the frame (deterministic seek).


---

# Scene Transition Engine & Shared Elements

Code: `src/transitions/presentations.ts` (TransitionRegistry, 30 presentations), `src/transitions/engine.ts` (`chooseTransitions`), `src/node/shared-rects.ts`, `src/engine/VideoComposition.tsx` (`SharedLayer`).

## Registry

Every transition declares what it **means** (continuity, reveal, energy, calm, contrast, space, ui, brand, time), its energy, and its visual **peak** (0..1 of the window — the Sound Director syncs the transition sound there).

`cut, none, crossfade, fade, slide, push, wipe, mask-wipe, zoom-in, zoom-out, blur, iris, light-sweep, speed-ramp, flip, color-sweep, match-cut, shared, morph, camera-push, camera-pull, whip, depth, shape, text-sweep, object-sweep, color-dip, perspective, page, split`

## How a transition is chosen

`chooseTransitions()` looks at each cut, in order:

1. **Relationship of the two scenes**, first match wins: same identity asset on both sides → `shared`; a cut on a musical beat in a rhythmic film → hard cut; into the hero / a reveal → the personality's reveal family (premium: light-sweep / camera-push / morph …); problem → solution, bridge, tease → the personality's contrast family; montage → mostly hard cuts (whip / speed-ramp sometimes); UI → UI → `page` / `push` / `match-cut`; same kind of content → mostly hard cuts; into the CTA → calm arrival (a cut after an energetic run); product reveal in energetic/playful/sport films → `object-sweep`; kinetic/launch films → one `text-sweep` carried by the next word; otherwise the personality's calm family or a cut.
2. **Meaning first, decoration never** — a cut on a musical beat is a hard cut; same-kind content cuts hard most of the time; "nothing to express" is a hard cut. A **flashy budget** (25 % of cuts for premium/corporate, 40 % otherwise) turns extra flashy picks into cuts, and rhythmic (energetic / launch / music) films keep at least 25 % hard cuts.
3. **Variety** — any one non-cut type is capped at a third of the cuts and is never used back-to-back.
4. **Style family** — the style preset's preferred transitions break ties inside a meaning.

The choice and its reason are written into `video.json` (`scenes[i].transition.reason`) and `shotlist.json`.

Motion QC: `TRANSITION_REPEAT` (back-to-back), `TRANSITION_MONOTONY` (> 50 % of cuts one type).

## Shared-element transitions

When two consecutive scenes show the same logo / product / phone / browser screenshot, the director plans a `shared` transition (`timeline.shared[]`). Before rendering, `produce` measures the asset with the DOM probe — where it really sits in the outgoing scene at the first frame of the transition and in the incoming scene at its last frame — and stores `fromRect` / `toRect`. During the window the film-level `SharedLayer` draws **one** copy that glides on an arc (products) or a straight path (UI/logos) with heavy physics and **uniform** size interpolation (`object-fit: contain`, never stretched), while both scenes hide their own copy (`useSharedHidden`). Pairs that cannot be measured (the asset is off-screen at one edge) keep a normal transition — nothing is guessed. Measurements are cached like QC probes.

Supported kinds in the schema: logo, product, phone, browser, card, text, shape, icon, chart, screenshot (identity media is what is measured today; text/shape continuity is done inside state-driven scenes such as `state-flow`).

## Transition Intelligence 2.0 (`src/transitions/continuity.ts`)

Reads how scene A ends and scene B begins and upgrades a plain cut to a continuity device when one exists: A's subject shape becomes B's frame (morph / shape-match), both scenes share a colour (color-match), A ends on a lateral camera move (camera-match), A's subject travels toward the next idea (motion-match), B is the hero reveal (zoom-through / liquid). It never overrides a shared-element transition, a beat cut, or the rhythm floor of energetic films, and rations itself to ≤ 40% of cuts. Each upgrade states its reason in `transition.reason` and carries its hints (focus, rect, shape, colour). Continuity transitions get silent or soft sound.


---

# Text Motion Engine & Arabic Kinetic Typography

Code: `src/text-motion/families.ts` (registry), `src/text-motion/planner.ts` (film-level plan), `src/typography/Text.tsx` (renderer), `src/scenes/kinetic/` (kinetic scene families).

## Families (27, `TextMotionRegistry`)

Each family declares its unit for Latin text and the unit it falls back to for Arabic, the roles it suits, energy, duration, stagger, direction and curve.

| Family | Latin unit | Arabic unit | Typical role |
|---|---|---|---|
| mask-reveal, line-reveal, split-reveal, wipe-reveal, perspective-reveal, editorial-title, underline-draw | line | line | headline / support |
| word-stagger, scale-impact, blur-reveal, vertical-reveal, horizontal-reveal, slide-reveal, rotation-reveal, compress-expand, word-replace, number-count, marker-highlight, background-highlight, phrase-emphasis, controlled-bounce, typography-punch, follow-through, kinetic-sequence | word | word | headline / CTA / number |
| char-stagger | char | **word** | Latin headline only |
| tracking-reveal, cinematic-title | block | block | premium titles / labels |

Granularity supported by the renderer: block, line, word, character (Latin only), phrase / highlighted phrase (`emphasis` words), number (count-up with the project's numeral system), and **Arabic word groups** (a particle glued to the next word — و، ف، ب، ل، ال… — animates with it).

## Arabic rules (enforced in code and QC)

- No per-glyph animation on Arabic: `effectiveUnit()` never returns `char` for Arabic text; QC flags `ARABIC_SPLIT_GLYPHS` (critical) if a single Arabic letter ever ends up in its own span.
- No letter-spacing on Arabic (`ARABIC_LETTER_SPACING`): `tracking-reveal` uses **word-spacing** for Arabic, letter-spacing only for Latin, and never widens past the fitted width.
- RTL base direction per line; Latin runs and numbers are isolated inside RTL lines (mixed Arabic + English + numbers). Directional families (`slide`, `horizontal`, `wipe`, `follow-through`, `rotation`) mirror for RTL.
- Masks, clip-paths and line segmentation are used where a Latin design would split characters.
- Line breaking is Arabic-aware (`fitText`) and re-runs per aspect; the text fitter reports overflow instead of clipping.

## Film-level plan

`planTextMotion(scenes, personality, seed)` assigns per scene a family for each role group (headline / support / CTA / number / label):

- headline families come from the personality's palette (`HEADLINE_FAMILIES`), weighted by beat (hook → impact families, data → number-count, CTA → punch/scale), **never the same headline family in two consecutive scenes**, with a usage cap per film;
- the brand's `brand-motion.json` preferred / avoided families bias the choice (consistency across films without identical films);
- the plan is written to `motion_spec.json` and to each scene's `motion.text`.

Motion QC (`src/qc/audio-qc.ts → motionVarietyQc`) reports `TEXT_MOTION_REPEAT` and `TEXT_MOTION_OVERUSED`.

## Kinetic typography scenes

`kinetic-sequence` (rhythm / impact / build), `kinetic-stack`, `kinetic-number`, `kinetic-mixed` (Arabic + English), `kinetic-replace` (word replacement). `content.lines` in the brief is a kinetic script; the director keeps lines in order and uses word groups as units.

## Tests

`test/unit/v3-modules.test.ts` (Arabic never per glyph, English per char allowed, no back-to-back headline family, ≥26 families), `test/unit/arabic.test.ts`, visual baselines in `test/visual/baseline/`.

## Arabic Kinetic Typography 2.0

- **Joining-safe letter groups** (`joiningClusters` in `src/typography/arabic.ts`): a word is split only where the right letter does not join forward (ا د ذ ر ز و ة ى …) or next to a non-joining character; diacritics stay with their letter; lam-alef is never split. مواعيدك → مو · ا · عيد · ك. Each group animates on its own and the word still joins correctly.
- **Kashida** (`kashida(word, n)`): tatweel inserted only at a legal joined connection (بشرتك → بشرتــك), used as a stretch on the key word; the fitter reserves the stretched width.
- **Families** (Arabic copy only): `ar-cluster-rise`, `ar-cluster-cascade`, `ar-cluster-drop`, `ar-fill-sweep` (ghost → ink in reading direction), `ar-ink-sweep` (feathered line wipe), `ar-weight-settle`, `ar-kashida-stretch` (needs a highlight). The planner puts them first for Arabic headlines, support lines and CTAs.
- **QC**: `ARABIC_SPLIT_GLYPHS` now tests real joins in the DOM (two adjacent text nodes on one line whose letters connect) instead of flagging every single-letter span.
- Scene family `kinetic-arabic` (stack / hero-word / rise) shows all of it.
