# Motion system

Motion in NITAAQ is planned at film level, then executed per element with physics presets. Every move must have a job; motion without a job is removed.

## 1. AI Creative Director (`src/director/creative.ts`)

Runs after the storyboard and writes its decisions to `motion_spec.json` and `shotlist.json`:

- **One motion personality** for the whole film: explicit `brief.motion` → tone words → style → reference motion energy.
- **A motion job per scene** from its story beat (`hook → stop-the-scroll`, `demo → show-how-it-works / connect-states`, `data → make-the-number-land`, `cta → resolve / direct-action`, …).
- **One hero moment**: the strongest product/solution/brand/demo/offer beat in the middle of the film (never the first or last scene).
- **Escalation curve**: hook 0.8 → build → hero 1.0 → CTA 0.7 (the CTA resolves, it does not shout).
- **Camera budget**: at most `ceil(scenes × activity × 0.6)` camera moves, given to hero, hook and CTA first; scenes marked strict-safe-area never move the camera.
- **Transitions** are chosen by meaning by the Transition Engine (`TRANSITIONS.md`): relationship of the two scenes first, a flashy budget, never the same non-cut type back-to-back.
- **Beat sync** (music, no voice): cut points snap to the nearest beat or downbeat within ±0.18 s when the previous scene can absorb the change (never below its minimum duration). Voice-led films follow the voice, never the beat.
- Deterministic: all choices use a seeded RNG. Same brief + seed = same film.

## 2. Personalities (`src/motion/personality.ts`)

| Personality | Feel | Stagger | Max overshoot | Camera activity / moves | Transitions |
|---|---|---|---|---|---|
| premium | controlled, heavy, deliberate | 0.12 s | 1 % | 0.45 · push, drift | crossfade, light-sweep, blur, wipe |
| energetic | fast, punchy, strong impacts | 0.05 s | 12 % | 0.55 · push, pans | push, zoom-in, speed-ramp, slide |
| playful | springs and bounce | 0.06 s | 35 % | 0.40 · drift, push | zoom-in, push, iris, color-sweep |
| corporate | restrained, precise | 0.08 s | 2 % | 0.20 · drift | push, crossfade, wipe |
| cinematic | depth, camera, reveals | 0.12 s | 2 % | 0.75 · push, pull, drift, rise | crossfade, light-sweep, blur, zoom-out |
| tech | precise, UI-aware micro-interactions | 0.05 s | 6 % | 0.40 · push, drift | mask-wipe, push, zoom-in, crossfade |
| sport | aggressive, impact-based | 0.04 s | 14 % | 0.70 · push, pans | speed-ramp, push, wipe, cut |

## 3. Physics library (`src/motion/physics.ts`)

Twelve presets, measured (overshoot and settle frames at 30 fps are computed, and unit-tested):

| Preset | Drive | stiffness/damping/mass | Overshoot | Settle (frames) | Use |
|---|---|---|---|---|---|
| snappy | spring | 260/26/0.7 | 0 % | 10 | UI and punchy type |
| responsive | spring | 320/30/0.6 | 0 % | 9 | buttons, toggles, cursors |
| soft | curve | 120/24/1 | 0 % | 16 | body copy, secondary info |
| heavy | spring | 110/22/1.6 | 1 % | 16 | dashboards, devices, big panels |
| premium | curve | 90/26/1.3 | 0 % | 22 | luxury reveals |
| playful | spring | 180/11/0.8 | 20 % | 18 | icons, stickers |
| elastic | spring | 140/9/0.8 | 23 % | 26 | pops and badges (sparingly) |
| cinematic | curve | 70/20/1.4 | 0 % | 38 | camera, atmosphere |
| mechanical | curve | 400/40/0.5 | 0 % | 11 | data, tickers |
| sport | spring | 380/18/0.6 | 9 % | 8 | sports and hype |
| corporate | curve | 150/28/1 | 0 % | — | institutional, measured ease-out |
| tech | spring | 300/30/0.7 | 2 % | — | product UI and SaaS, crisp |

Default per element type: button/cursor → responsive · card/icon/notification/hero-title → snappy · text/body → soft · panel/dashboard/device/product → heavy · logo → premium · chart/number → mechanical · camera/background → cinematic. Each personality overrides some of these (e.g. premium makes buttons and icons `soft`; sport makes cards and numbers `sport`).

## 3b. Animation Principles Engine (`src/motion/principles.ts`)

One function, `motionProfile(personality, element, areaFraction)`, decides **how** a thing moves from **what** it is, how big/heavy it looks, and the film's personality. Every scene that animates an element asks it rather than hard-coding easing.

- **Apparent mass** (feather → light → medium → heavy → massive) from the element kind and its on-screen area; heavier = longer (`timeScale` 0.75 → 1.35).
- **Anticipation**: a small counter-move before expressive moves (6–10 % of travel for bouncy personalities, 3 % tech); never on buttons, cursors, charts, numbers, or under premium / corporate / cinematic.
- **Overshoot** bounded by the personality's budget ∩ the preset.
- **Follow-through** (`followThrough`): children lag and settle after their parent; **secondary motion** (`secondaryMotion`): shadows/labels/glows react slightly later.
- **Arcs** (`arcPoint`): organic objects (product, icon, logo, card, notification) travel on arcs; UI travels straight.
- **Squash & stretch** (`squashStretch`): volume-preserving, only for light objects in playful (and slightly in sport) films — never on logos or titles.
- **Sound anchors** (`anchorsOf` / `profileAnchors`): the same motion curve yields `start`, `peak` (peak velocity), `contact`, `settle`, `completion` — the Sound Director syncs to these (`SOUND_DIRECTOR.md`), not to scene start.

The profile's `why` string is written to `motion_spec.json`, so every move documents its reason.

## 4. State-based motion and shared elements

`state-flow` (alias `shared-element`, `journey`) moves one element through the product journey (logo → search → result → product → cart → checkout → success): the same surface morphs size, radius and content between states instead of cutting between unrelated cards. `form-fill`, `workflow`, `order-success`, `browser-scene` and `landing-page` are also state-driven (empty → typed → submitted → done). Across scenes, the same logo / product / screenshot is carried by a measured **shared-element transition** (`TRANSITIONS.md`).

## 5. Seamless loop

`brief.loop: true` → `timeline.seamlessLoop`: the last scene returns to the opening frame state; final QC compares first and last frames (`LOOP_SEAM` if the 64×64 grey difference is above 14).

## 6. QC checks on motion

`HOLD_TOO_SHORT`, `VOICE_DRIFT`, `MOTION_NO_PURPOSE`, `CAMERA_OVERUSE` (> 70 % of scenes), `TRANSITION_MONOTONY`, `TRANSITION_REPEAT`, `TEXT_MOTION_REPEAT`, `TEXT_MOTION_OVERUSED`, `PERSONALITY_MISMATCH`. See `QUALITY.md`.

## 7. Motion Engine 2.0

- **Springs** (`src/motion/spring.ts`): closed-form damped oscillator (under/critical/over-damped), `springFromBounce(bounce, visualDuration)`, settle time, overshoot, `inertiaAt` (throw + decay to a boundary), `momentumAt` (multi-leg). Pure functions of time.
- **Easing** (`src/motion/easing.ts`): cubic-bezier solver, anticipate, back, elastic, bounce, steps, mirror/reverse/blend, named `RATE` table per role.
- **Orchestration** (`src/motion/orchestrate.ts`): stagger (from first/last/centre/edges/random-seeded, with easing over the stagger), keyframe tracks, sequences with overlaps, numeric velocity.
- **Motion Intent System** (`src/motion/intent.ts`): every element gets a role (hero-product, headline, supporting-text, cta, logo, ui, illustration, icon, background, data) and an intent (reveal, emphasis, transition, navigation, transformation, continuity, attention, …) → the motion, its timing and its sound are chosen from the intent, written to `scene.motion.intents`.

## 8. Motion Director 2.0

- **Visual Rhythm Plan** (`src/director/rhythm.ts` → `rhythm_plan.json`): per scene start, length, energy, copy density, the cut into it, camera, beat accents; film checks for monotony (three equal lengths), a repeated cut, hero placement (30–85%), a breath before the hero, readability (≤ 22 characters/s) and contrast (length variation).
- **Motion Language** (same file): the film's vocabulary — personality, easing, entrances, text families, transitions, camera moves, its signature move and its rules — so edits stay in the same language.
- **Anti-Template System** (`src/director/anti-template.ts`, history in `workspace/.history/films.json`): each film's fingerprint (family/variant sequence, cuts, camera, backgrounds, text families, personality) is compared with the last 40 films; above 60% similarity the director varies only non-semantic choices — cuts without a story reason, sibling camera moves, variants with at least the same text capacity — until it drops below. Content, order, timing, brand and product never change. Report: `anti_template.json`. `NITAAQ_NO_ANTI_TEMPLATE=1` turns it off.
- **Camera**: docs/MOTION_SYSTEM.md. **Morphing**: docs/MOTION_SYSTEM.md.


---

# Cinematic Camera 2.0 (2.5D, depth, parallax)

A real 2.5D camera over depth planes, with the same maths as CSS 3D, so what the QA measures is what renders.

| File | Role |
|---|---|
| `src/camera/rig.ts` | camera state (x, y, dolly, zoom, tilt, yaw, roll, focus, aperture), `project` / `projectRect`, `unproject` (Newton) / `unprojectRect`, clearance (a plane must never reach the lens), depth of field |
| `src/camera/moves.ts` | 22 named moves (`push-in`, `pull-out`, `dolly-*`, `truck-*`, `pan-*`, `tilt-*`, `pedestal-*`, `orbit-*`, `arc`, `crane-up`, `zoom-*`, `rack-focus`, `track`, `drift`, `static`) → `cameraAt(plan, t)`; waypoints; beat accents; `peakSpeed` |
| `src/camera/CameraRig.tsx` | `<CameraRig plan>` (perspective + world transform) and `<DepthLayer plane>`; outside an active rig a DepthLayer is a plain fill, so old films render exactly as before |
| `src/camera/director.ts` | `planCamera()` — which move serves this subject (see below) |
| `src/camera/framing.ts` | `auditFraming` / `solveFraming` — protected elements (text, product, logo, CTA) must stay inside the safe area for the whole move |

## Depth planes

Perspective `D = hypot(W, H) × 1.25`. Planes (fraction of D): foreground −0.32, midground −0.12, **hero 0** (authored layout is exact), background 0.7, atmosphere 1.6. Each layer keeps its rest size (`translateZ(−dD) scale(1 + d)`), so only the camera moves things: near planes move more (true parallax).

The scene background sits on the background plane, overscanned 12.5% a side about the centre (orbits/arcs move the far plane by up to ~11%; measured, see `test/unit/motion2b.test.ts`).

## Which move (camera director)

| Subject | Move |
|---|---|
| hero product | orbit-left / arc / push-in (+ depth of field for premium/cinematic) |
| logo / brand | crane-up (push-in when restrained) |
| CTA | pull-out |
| UI | truck-left in RTL films, truck-right in LTR |
| data | pedestal-up |
| headline | push-in or drift |

Corporate never orbits, arcs or cranes. Amplitude per personality: premium .8, cinematic 1, corporate .6, tech .85, playful .9, energetic 1.05, sport 1.1 (×0.85 off the hero). Music-led films (not premium/corporate) add up to 3 downbeat accents per scene.

`scene.motion.cameraPlan` is plain JSON (move, amplitude, ease, focus, accents, waypoints, dof, reason) — editable by hand; the legacy `scene.motion.camera` name still works.

## QA

Visual QA 2.0 unprojects every measured element back to its rest position and audits the whole move (30 samples). A violation becomes `CAMERA_FRAMING` with the repair `camera-solve`: apply the solved plan (smaller amplitude / moved focus), else halve the amplitude.


---

# Advanced Morphing

True path morphing (not a crossfade), reimplemented from the published ideas of flubber / Manim's `Transform` — no code copied, no dependency added.

| File | Role |
|---|---|
| `src/morph/path.ts` | SVG path parser (all commands → cubic segments), arc-length `resample`, `alignRing` (rotation + winding that minimises travel), `prepareMorph` (sub-path matching: biggest bodies pair; extra sub-paths shrink into / grow from the nearest body), `morphAt(plan, t, arc)` (`arc` bends travel around the common centre, like Manim's `path_arc`), `midSilhouetteOk` |
| `src/morph/shapes.ts` | `shapePath` (circle, squircle, hexagon, star, blob…), `blobPath` (seeded organic body), `iconPath` (any Lucide icon as one path; every element's leading relative `m` is anchored, so joined elements stay in place) |
| `src/morph/trace.ts` | `traceContours` / `silhouettePath` — an image's alpha → its outline path |
| `src/morph/useSilhouette.ts` | browser hook: traces a logo/product silhouette (delayRender, cached) |
| `src/morph/Morph.tsx` | `<MorphShape stages>` (spring-timed stages), `<MorphMask>`, `<LiquidBlob>` |

## Where it is used

- `morph-story` scene family: one body becomes each step (icons as line art, or filled shapes), caption per stage.
- Logo reveal `liquid-morph`: a breathing blob springs into the logo's traced silhouette, then the real logo fades in — the settled frame is always the untouched logo (needs a logo with transparency).
- Transitions `morph` / `shape-match` / `liquid` (Transition Intelligence).
- Background kind `liquid` (two large organic bodies breathing slowly).

All of it is a pure function of the frame (deterministic seek).


---

# Scene Transition Engine & Shared Elements

Code: `src/transitions/presentations.ts` (TransitionRegistry, 30 presentations), `src/transitions/engine.ts` (`chooseTransitions`), `src/node/shared-rects.ts`, `src/engine/VideoComposition.tsx` (`SharedLayer`).

## Registry

Every transition declares what it **means** (continuity, reveal, energy, calm, contrast, space, ui, brand, time), its energy, and its visual **peak** (0..1 of the window — the Sound Director syncs the transition sound there).

`cut, none, crossfade, fade, slide, push, wipe, mask-wipe, zoom-in, zoom-out, blur, iris, light-sweep, speed-ramp, flip, color-sweep, match-cut, shared, morph, camera-push, camera-pull, whip, depth, shape, text-sweep, object-sweep, color-dip, perspective, page, split`

## How a transition is chosen

`chooseTransitions()` looks at each cut, in order:

1. **Relationship of the two scenes**, first match wins: same identity asset on both sides → `shared`; a cut on a musical beat in a rhythmic film → hard cut; into the hero / a reveal → the personality's reveal family (premium: light-sweep / camera-push / morph …); problem → solution, bridge, tease → the personality's contrast family; montage → mostly hard cuts (whip / speed-ramp sometimes); UI → UI → `page` / `push` / `match-cut`; same kind of content → mostly hard cuts; into the CTA → calm arrival (a cut after an energetic run); product reveal in energetic/playful/sport films → `object-sweep`; kinetic/launch films → one `text-sweep` carried by the next word; otherwise the personality's calm family or a cut.
2. **Meaning first, decoration never** — a cut on a musical beat is a hard cut; same-kind content cuts hard most of the time; "nothing to express" is a hard cut. A **flashy budget** (25 % of cuts for premium/corporate, 40 % otherwise) turns extra flashy picks into cuts, and rhythmic (energetic / launch / music) films keep at least 25 % hard cuts.
3. **Variety** — any one non-cut type is capped at a third of the cuts and is never used back-to-back.
4. **Style family** — the style preset's preferred transitions break ties inside a meaning.

The choice and its reason are written into `video.json` (`scenes[i].transition.reason`) and `shotlist.json`.

Motion QC: `TRANSITION_REPEAT` (back-to-back), `TRANSITION_MONOTONY` (> 50 % of cuts one type).

## Shared-element transitions

When two consecutive scenes show the same logo / product / phone / browser screenshot, the director plans a `shared` transition (`timeline.shared[]`). Before rendering, `produce` measures the asset with the DOM probe — where it really sits in the outgoing scene at the first frame of the transition and in the incoming scene at its last frame — and stores `fromRect` / `toRect`. During the window the film-level `SharedLayer` draws **one** copy that glides on an arc (products) or a straight path (UI/logos) with heavy physics and **uniform** size interpolation (`object-fit: contain`, never stretched), while both scenes hide their own copy (`useSharedHidden`). Pairs that cannot be measured (the asset is off-screen at one edge) keep a normal transition — nothing is guessed. Measurements are cached like QC probes.

Supported kinds in the schema: logo, product, phone, browser, card, text, shape, icon, chart, screenshot (identity media is what is measured today; text/shape continuity is done inside state-driven scenes such as `state-flow`).

## Transition Intelligence 2.0 (`src/transitions/continuity.ts`)

Reads how scene A ends and scene B begins and upgrades a plain cut to a continuity device when one exists: A's subject shape becomes B's frame (morph / shape-match), both scenes share a colour (color-match), A ends on a lateral camera move (camera-match), A's subject travels toward the next idea (motion-match), B is the hero reveal (zoom-through / liquid). It never overrides a shared-element transition, a beat cut, or the rhythm floor of energetic films, and rations itself to ≤ 40% of cuts. Each upgrade states its reason in `transition.reason` and carries its hints (focus, rect, shape, colour). Continuity transitions get silent or soft sound.


---

# Text Motion Engine & Arabic Kinetic Typography

Code: `src/text-motion/families.ts` (registry), `src/text-motion/planner.ts` (film-level plan), `src/typography/Text.tsx` (renderer), `src/scenes/kinetic/` (kinetic scene families).

## Families (27, `TextMotionRegistry`)

Each family declares its unit for Latin text and the unit it falls back to for Arabic, the roles it suits, energy, duration, stagger, direction and curve.

| Family | Latin unit | Arabic unit | Typical role |
|---|---|---|---|
| mask-reveal, line-reveal, split-reveal, wipe-reveal, perspective-reveal, editorial-title, underline-draw | line | line | headline / support |
| word-stagger, scale-impact, blur-reveal, vertical-reveal, horizontal-reveal, slide-reveal, rotation-reveal, compress-expand, word-replace, number-count, marker-highlight, background-highlight, phrase-emphasis, controlled-bounce, typography-punch, follow-through, kinetic-sequence | word | word | headline / CTA / number |
| char-stagger | char | **word** | Latin headline only |
| tracking-reveal, cinematic-title | block | block | premium titles / labels |

Granularity supported by the renderer: block, line, word, character (Latin only), phrase / highlighted phrase (`emphasis` words), number (count-up with the project's numeral system), and **Arabic word groups** (a particle glued to the next word — و، ف، ب، ل، ال… — animates with it).

## Arabic rules (enforced in code and QC)

- No per-glyph animation on Arabic: `effectiveUnit()` never returns `char` for Arabic text; QC flags `ARABIC_SPLIT_GLYPHS` (critical) if a single Arabic letter ever ends up in its own span.
- No letter-spacing on Arabic (`ARABIC_LETTER_SPACING`): `tracking-reveal` uses **word-spacing** for Arabic, letter-spacing only for Latin, and never widens past the fitted width.
- RTL base direction per line; Latin runs and numbers are isolated inside RTL lines (mixed Arabic + English + numbers). Directional families (`slide`, `horizontal`, `wipe`, `follow-through`, `rotation`) mirror for RTL.
- Masks, clip-paths and line segmentation are used where a Latin design would split characters.
- Line breaking is Arabic-aware (`fitText`) and re-runs per aspect; the text fitter reports overflow instead of clipping.

## Film-level plan

`planTextMotion(scenes, personality, seed)` assigns per scene a family for each role group (headline / support / CTA / number / label):

- headline families come from the personality's palette (`HEADLINE_FAMILIES`), weighted by beat (hook → impact families, data → number-count, CTA → punch/scale), **never the same headline family in two consecutive scenes**, with a usage cap per film;
- the brand's `brand-motion.json` preferred / avoided families bias the choice (consistency across films without identical films);
- the plan is written to `motion_spec.json` and to each scene's `motion.text`.

Motion QC (`src/qc/audio-qc.ts → motionVarietyQc`) reports `TEXT_MOTION_REPEAT` and `TEXT_MOTION_OVERUSED`.

## Kinetic typography scenes

`kinetic-sequence` (rhythm / impact / build), `kinetic-stack`, `kinetic-number`, `kinetic-mixed` (Arabic + English), `kinetic-replace` (word replacement). `content.lines` in the brief is a kinetic script; the director keeps lines in order and uses word groups as units.

## Tests

`test/unit/v3-modules.test.ts` (Arabic never per glyph, English per char allowed, no back-to-back headline family, ≥26 families), `test/unit/arabic.test.ts`, visual baselines in `test/visual/baseline/`.

## Arabic Kinetic Typography 2.0

- **Joining-safe letter groups** (`joiningClusters` in `src/typography/arabic.ts`): a word is split only where the right letter does not join forward (ا د ذ ر ز و ة ى …) or next to a non-joining character; diacritics stay with their letter; lam-alef is never split. مواعيدك → مو · ا · عيد · ك. Each group animates on its own and the word still joins correctly.
- **Kashida** (`kashida(word, n)`): tatweel inserted only at a legal joined connection (بشرتك → بشرتــك), used as a stretch on the key word; the fitter reserves the stretched width.
- **Families** (Arabic copy only): `ar-cluster-rise`, `ar-cluster-cascade`, `ar-cluster-drop`, `ar-fill-sweep` (ghost → ink in reading direction), `ar-ink-sweep` (feathered line wipe), `ar-weight-settle`, `ar-kashida-stretch` (needs a highlight). The planner puts them first for Arabic headlines, support lines and CTAs.
- **QC**: `ARABIC_SPLIT_GLYPHS` now tests real joins in the DOM (two adjacent text nodes on one line whose letters connect) instead of flagging every single-letter span.
- Scene family `kinetic-arabic` (stack / hero-word / rise) shows all of it.
