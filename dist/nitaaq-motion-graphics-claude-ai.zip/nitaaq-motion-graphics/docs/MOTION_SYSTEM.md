# Motion system

Motion in NITAAQ is planned at film level, then executed per element with physics presets. Every move must have a job; motion without a job is removed.

## 1. AI Creative Director (`src/director/creative.ts`)

Runs after the storyboard and writes its decisions to `motion_spec.json` and `shotlist.json`:

- **One motion personality** for the whole film: explicit `brief.motion` → tone words → style → reference motion energy.
- **A motion job per scene** from its story beat (`hook → stop-the-scroll`, `demo → show-how-it-works / connect-states`, `data → make-the-number-land`, `cta → resolve / direct-action`, …).
- **One hero moment**: the strongest product/solution/brand/demo/offer beat in the middle of the film (never the first or last scene).
- **Escalation curve**: hook 0.8 → build → hero 1.0 → CTA 0.7 (the CTA resolves, it does not shout).
- **Camera budget**: at most `ceil(scenes × activity × 0.6)` camera moves, given to hero, hook and CTA first; scenes marked strict-safe-area never move the camera.
- **Transitions** are chosen by meaning by the Transition Engine (`TRANSITIONS.md`): relationship of the two scenes first, a flashy budget, never the same non-cut type back-to-back.
- **Beat sync** (music, no voice): cut points snap to the nearest beat or downbeat within ±0.18 s when the previous scene can absorb the change (never below its minimum duration). Voice-led films follow the voice, never the beat.
- Deterministic: all choices use a seeded RNG. Same brief + seed = same film.

## 2. Personalities (`src/motion/personality.ts`)

| Personality | Feel | Stagger | Max overshoot | Camera activity / moves | Transitions |
|---|---|---|---|---|---|
| premium | controlled, heavy, deliberate | 0.12 s | 1 % | 0.45 · push, drift | crossfade, light-sweep, blur, wipe |
| energetic | fast, punchy, strong impacts | 0.05 s | 12 % | 0.55 · push, pans | push, zoom-in, speed-ramp, slide |
| playful | springs and bounce | 0.06 s | 35 % | 0.40 · drift, push | zoom-in, push, iris, color-sweep |
| corporate | restrained, precise | 0.08 s | 2 % | 0.20 · drift | push, crossfade, wipe |
| cinematic | depth, camera, reveals | 0.12 s | 2 % | 0.75 · push, pull, drift, rise | crossfade, light-sweep, blur, zoom-out |
| tech | precise, UI-aware micro-interactions | 0.05 s | 6 % | 0.40 · push, drift | mask-wipe, push, zoom-in, crossfade |
| sport | aggressive, impact-based | 0.04 s | 14 % | 0.70 · push, pans | speed-ramp, push, wipe, cut |

## 3. Physics library (`src/motion/physics.ts`)

Twelve presets, measured (overshoot and settle frames at 30 fps are computed, and unit-tested):

| Preset | Drive | stiffness/damping/mass | Overshoot | Settle (frames) | Use |
|---|---|---|---|---|---|
| snappy | spring | 260/26/0.7 | 0 % | 10 | UI and punchy type |
| responsive | spring | 320/30/0.6 | 0 % | 9 | buttons, toggles, cursors |
| soft | curve | 120/24/1 | 0 % | 16 | body copy, secondary info |
| heavy | spring | 110/22/1.6 | 1 % | 16 | dashboards, devices, big panels |
| premium | curve | 90/26/1.3 | 0 % | 22 | luxury reveals |
| playful | spring | 180/11/0.8 | 20 % | 18 | icons, stickers |
| elastic | spring | 140/9/0.8 | 23 % | 26 | pops and badges (sparingly) |
| cinematic | curve | 70/20/1.4 | 0 % | 38 | camera, atmosphere |
| mechanical | curve | 400/40/0.5 | 0 % | 11 | data, tickers |
| sport | spring | 380/18/0.6 | 9 % | 8 | sports and hype |
| corporate | curve | 150/28/1 | 0 % | — | institutional, measured ease-out |
| tech | spring | 300/30/0.7 | 2 % | — | product UI and SaaS, crisp |

Default per element type: button/cursor → responsive · card/icon/notification/hero-title → snappy · text/body → soft · panel/dashboard/device/product → heavy · logo → premium · chart/number → mechanical · camera/background → cinematic. Each personality overrides some of these (e.g. premium makes buttons and icons `soft`; sport makes cards and numbers `sport`).

## 3b. Animation Principles Engine (`src/motion/principles.ts`)

One function, `motionProfile(personality, element, areaFraction)`, decides **how** a thing moves from **what** it is, how big/heavy it looks, and the film's personality. Every scene that animates an element asks it rather than hard-coding easing.

- **Apparent mass** (feather → light → medium → heavy → massive) from the element kind and its on-screen area; heavier = longer (`timeScale` 0.75 → 1.35).
- **Anticipation**: a small counter-move before expressive moves (6–10 % of travel for bouncy personalities, 3 % tech); never on buttons, cursors, charts, numbers, or under premium / corporate / cinematic.
- **Overshoot** bounded by the personality's budget ∩ the preset.
- **Follow-through** (`followThrough`): children lag and settle after their parent; **secondary motion** (`secondaryMotion`): shadows/labels/glows react slightly later.
- **Arcs** (`arcPoint`): organic objects (product, icon, logo, card, notification) travel on arcs; UI travels straight.
- **Squash & stretch** (`squashStretch`): volume-preserving, only for light objects in playful (and slightly in sport) films — never on logos or titles.
- **Sound anchors** (`anchorsOf` / `profileAnchors`): the same motion curve yields `start`, `peak` (peak velocity), `contact`, `settle`, `completion` — the Sound Director syncs to these (`SOUND_DIRECTOR.md`), not to scene start.

The profile's `why` string is written to `motion_spec.json`, so every move documents its reason.

## 4. State-based motion and shared elements

`state-flow` (alias `shared-element`, `journey`) moves one element through the product journey (logo → search → result → product → cart → checkout → success): the same surface morphs size, radius and content between states instead of cutting between unrelated cards. `form-fill`, `workflow`, `order-success`, `browser-scene` and `landing-page` are also state-driven (empty → typed → submitted → done). Across scenes, the same logo / product / screenshot is carried by a measured **shared-element transition** (`TRANSITIONS.md`).

## 5. Seamless loop

`brief.loop: true` → `timeline.seamlessLoop`: the last scene returns to the opening frame state; final QC compares first and last frames (`LOOP_SEAM` if the 64×64 grey difference is above 14).

## 6. QC checks on motion

`HOLD_TOO_SHORT`, `VOICE_DRIFT`, `MOTION_NO_PURPOSE`, `CAMERA_OVERUSE` (> 70 % of scenes), `TRANSITION_MONOTONY`, `TRANSITION_REPEAT`, `TEXT_MOTION_REPEAT`, `TEXT_MOTION_OVERUSED`, `PERSONALITY_MISMATCH`. See `QUALITY.md`.

## 7. Motion Engine 2.0

- **Springs** (`src/motion/spring.ts`): closed-form damped oscillator (under/critical/over-damped), `springFromBounce(bounce, visualDuration)`, settle time, overshoot, `inertiaAt` (throw + decay to a boundary), `momentumAt` (multi-leg). Pure functions of time.
- **Easing** (`src/motion/easing.ts`): cubic-bezier solver, anticipate, back, elastic, bounce, steps, mirror/reverse/blend, named `RATE` table per role.
- **Orchestration** (`src/motion/orchestrate.ts`): stagger (from first/last/centre/edges/random-seeded, with easing over the stagger), keyframe tracks, sequences with overlaps, numeric velocity.
- **Motion Intent System** (`src/motion/intent.ts`): every element gets a role (hero-product, headline, supporting-text, cta, logo, ui, illustration, icon, background, data) and an intent (reveal, emphasis, transition, navigation, transformation, continuity, attention, …) → the motion, its timing and its sound are chosen from the intent, written to `scene.motion.intents`.

## 8. Motion Director 2.0

- **Visual Rhythm Plan** (`src/director/rhythm.ts` → `rhythm_plan.json`): per scene start, length, energy, copy density, the cut into it, camera, beat accents; film checks for monotony (three equal lengths), a repeated cut, hero placement (30–85%), a breath before the hero, readability (≤ 22 characters/s) and contrast (length variation).
- **Motion Language** (same file): the film's vocabulary — personality, easing, entrances, text families, transitions, camera moves, its signature move and its rules — so edits stay in the same language.
- **Anti-Template System** (`src/director/anti-template.ts`, history in `workspace/.history/films.json`): each film's fingerprint (family/variant sequence, cuts, camera, backgrounds, text families, personality) is compared with the last 40 films; above 60% similarity the director varies only non-semantic choices — cuts without a story reason, sibling camera moves, variants with at least the same text capacity — until it drops below. Content, order, timing, brand and product never change. Report: `anti_template.json`. `NITAAQ_NO_ANTI_TEMPLATE=1` turns it off.
- **Camera**: docs/MOTION_SYSTEM.md. **Morphing**: docs/MOTION_SYSTEM.md.


---

# Choreography Engine

A choreography describes a whole moment on one timeline:

> cursor moves → hover → press → the folder compresses → click sound → glass pulse → the folder opens → video cards emerge → the camera pushes in → focus moves to the cards

Without it, each animation is written separately with hand-typed delays. With it, the relationships are stated directly:

- one action follows another;
- this action overlaps that one;
- this action starts when that cue fires.

The engine resolves those relationships into exact times.

It is a layer on top of the existing motion engine, not a second one. `compileChoreo` decides only **when** things happen. The values still come from the existing primitives: `curve`, `springAt`, `staggerDelay` and `trackAt`.

Remotion stays the clock. The compiled choreography is a set of pure functions of time, which a scene evaluates at its own `frame / fps`. Nothing is stored between frames, so the render, stills, `nitaaq seek` and QC agree, and the same JSON always gives the same film.

The engine has three parts:

| File | Role |
|---|---|
| `src/motion/choreography.ts` | Timeline schema, compiler, property tracks, focus handoff, events, camera |
| `src/motion/interaction.ts` | Cursor vocabulary, pointer state, how the target element responds |
| `src/motion/phrases.ts` | Motion Phrases: reveal, interaction and camera |

## The timeline (JSON, zod-validated)

```json
{
  "initial": { "folder.open": 0 },
  "timeline": [
    { "type": "action", "id": "reveal", "target": "folder", "dur": 0.6, "spring": { "bounce": 0.3 }, "props": { "reveal": 1 } },
    { "type": "action", "target": "cursor", "kind": "move", "dur": 0.8, "data": { "to": "folder" }, "at": "-=0.2" },
    { "type": "action", "id": "press", "target": "cursor", "kind": "press", "data": { "target": "folder" } },
    { "type": "par", "children": [
      { "type": "cue", "id": "click" },
      { "type": "action", "target": "folder", "shape": "pulse", "dur": 0.5, "props": { "glow": 1 } }
    ] },
    { "type": "action", "id": "open", "target": "folder", "trigger": "click", "offset": 0.1, "dur": 0.7, "spring": { "bounce": 0.25 }, "props": { "open": 1 }, "event": { "type": "ui_appear" } }
  ]
}
```

### Nodes

| Node | Meaning |
|---|---|
| `action` | A timed move of `target`. `props` gives the values it moves to; `from` gives explicit start values. Timing comes from `dur` with `ease` (a curve name, `linear` or `hold`) or from a `spring`. |
| `wait` | A gap of `dur` seconds. |
| `marker` | A named moment that other nodes can refer to. |
| `cue` | A named moment, optionally with a Sound Director `event`. A `trigger` starts on it. |
| `seq` | Children run one after another. The root is a `seq`. |
| `par` | Children start together. |
| `stagger` | Children start `each` seconds apart, using the motion engine's distribution: `from` first / last / center / edges / reading / an index, plus `ease` and `maxTotal`. |

Ids use letters, digits, `_` and `:` only. A `-` would read as an offset, as in `card-0.2`.

### Placement (any node)

| Field | Example | Start |
|---|---|---|
| default | | after the previous sibling (`seq`), with the container (`par`), on the stagger (`stagger`) |
| `at` number | `2.4` | absolute seconds |
| `at` relative | `"<"`, `">"`, `"<0.2"`, `">-0.1"`, `"+=0.3"`, `"-=0.25"` | with / after the previous sibling, gap or overlap |
| `at` reference | `"press.end+0.06"`, `"open.peak"`, `"click"` | a point of any id, marker or cue in the tree (`start`, `end`, `peak`, `contact`, `settle`) |
| `trigger` | `"click"` | when that cue fires. Forward references work. |
| `follow` | `{ "id": "lead", "lag": 0.1 }` | follow-through: the leader's point plus a lag. An action without its own `dur`, `ease` or `props` inherits the leader's. |
| `handoff` | `{ "from": "open", "at": 0.6 }` | while `from` is still finishing, at that fraction of it. Focus passes from its target to this one. |
| `offset` | `0.1` | added after the placement is resolved |

The compiler refuses three things, each with a clear `ChoreoError`:

- unknown references;
- duplicate ids;
- cycles.

`timeScale` stretches every duration, wait and absolute time. A scene uses it to fit a phrase into its length.

### Property tracks

```
valueAt(c, 'folder.open', t)    targetValues(c, 'folder', t)
```

| `shape` | Behaviour |
|---|---|
| `to` | Moves from the track's current value. A later move interrupts an earlier one without a jump, and a spring inherits the velocity of the move it interrupts. |
| `pulse` | Goes there and back over `dur`, added on top. |
| `kick` | A spring impulse that peaks at the amount and settles by itself. Used for camera accents. |

Rest values: `scale`, `zoom`, `close` and `opacity` are 1; `focusX` and `focusY` are 0.5; everything else is 0, unless `initial` says otherwise.

Queries:

- `phaseOf(c, id, t)`: `before`, `active` or `done`, with eased progress.
- `activeAt(c, t)` and `passedAt(c, t)`: what is running and which markers or cues have passed.
- `focusAt(c, t)`: focus weights after handoffs.

## Interaction choreography (the existing Cursor, extended)

Cursor actions are ordinary actions with `target: "cursor"` and a `kind`:

| kind | data | What happens |
|---|---|---|
| `appear` | `to` | The pointer fades in at `to`. |
| `move` | `to` (element name or `{x, y}` as a fraction of the canvas), `arc` | It travels on a slight arc that is fast at first and decelerates into the target. Arriving on an element starts its hover; moving away ends it. |
| `hover` | `target` | It stays over the element; the element takes its hover state. |
| `press` | `target` | Button down. The element compresses and stays compressed while held. The default event is `button_press`, with its contact at the bottom of the press. |
| `release` | `target` | Button up. The element springs back slightly past rest (a pop) and `released` runs 0 → 1, a state transition. |
| `click` | `target` | Press and release in one action. The press takes 45%, and the contact sits at the bottom of it. |
| `drag` | `target`, `to` | The pointer holds the element and carries it, with a small lag, to `to`, then releases there. The default event is `swipe`. |
| `leave`, `hide` | | It moves off and fades out. |

`elementAt(ix, 'folder', t)` gives the element's response:

- `hover`, 0..1;
- `press`, 0..1 for compression, below 0 for the release pop;
- `click`, 0..1 for the reaction pulse, with `clickAge` in seconds;
- `released`;
- `dragging` and the `drag` offset.

`cursorAt(ix, t, resolve)` gives the pointer:

- its position;
- `visible`;
- `press`;
- `ripple`;
- a `hover` halo;
- `speed`.

Positions are resolved through the scene's own layout, so the same choreography and the same sound events work in every aspect.

`<Cursor keys={…}>` is unchanged. `<Cursor state={cursorAt(…)}>` draws the same pointer with a hover halo and a press that holds while the button is down.

## Sound from the same timeline

The Sound Director reads the choreography's events. They come from the cursor kinds' defaults, from an action's `event`, and from a cue's `event`.

Every event carries **exact anchors** measured from its own timing:

- **start**;
- **peak**, the velocity peak of its curve or spring;
- **contact**: the end of a move, or the bottom of a press;
- **settle**, from the spring;
- **completion**.

So the click lands on the frame where the button bottoms out. `event: false` silences a default.

A scene passes them on with `events: (c, v, d) => compiled.events`.

## Camera choreography

Actions on the `camera` target drive the Camera Engine from the same timeline:

| Property | Effect |
|---|---|
| `focusX` / `focusY` | The subject, as a fraction of the canvas |
| `close` | Framing tightness, where 1 is rest |
| `dolly`, `zoom`, `tilt`, `yaw`, `roll` | Direct channels |

`cameraFromChoreo(c, t, W, H)` maps them with the same constants as a `track` camera plan. `<CameraRig state={…}>` renders them on the rig's depth planes.

A scene uses its timeline's camera only when the scene shell has no `cameraPlan` of its own, so there are never two cameras.

## Motion Phrases

Connected motion replaces the pattern where one element arrives, stops, and then the next one arrives:

| Phrase | Shape |
|---|---|
| `revealPhrase(target)` | anticipation (a small dip) → reveal (spring) → settle → secondary response, which overlaps the end |
| `interactionPhrase({ target, from, response, consequence })` | approach → hover → press → response (from the click) → release → consequence (it starts while the finger is still lifting) → leave / hide |
| `cameraPhrase({ focus, close, passForeground, transferTo })` | establish → accelerate → pass foreground → focus transfer → settle (a kick) |

Each part has an id (`folder_interaction_press`, `camera_phrase_arrive`…), so an edited JSON can move any part.

## Scene family `interaction-flow`

| Variant | Timeline |
|---|---|
| `folder` | The folder reveals. The cursor approaches and hovers, and the folder lifts. A press compresses it. The click brings the sound and a glass pulse. On release the folder opens, video cards emerge in a stagger from the centre, the camera pushes in, and focus hands off from the folder to the cards. |
| `button` | The button reveals → approach → hover → press → click → success state, with a small camera kick. |
| `drag` | The cursor grabs a card and drags it into the folder. The folder takes it with a squash, a glow and a `+1`. |

Content fields:

- `folder`;
- `items` (1–6, each with a `title` and an optional image or video `media`);
- `button` and `success`;
- `from` (where the pointer enters);
- `eyebrow`, `title`, `subtitle` and `caption`;
- `choreography`, an edited timeline that replaces the built-in one. It uses the same element names: `folder`, `cardN`, `button`, `cursor`, `camera` and `cards`.

The natural timeline is compressed to fit a short scene, never stretched. The folder here is a simple flat folder. The glass portfolio folder is a later phase.

## Seek

For a choreographed scene, `nitaaq seek` reports a `choreography` entry with:

- the timeline time;
- the running actions;
- passed markers and cues;
- the cursor action, with `visible`, `press` and `hover`;
- each element's hover, press, click and released values;
- focus weights;
- the timeline's camera state.

## Limits (honest)

- The Director does not pick `interaction-flow` on its own yet; it is used when a film or edit names it. Motion Phrases inside the Director's planning come in a later phase.
- Overlapping `to` moves on the same property hand over (the later one takes over from the current value). There is no additive blending of two `to` moves.
- A `drag` carries one element at a time.


---

# Glass + Spatial

This phase adds three things:

- Glass 2.0, an opt-in model of how a glass pane looks;
- the GlassPortfolioFolder, a folder built from glass layers with six states;
- the Spatial Video Gallery, where several videos play at once on cards placed in depth while the camera tours them.

All three build on what already exists:

- the Surface component;
- the Choreography Engine (`docs/MOTION_SYSTEM.md`);
- the camera model of the rig (`src/camera/rig.ts`);
- `VideoMedia`.

Nothing old changes:

- A `Surface` without `glass` draws exactly as before, in every kind.
- The Cursor and the Camera keep their defaults.

| File | Role |
|---|---|
| `src/components/glass.ts` | Glass 2.0 as pure style data (`glassLook`) |
| `src/components/Surface.tsx` | new optional `glass` prop |
| `src/components/glass-folder-state.ts` | the six folder states and the pose they read from (pure) |
| `src/components/GlassPortfolioFolder.tsx` | the folder component |
| `src/camera/spatial.ts` | cards in depth, the camera that tours them, pass-through, plane maps |
| `src/scenes/spatial/program.ts` | the timelines of the two families (pure) |
| `src/scenes/spatial/spatial-scenes.tsx` | the `glass-folder` and `spatial-gallery` families |

## Glass 2.0

```tsx
<Surface glass={{ frost: 0.7, thickness: 0.6, edgeLight: 0.7, specular: sweep, refraction: 0.4, chroma: 0.4, light: { x, y }, grain: 0.5 }} />
```

| Option | Effect |
|---|---|
| `frost` | Blurs what is behind the pane (backdrop blur, capped at 24px). In simulated frost it makes the pane milkier. |
| `tint`, `opacity` | The colour and strength of the pane. They default to the style's surface. |
| `thickness` | A bevel: the edge toward the light is lit and the opposite edge is shaded. |
| `edgeLight` | A rim of light around the edge, brightest toward the light. |
| `specular` | The position of a light band that sweeps across the pane: −0.3 is before it, 1.3 is past it. Scenes animate this value on their timeline. |
| `refraction` | Simulated: light bent through the thickness gathers as a caustic along the far edge, and it shifts against the light. |
| `chroma` | A chromatic fringe: warm on one side, cool on the other. |
| `light` | The light direction (−1..1). The spatial scenes pass the camera here, so reflections move as the camera moves. |
| `grain` | A fixed frost texture, the same seed every frame. |
| `backdrop` | `auto` (the default), `live` or `simulated`. |

**Live or simulated.** In Chromium, a backdrop blur inside a 3D (`preserve-3d`) camera has bad rendering paths. So `auto` picks between the two modes:

- **live blur:** used only in full-effects renders outside an active 3D camera;
- **simulated frost:** used everywhere else. It is more opaque and milkier, so it still hides what is behind it, and it costs nothing.

`data-qc-glass` on the surface says which mode was used. `glassLook` is a pure function of its inputs.

## GlassPortfolioFolder

The folder has five layers, from back to front:

1. **Back pane and tab:** tinted frosted glass.
2. **Two inner sheets:** they rise as the folder opens.
3. **What it holds:** the cards.
4. **Front pane:** frosted, with a lit rim, a specular sweep, refraction, a chromatic edge and grain. It frosts the cards behind it.
5. **Glow ring:** the click pulse.

It has six states, all read from one continuous pose (`reveal`, `hover`, `press`, `open`, `explode`, `glow`, `dim`, `sweep`). Each state blends into the next on the scene's timeline; there is no switch between drawings.

| State | Reads as |
|---|---|
| `closed` | at rest |
| `hover` | lifted, rim brighter, shadow softer |
| `pressed` | compressed, shadow tighter |
| `opening` | the front pane tips back |
| `open` | the cards are out |
| `exploded` | the glass layers separate (back up, sheets fan, front down) and the cards fan out around it |

- `folderState(pose)` names the state, and `folderPose(state)` gives the pose of a named state.
- The folder sets `data-qc-folder-state`.

Everything is 2D. In Phase 4, text inside a 3D-transformed layer did not rasterise identically run to run, so the front pane tips back with a scale and a trapezoid clip instead of a `rotateX`.

## Spatial camera (`src/camera/spatial.ts`)

This is the same camera model as the rig.

**Where a card lands.** Take a card on plane `d`, at physical offset `(X, Y)` from the canvas centre, with physical width `w`. Under camera `(x, y, dolly, zoom)`, with no tilt or yaw, it shows at:

```
k = zoom / (1 + d − dolly)      screen = centre + (X − x, Y − y)·k      size = w·k
```

This is exactly what `project()` and CSS 3D give for that plane; the unit tests check it.

**Drawn in 2D.** Every plane that faces the camera maps to a translate plus a scale. So the spatial scenes draw their planes in 2D with these numbers instead of nesting them in a `preserve-3d` world:

- the picture is the same;
- frosted glass keeps its live blur;
- text and video rasterise identically run to run.

**Main functions:**

| Function | What it does |
|---|---|
| `cardOnScreen(card, cam)` | Returns the screen rect, the clearance and the pass-through opacity. |
| `planeMap` / `planeTransform` | Give the 2D map, or the CSS, of a plane under the camera. The glass folder uses it for its camera push. |
| `frameCard` | Frames one card at a target width. |
| `fitCards` | Gives the tightest camera that shows a whole set inside the stage. |
| `galleryLayout(variant, n, …)` | Places the cards and computes their framings and the overview. |
| `galleryCamera(layout, travel, push, back)` | Gives the camera at a point of the tour. `travel` −1 is the overview and `i` is card `i`. Values in between blend the neighbours, with a pull-back arc and a depth-of-field ramp. `back` returns to the overview directly. |

**Pass-through.** A card the camera flies past fades out while its clearance is between `PASS_FADE` = [NEAR + 0.07, NEAR + 0.4]. It is gone before it reaches the lens, so the camera never collides with it.

## Scene family `glass-folder`

| Variant | Timeline |
|---|---|
| `open` | The folder reveals. The cursor approaches and hovers: the folder lifts, its rim brightens and light sweeps across the front pane. A press compresses it. The click brings the sound and a pulse. On release the folder opens and the video cards rise out. The camera pushes in, and focus hands off to the cards. |
| `explode` | The same, then the folder explodes: its glass layers separate, the cards fan out around it, and the camera eases back. |

Content fields:

- `eyebrow`, `title`, `subtitle` and `caption`;
- `folder`;
- `items` (1–6), each with a `title`, an image or video `media`, and a `clip` (trim, loop, rate);
- `from`;
- `choreography`, an edited timeline. It uses the element names `folder`, `cardN`, `cards`, `cursor` and `camera`. The folder's properties are `reveal`, `open`, `explode`, `glow` and `sweep`; a card's properties are `out` and `fan`.

## Scene family `spatial-gallery`

Several videos play at once, each on a Glass 2.0 card in depth. Each video is frame-driven with its own clip.

| Variant | Tour |
|---|---|
| `corridor` | The opening view is a cascade that alternates sides and climbs into depth. The camera flies to each card in turn and passes the ones it leaves behind. |
| `wall` | The camera starts on the whole wall, visits each card (pulling back between them) and returns to the whole wall. |

What follows the camera:

- **Focus:** the framed card gets a ring, and the others dim.
- **Depth of field:** cards off the focus plane blur, in full renders.
- **Glass reflections:** they shift with the camera.
- **Light sweep:** light runs across a card's glass as the camera arrives on it.
- **Title and dots:** the focused card's title shows under the cards, with a row of position dots.

Content fields:

- `eyebrow`, `title` and `subtitle`;
- `items` (2–6), each with a `title`, a `media` and a `clip`;
- `cardAspect`, which defaults to 4:5 on portrait canvases and 16:9 on landscape ones;
- `choreography`. Its targets are `gallery.travel`, `gallery.back`, `gallery.push`, `cardN.reveal` and `cardN.sheen`.

**Sound** comes from the same timeline:

- `card_entry` when the cards reveal;
- `camera_move` for each move of the tour.

## Never two cameras

Both families run their own timeline camera only when the scene shell has no `cameraPlan`. When the shell has one, the folder is drawn at rest and the gallery holds its overview, and the shell's camera moves the whole scene.

## Seek

`nitaaq seek` reports, for these families:

- `choreography.folder`: the state, `open` and `explode`;
- `choreography.gallery`: `travel`, `back` and the focused card;
- under `videos`, every card video at the source time it shows.

The gallery's camera itself depends on the layout, which depends on the canvas, so seek reports the tour rather than the camera.

## Determinism

Structure, timing, the folder states, the camera and the sound are identical run to run. Production renders were checked frame by frame. A few choices make the glass and the card edges identical too:

- **The folder's front pane uses simulated frost.** The live backdrop blur over the moving pointer and the emerging video cards differed by a few colour levels between runs. The live blur is still available (`backdrop: 'live'` or `'auto'`) for panes over still content.
- **Video thumbnails have square corners and sit in a window with a keyline.**
  - The picture overhangs its window a little, so its own edge is never on screen.
  - One solid keyline border straddles the window's edge. When a video is shown much smaller than its source, the anti-aliased edge pixel varied slightly run to run, and the keyline covers that pixel.
  - Rounding the video's corners (a clipped box, or a radius on the picture) varied the same way.
- **A card that plays a video does not rotate.** The fan then reads from position and scale; cards without a video still tilt.
- **The lit rim is drawn with inset box shadows,** not with a mask-composite ring.

**What is left.** The pixels inside a video picture, and in the frosted strip drawn over it, can still differ slightly between runs. This happens only while that picture moves or changes size. In the test film, measured on lossless frames:

- the difference is usually 1–5 levels of 255;
- it reaches 26 in a few dozen pixels while the folder explodes.

- **Cause:** each video frame reaches Chromium as a new image (`OffthreadVideo`), and Chromium does not always resample a new image the same way when it draws it scaled.
- **What was ruled out:**
  - The same scene with still images instead of videos renders identically.
  - Snapping the source time to the middle of a frame, PNG frames (`transparent`), one render worker, and a software GL backend did not remove the difference. The software backend only reduced it.
- **Effect:** the difference is invisible. It never touches text, edges, glass or timing.

## Limits (honest)

- **Simulated refraction:** there is no real light bending through the pane.
- **Spatial camera:** it has no tilt or yaw, by design, so the cards always face the lens. Orbiting the gallery is a later camera phase.
- **The Director:** it does not pick these families on its own yet; they are used when a film or edit names them.
- **Performance:** six simultaneous videos, each with its own glass frame, is the heaviest scene in the library. The live blur is kept for the folder's front pane, and the gallery's card frames use simulated frost.


---

# Cinematic Camera 2.0 (2.5D, depth, parallax)

A real 2.5D camera over depth planes, with the same maths as CSS 3D, so what the QA measures is what renders.

| File | Role |
|---|---|
| `src/camera/rig.ts` | camera state (x, y, dolly, zoom, tilt, yaw, roll, focus, aperture), `project` / `projectRect`, `unproject` (Newton) / `unprojectRect`, clearance (a plane must never reach the lens), depth of field |
| `src/camera/moves.ts` | 22 named moves (`push-in`, `pull-out`, `dolly-*`, `truck-*`, `pan-*`, `tilt-*`, `pedestal-*`, `orbit-*`, `arc`, `crane-up`, `zoom-*`, `rack-focus`, `track`, `drift`, `static`) → `cameraAt(plan, t)`; waypoints; beat accents; `peakSpeed` |
| `src/camera/CameraRig.tsx` | `<CameraRig plan>` (perspective + world transform) and `<DepthLayer plane>`; outside an active rig a DepthLayer is a plain fill, so old films render exactly as before |
| `src/camera/director.ts` | `planCamera()` — which move serves this subject (see below) |
| `src/camera/framing.ts` | `auditFraming` / `solveFraming` — protected elements (text, product, logo, CTA) must stay inside the safe area for the whole move |

## Depth planes

Perspective `D = hypot(W, H) × 1.25`. Planes (fraction of D): foreground −0.32, midground −0.12, **hero 0** (authored layout is exact), background 0.7, atmosphere 1.6. Each layer keeps its rest size (`translateZ(−dD) scale(1 + d)`), so only the camera moves things: near planes move more (true parallax).

The scene background sits on the background plane, overscanned 12.5% a side about the centre (orbits/arcs move the far plane by up to ~11%; measured, see `test/unit/motion2b.test.ts`).

## Which move (camera director)

| Subject | Move |
|---|---|
| hero product | orbit-left / arc / push-in (+ depth of field for premium/cinematic) |
| logo / brand | crane-up (push-in when restrained) |
| CTA | pull-out |
| UI | truck-left in RTL films, truck-right in LTR |
| data | pedestal-up |
| headline | push-in or drift |

Corporate never orbits, arcs or cranes. Amplitude per personality: premium .8, cinematic 1, corporate .6, tech .85, playful .9, energetic 1.05, sport 1.1 (×0.85 off the hero). Music-led films (not premium/corporate) add up to 3 downbeat accents per scene.

`scene.motion.cameraPlan` is plain JSON (move, amplitude, ease, focus, accents, waypoints, dof, reason) — editable by hand; the legacy `scene.motion.camera` name still works.

## QA

Visual QA 2.0 unprojects every measured element back to its rest position and audits the whole move (30 samples). A violation becomes `CAMERA_FRAMING` with the repair `camera-solve`: apply the solved plan (smaller amplitude / moved focus), else halve the amplitude.

## Camera Solver, presets and pass-through (Premium Phase 6)

The rig and the move library stay as they are; the solver (`src/camera/solver.ts`) adds targets on top of them. `cameraAt(plan, t)` resolves a preset, frames the target(s), plays the move around that framing, then applies the bounds. A plan without the new fields gives exactly the old numbers.

| Field of `cameraPlan` | What it does |
|---|---|
| `preset` | `hero-reveal`, `product-orbit`, `brand-crane`, `ui-tour`, `impact-push`, `calm-drift`, `flythrough`, `focus-pull`, `resolve-pull` — fills only the fields the plan leaves unset (`move: "static"` takes the preset's move) |
| `target: { rect, depth?, fill? }` | auto framing of one element or a group (`rect` may be a list → union): dolly first, then lens zoom where the dolly would come too close (protected planes keep NEAR + 0.12) |
| `targets: [{ t, rect, depth?, fill? }]`, `lag` | smooth look-at: the camera follows each new target with an eased lag (velocity 0 at both ends, no jump) |
| `bounds: { world?, depth?, minDolly?, maxDolly?, maxZoom? }` | the visible window never leaves the world rect, the dolly stays in its limits |
| `passThrough` | the `fly-through` move may travel through the hero plane: each `DepthLayer` fades over the pass band (clearance NEAR+0.07 → NEAR+0.4) and is hidden before it reaches the lens |
| `motionBlur` | velocity-aware directional blur from `blurHint` (shutter 180°, threshold 0.35 u per frame, cap 3 u) as an SVG `feGaussianBlur` — only while the camera is fast, full effects only |

`focusHandoff(a, b, u)` blends two framings with a rack of the focus plane (depth of field peaks mid-way). Probes: `data-qc-camera` (preset or move), `data-qc-pass` (pass-through opacity), `data-qc-motion-blur`.


---

# Advanced Morphing

True path morphing (not a crossfade), reimplemented from the published ideas of flubber / Manim's `Transform` — no code copied, no dependency added.

| File | Role |
|---|---|
| `src/morph/path.ts` | SVG path parser (all commands → cubic segments), arc-length `resample`, `alignRing` (rotation + winding that minimises travel), `prepareMorph` (sub-path matching: biggest bodies pair; extra sub-paths shrink into / grow from the nearest body), `morphAt(plan, t, arc)` (`arc` bends travel around the common centre, like Manim's `path_arc`), `midSilhouetteOk` |
| `src/morph/shapes.ts` | `shapePath` (circle, squircle, hexagon, star, blob…), `blobPath` (seeded organic body), `iconPath` (any Lucide icon as one path; every element's leading relative `m` is anchored, so joined elements stay in place) |
| `src/morph/trace.ts` | `traceContours` / `silhouettePath` — an image's alpha → its outline path |
| `src/morph/useSilhouette.ts` | browser hook: traces a logo/product silhouette (delayRender, cached) |
| `src/morph/Morph.tsx` | `<MorphShape stages>` (spring-timed stages), `<MorphMask>`, `<LiquidBlob>` |

## Where it is used

- `morph-story` scene family: one body becomes each step (icons as line art, or filled shapes), caption per stage.
- Logo reveal `liquid-morph`: a breathing blob springs into the logo's traced silhouette, then the real logo fades in — the settled frame is always the untouched logo (needs a logo with transparency).
- Transitions `morph` / `shape-match` / `liquid` (Transition Intelligence).
- Background kind `liquid` (two large organic bodies breathing slowly).

All of it is a pure function of the frame (deterministic seek).


---

# Scene Transition Engine & Shared Elements

Code: `src/transitions/presentations.ts` (TransitionRegistry, 30 presentations), `src/transitions/engine.ts` (`chooseTransitions`), `src/node/shared-rects.ts`, `src/engine/VideoComposition.tsx` (`SharedLayer`).

## Registry

Every transition declares what it **means** (continuity, reveal, energy, calm, contrast, space, ui, brand, time), its energy, and its visual **peak** (0..1 of the window — the Sound Director syncs the transition sound there).

`cut, none, crossfade, fade, slide, push, wipe, mask-wipe, zoom-in, zoom-out, blur, iris, light-sweep, speed-ramp, flip, color-sweep, match-cut, shared, morph, camera-push, camera-pull, whip, depth, shape, text-sweep, object-sweep, color-dip, perspective, page, split`

## How a transition is chosen

`chooseTransitions()` looks at each cut, in order:

1. **Relationship of the two scenes**, first match wins: same identity asset on both sides → `shared`; a cut on a musical beat in a rhythmic film → hard cut; into the hero / a reveal → the personality's reveal family (premium: light-sweep / camera-push / morph …); problem → solution, bridge, tease → the personality's contrast family; montage → mostly hard cuts (whip / speed-ramp sometimes); UI → UI → `page` / `push` / `match-cut`; same kind of content → mostly hard cuts; into the CTA → calm arrival (a cut after an energetic run); product reveal in energetic/playful/sport films → `object-sweep`; kinetic/launch films → one `text-sweep` carried by the next word; otherwise the personality's calm family or a cut.
2. **Meaning first, decoration never** — a cut on a musical beat is a hard cut; same-kind content cuts hard most of the time; "nothing to express" is a hard cut. A **flashy budget** (25 % of cuts for premium/corporate, 40 % otherwise) turns extra flashy picks into cuts, and rhythmic (energetic / launch / music) films keep at least 25 % hard cuts.
3. **Variety** — any one non-cut type is capped at a third of the cuts and is never used back-to-back.
4. **Style family** — the style preset's preferred transitions break ties inside a meaning.

The choice and its reason are written into `video.json` (`scenes[i].transition.reason`) and `shotlist.json`.

Motion QC: `TRANSITION_REPEAT` (back-to-back), `TRANSITION_MONOTONY` (> 50 % of cuts one type).

## Shared-element transitions

When two consecutive scenes show the same logo / product / phone / browser screenshot, the director plans a `shared` transition (`timeline.shared[]`). Before rendering, `produce` measures the asset with the DOM probe — where it really sits in the outgoing scene at the first frame of the transition and in the incoming scene at its last frame — and stores `fromRect` / `toRect`. During the window the film-level `SharedLayer` draws **one** copy that glides on an arc (products) or a straight path (UI/logos) with heavy physics and **uniform** size interpolation (`object-fit: contain`, never stretched), while both scenes hide their own copy (`useSharedHidden`). Pairs that cannot be measured (the asset is off-screen at one edge) keep a normal transition — nothing is guessed. Measurements are cached like QC probes.

Supported kinds in the schema: logo, product, phone, browser, card, text, shape, icon, chart, screenshot (identity media is what is measured today; text/shape continuity is done inside state-driven scenes such as `state-flow`).

## Transition Intelligence 2.0 (`src/transitions/continuity.ts`)

Reads how scene A ends and scene B begins and upgrades a plain cut to a continuity device when one exists: A's subject shape becomes B's frame (morph / shape-match), both scenes share a colour (color-match), A ends on a lateral camera move (camera-match), A's subject travels toward the next idea (motion-match), B is the hero reveal (zoom-through / liquid). It never overrides a shared-element transition, a beat cut, or the rhythm floor of energetic films, and rations itself to ≤ 40% of cuts. Each upgrade states its reason in `transition.reason` and carries its hints (focus, rect, shape, colour). Continuity transitions get silent or soft sound.

## Spatial transitions (Premium Phase 6)

Eight transitions extend the same engine (`src/transitions/advanced.ts`, same `TransitionFrame` contract, same overlay layer):

| Id | What happens |
|---|---|
| `card-push-through` | the camera pushes into a card of the outgoing scene (`rect`); the card is a window onto the next scene that grows to the frame |
| `video-match-cut` | a video frame of A becomes the video frame of B (rect → full frame) with a short exposure match |
| `foreground-card-wipe` | a card passes in front of the lens; the cut happens behind it (complementary clips — no doubled frame) |
| `glass-wipe` | a pane of frosted glass slides across; the next scene is already behind it |
| `scale-match` | the matched element (`rect` → `toRect`) carries the scale change across the cut |
| `z-depth-pass` | A flies past the lens toward `focus` while B arrives from depth |
| `directional-blur` | a whip along the motion `vector` with a directional SVG blur on both scenes |
| `focus-handoff` | a rack focus across the cut: A blurs out, B racks in, the two barely overlap |

**Motion Continuity vectors.** A scene edge may carry a `MotionVector` (direction, speed, depth, energy). `continuityScore(out, into, transition)` scores a cut 0..1 (still → still = 0.75; continuity transitions bridge +0.15). `refineContinuity` picks the spatial transitions first (video → video = match cut, matched rects = scale match, forward depth = push-through / z-depth, fast lateral = directional blur, depth of field = focus handoff, glass = glass wipe) — only the spatial / video families declare these edges, so every other film is chosen exactly as before.


---

# Text Motion Engine & Arabic Kinetic Typography

Code: `src/text-motion/families.ts` (registry), `src/text-motion/planner.ts` (film-level plan), `src/typography/Text.tsx` (renderer), `src/scenes/kinetic/` (kinetic scene families).

## Families (27, `TextMotionRegistry`)

Each family declares its unit for Latin text and the unit it falls back to for Arabic, the roles it suits, energy, duration, stagger, direction and curve.

| Family | Latin unit | Arabic unit | Typical role |
|---|---|---|---|
| mask-reveal, line-reveal, split-reveal, wipe-reveal, perspective-reveal, editorial-title, underline-draw | line | line | headline / support |
| word-stagger, scale-impact, blur-reveal, vertical-reveal, horizontal-reveal, slide-reveal, rotation-reveal, compress-expand, word-replace, number-count, marker-highlight, background-highlight, phrase-emphasis, controlled-bounce, typography-punch, follow-through, kinetic-sequence | word | word | headline / CTA / number |
| char-stagger | char | **word** | Latin headline only |
| tracking-reveal, cinematic-title | block | block | premium titles / labels |

Granularity supported by the renderer: block, line, word, character (Latin only), phrase / highlighted phrase (`emphasis` words), number (count-up with the project's numeral system), and **Arabic word groups** (a particle glued to the next word — و، ف، ب، ل، ال… — animates with it).

## Arabic rules (enforced in code and QC)

- No per-glyph animation on Arabic: `effectiveUnit()` never returns `char` for Arabic text; QC flags `ARABIC_SPLIT_GLYPHS` (critical) if a single Arabic letter ever ends up in its own span.
- No letter-spacing on Arabic (`ARABIC_LETTER_SPACING`): `tracking-reveal` uses **word-spacing** for Arabic, letter-spacing only for Latin, and never widens past the fitted width.
- RTL base direction per line; Latin runs and numbers are isolated inside RTL lines (mixed Arabic + English + numbers). Directional families (`slide`, `horizontal`, `wipe`, `follow-through`, `rotation`) mirror for RTL.
- Masks, clip-paths and line segmentation are used where a Latin design would split characters.
- Line breaking is Arabic-aware (`fitText`) and re-runs per aspect; the text fitter reports overflow instead of clipping.

## Film-level plan

`planTextMotion(scenes, personality, seed)` assigns per scene a family for each role group (headline / support / CTA / number / label):

- headline families come from the personality's palette (`HEADLINE_FAMILIES`), weighted by beat (hook → impact families, data → number-count, CTA → punch/scale), **never the same headline family in two consecutive scenes**, with a usage cap per film;
- the brand's `brand-motion.json` preferred / avoided families bias the choice (consistency across films without identical films);
- the plan is written to `motion_spec.json` and to each scene's `motion.text`.

Motion QC (`src/qc/audio-qc.ts → motionVarietyQc`) reports `TEXT_MOTION_REPEAT` and `TEXT_MOTION_OVERUSED`.

## Kinetic typography scenes

`kinetic-sequence` (rhythm / impact / build), `kinetic-stack`, `kinetic-number`, `kinetic-mixed` (Arabic + English), `kinetic-replace` (word replacement). `content.lines` in the brief is a kinetic script; the director keeps lines in order and uses word groups as units.

## Tests

`test/unit/v3-modules.test.ts` (Arabic never per glyph, English per char allowed, no back-to-back headline family, ≥26 families), `test/unit/arabic.test.ts`, visual baselines in `test/visual/baseline/`.

## Arabic Kinetic Typography 2.0

- **Joining-safe letter groups** (`joiningClusters` in `src/typography/arabic.ts`): a word is split only where the right letter does not join forward (ا د ذ ر ز و ة ى …) or next to a non-joining character; diacritics stay with their letter; lam-alef is never split. مواعيدك → مو · ا · عيد · ك. Each group animates on its own and the word still joins correctly.
- **Kashida** (`kashida(word, n)`): tatweel inserted only at a legal joined connection (بشرتك → بشرتــك), used as a stretch on the key word; the fitter reserves the stretched width.
- **Families** (Arabic copy only): `ar-cluster-rise`, `ar-cluster-cascade`, `ar-cluster-drop`, `ar-fill-sweep` (ghost → ink in reading direction), `ar-ink-sweep` (feathered line wipe), `ar-weight-settle`, `ar-kashida-stretch` (needs a highlight). The planner puts them first for Arabic headlines, support lines and CTAs.
- **QC**: `ARABIC_SPLIT_GLYPHS` now tests real joins in the DOM (two adjacent text nodes on one line whose letters connect) instead of flagging every single-letter span.
- Scene family `kinetic-arabic` (stack / hero-word / rise) shows all of it.


---

# Micro FX (Premium Phase 7)

Small, deterministic accents that land a moment: nine light effects drawn as a handful of SVG primitives (`src/fx/micro.ts`, layer `src/fx/MicroFx.tsx`, planner `src/fx/plan.ts`). They never replace motion; they punctuate it.

| Kind | Moment it serves | Duration |
|---|---|---|
| `burst` | a press / hit (energetic, playful) | short |
| `ripple` | a tap on glass / UI | short |
| `ring` | a premium press, a logo landing | short |
| `sparks` | a celebration, a counter final | short |
| `trails` | an element travelling (direction) | medium |
| `impact-lines` | a product landing (sport) | short |
| `energy-pulse` | a tech / hero reveal | medium |
| `glow-pulse` | a premium / brand reveal | medium |
| `directional-streaks` | a fast lateral move (direction) | short |

`scene.fx: [{ kind, at, x, y, size?, color?, intensity?, direction?, duration?, seed?, importance? }]` places one by hand (scene-local seconds, position in fractions). Every particle comes from `createRng(seed:kind:at)` — the same film always draws the same sparks.

**Auto accents** (`design.microFx: "auto"`, default `off`): the planner reads the film's motion events (Choreography Engine events carry their position), picks the accent by moment, Motion Intent and personality (`fxForMoment`; quiet intents such as continuity get none), and places it on the event. Centred reveals (hero / logo / CTA) sit on the frame centre.

**FX Budget** (`design.fxBudget`, else `design.effectBudget`, default MEDIUM): at most 3 / 6 / 10 accents per 10 s and a concurrent cost of 1.2 / 2.2 / 3.5 on screen for LOW / MEDIUM / HIGH; the most important accents are kept first, then the earliest. Their render cost joins the **Performance Budget** (`perf/effect-budget.ts`, contributor "micro FX accents"). Spatial QC reports `FX_BUDGET` when hand-placed accents go over it.


---

# Shot Script — Full Director Mode

The automatic director (Fast Mode) plans a film from a brief with seeded choices. In **Full Director
Mode** you (Claude) direct it shot by shot in `shots.json`; the engine renders what you decided.

```
shots.json → validation → shot compiler → existing VideoSpec → structural QC → animatic (½ size, 15 fps)
          → motion metrics → motion review → final render → final QC + motion metrics
```

```bash
npx tsx cli/nitaaq.ts create brief.json --shots shots.json
npx tsx cli/nitaaq.ts direct brief.json --shots shots.json --project <dir>   # plan only
```

The brief still supplies brand, assets, audio and copy. The script supplies the direction.

## Rules

- **A reason for every decision.** A camera move without `cameraReason`, a transition without
  `transitionReason`, or a motion-chain event without `reason` is a validation error.
- **Every shot but the last has a `transitionOut`.** A hard cut is a decision too (`"cut"`).
- **The script wins.** In Full Director Mode no random choice overrides a camera move,
  transition, typography family, variant or timing the script specifies. What the script leaves
  out is filled deterministically by the engine and listed in `shot_compile_report.json`
  (`decisions[].source = script | engine | mapped | fallback | voice`).
- **Nothing is dropped silently.** An unknown camera move or transition maps to the nearest one
  that exists; an unknown variant falls back to the family's variant for this aspect; anything the
  engine cannot do yet is recorded as a warning.
- **Better directed, not more.** Sustain motion is for things that should feel alive; text that
  has to be read stays settled. Declare a deliberate still frame with `hold` instead of filling it.

## Shot fields

| field | meaning |
|---|---|
| `id` | lowercase id (`hook`, `demo`, …) |
| `purpose` | narrative job: hook, problem, solution, demo, feature, process, proof, offer, brand, cta, … |
| `message` | the one thing the viewer must take from the shot |
| `voiceAnchor` | `{ text }`: the words spoken during this shot (found in the voice map), or `{ start, end }` film seconds |
| `timing` | `{ duration, minHold }`; required when there is no voice anchor. With a voice, the voice wins |
| `subject` | what the eye should land on |
| `shotSize` | wide · medium · close · extreme-close · insert (needs `cameraTarget` to frame) |
| `composition` | free text, recorded |
| `sceneFamily`, `variant` | an existing scene family (`npx tsx cli/nitaaq.ts scenes`) |
| `elements` | the family's content (its own schema); omitted → built from the brief by the family's recipe |
| `motionIntent` | why things move in this shot |
| `motionChain[]` | `{ element, action: enter/emphasis/sustain/exit, at, style, direction, velocity, reason }` |
| `camera` | `"static"`, a move/preset name, or `{ move, amplitude, startAt, endAt, ease, accents }` |
| `cameraTarget`, `cameraReason` | the element the camera serves (headline, logo, screenshot, a word …) and why it moves |
| `typography` | `{ headline, support, cta, label }` text motion families |
| `emphasisWords` | words to accent; with a voice they pulse when spoken |
| `transitionOut`, `transitionTarget`, `transitionReason` | the cut, the next shot's id, and why |
| `audioCues` | recorded; the Sound Director still places cues (cue authoring is P1) |
| `continuity` | recorded (element persistence across shots is P1) |
| `expectedEnergy` | 0..1 → scene intensity |
| `hold` | `{ reason, maxSec }`: a deliberate still hold (Motion Metrics counts it as intentional up to `maxSec`) |

Times inside a shot (`at`, `startAt`, `endAt`, `accents`) are scene-local seconds or a spoken word:
`"word:منصة"`.

## What each decision becomes

| script | engine |
|---|---|
| camera move / preset | `motion.cameraPlan` (move, amplitude, start/end, ease, accents, reason) |
| `cameraTarget` + `shotSize` | measured with DOM probes on the settled frame → camera `focus`; medium/close sizes add a solver framing (`camera_targets.json`) |
| transition | `transition` (type, duration, reason); `shared` → `scale-match` (P1: measured persistence) |
| typography | `motion.text` |
| motion chain sustain / exit / hold | `motion.lifecycle` (principled model) |
| emphasis words | `motion.lifecycle.emphasis` (voice-timed when found) + the copy's `highlight` (only words that occur in it) |
| voice anchors | shot durations: the next shot is on screen 0.12 s before its words begin |
| voice emphasis | scene accents (voice first); music downbeats stay as secondary micro accents |

Full Director Mode also sets `motion.model = "principled"` (anticipation → entrance → settle →
sustain → exit/handoff in the shared components) and `metadata.director.mode = "full"`. Fast Mode
keeps the legacy motion model, so older projects render exactly as before.

## Not in P0

Stage composition (per-element entrance timing), element persistence / global camera, object
morphs, a rebuilt transition set, audio cue authoring and a full motion critic are later phases.
The compiler records these requests as warnings instead of pretending.
