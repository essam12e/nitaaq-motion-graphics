# Character Motion Engine

The character is an **actor**, not decoration. For every shot the engine answers: what does the character know, feel and do, where does it look, what should the audience look at, and what is the one gesture that matters. Then it combines **pose + expression + gesture + camera + typography + graphics + sound**. A strong pose with good camera direction beats unnecessary full-body animation.

Code: `src/character/` (pure: schema, director, actor, layout, rig, gestures, library, semantics, silhouette), `src/node/character/` (prepare / cache / package, sheet + PNG ingest, SVG → rig, film assembly, acting sheet), `src/scenes/character/` (5 scene families), `src/qc/character-qc.ts`. Module `character` (lazy; loaded only when the brief has `character`). Remotion stays the render engine.

## Pipeline

```
brief.character ─► INTAKE (sheet / PNG poses / layered SVG / single PNG / saved package)
  ─► CACHE LOOKUP  .cache/nitaaq-motion/characters/<hash>/   (hit → no re-analysis)
  ─► POSES (crop, matte, silhouette analysis, state + gesture + prop, anchors)
  ─► RIG (layered SVG only: parts, hierarchy, pivots, face states)
  ─► CHARACTER BIBLE + POSE LIBRARY + identity lock + contact sheet
  ─► SCRIPT ANALYSIS (content.characterScript, or derived from hook / problem / solution / cta)
  ─► CHARACTER DIRECTOR (intent per line → state machine phases, pose choice, shot size, camera, cut)
  ─► CHARACTER ACTOR (curves: anticipation, overshoot, overlap, secondary motion, idle, talk)
  ─► SCENE DIRECTOR (character-stage / phone / product / data / cta, RTL screen direction)
  ─► SOUND EVENTS (exact anchors from the Actor's own curves → Sound Director)
  ─► ANIMATIC + ACTING SHEET ─► CHARACTER QC ─► REPAIR ─► PRODUCTION RENDER ─► MP4
```

## Input levels

| Level | Brief | What you get | Ceiling |
|---|---|---|---|
| A — character sheet | `character.sheet` (+ optional `sheetLabels`, `crops`) | figures auto-detected, cropped, matted, classified (state, gesture, prop, facing) | POSE_BASED |
| B — PNG poses | `character.poses: [{ path, label? }]` | one pose per file; labels / file names / silhouette decide the state | POSE_BASED |
| C — layered SVG | `character.svg` | a rig (head, arms, face states, headwear) → 17 rig poses, real gestures | PARTIAL / FULL_VECTOR_RIG |
| D — single PNG | `character.image` | one pose; camera, framing, breathing, 2.5D, overlays — **no new gestures** | STATIC |
| saved | `character.use: "<name>"` | the package saved earlier with `saveAs` (no re-analysis) | as saved |

Everything runs locally. Nothing is uploaded (no remove-bg API, no cloud vision). No paid API is required.

## Character Director (intent) vs Character Actor (execution)

- **Director** (`director.ts`): `readLine()` reads each line (Arabic-aware cue lexicon, word boundaries with clitics): question → questioning, «وش الحل؟», «شوف هنا» → pointing, «وصلتني رسالة» → looking_phone, CTA → presenting, problem words → confused / worried, etc. An explicit `action` / `pose` / `scene` in the beat always wins. It then plans each shot: phases from the state machine `IDLE → NOTICE → THINK → REACT → TALK → PRESENT → RETURN_TO_IDLE`, the pose (missing-pose strategy, see CHARACTER_POSES.md), shot size (wide / medium / medium-close / close), camera move, mirroring (only when the art allows it), and the **cut** between poses.
- **Actor** (`actor.ts`): turns a shot into frames. Closed-form damped springs per personality, anticipation before the action, limb overshoot halved, overlapping action (lower arm 0.05 s, hand 0.09 s, head 0.07 s, headwear 0.12 s drag), headwear follow-through driven by head angular velocity, blinks (seeded), breathing, idle presets (casual, premium, energetic, thinking, listening), talking levels 0–3, landing squash, reaction pop. It also reports every event with **exact** anchors (start, peak, contact, settle, completion).

## Pose transitions — intentional, never morphing

| Cut | When | Rendered as |
|---|---|---|
| continuous | rig: same character, new pose → joints rotate through the motion | no cut |
| match-cut | similar silhouettes / same framing | `match-cut` 0.14 s |
| camera-assisted | shot size changes | `camera-push` 0.35 s |
| whip | big energy change (surprise, excitement) | `whip` 0.3 s |
| occlusion | a phone / card sweeps across the body | occlusion sweep in the scene |
| cut-on-action | PNG poses: cut at the gesture peak + settle | hard cut + settle |

## Scenes

| Family | Variants | Use |
|---|---|---|
| `character-stage` | side, bubble, title | talk, react, think, point, present; kinetic typography (`title`) |
| `character-phone` | phone, chat | phone in hand, mock app screen, chat bubbles, typing |
| `character-product` | present | the user's product image at the hand anchor (never altered) |
| `character-data` | stat, bars | the user's number / series with its source (nothing invented) |
| `character-cta` | button, logo | final call to action |

Screen direction (RTL): landscape and 1:1 → character on the left looking at the text on the right; portrait / 4:5 → text above, character below. Kept for the whole film.

## User control phrases

Write them into the brief: «خلي الحركة بسيطة» → `character.motion: "subtle"`, «مبالغ فيها» → `"exaggerated"`, «لا تحرك الوجه» → `lockFace: true`, «بدون كلام» → `talk: 0`, «خلي الشخصية يمين» → `side: "right"`. Per beat: `action`, `emotion`, `pose`, `prop`, `camera`, `scene`, `messages`, `seconds`.

## Brief example

```json
{
  "request": "فيديو موشن بشخصية سعودية يشرح تطبيق توصيل",
  "language": "ar", "dialect": "saudi", "platform": "tiktok",
  "character": { "sheet": "abu-fahad-sheet.png", "name": "أبو فهد", "saveAs": "abu-fahad" },
  "content": {
    "characterScript": [
      { "line": "تعبت من الزحمة كل يوم؟" },
      { "line": "وش الحل؟" },
      { "line": "تطبيق مشوار يوصلك بسرعة", "scene": "phone" },
      { "line": "وصلتني رسالة من المندوب", "messages": ["المندوب عند الباب", "تمام، جاي"] },
      { "line": "شوف هنا كل شي واضح" },
      { "line": "حمّل التطبيق الآن", "scene": "cta" }
    ],
    "ui": { "appName": "مشوار", "headline": "وين تبي تروح؟", "items": ["البيت", "الدوام", "المطار"] },
    "cta": { "text": "حمّل التطبيق الآن", "button": "حمّل مجاناً" }
  }
}
```

No `characterScript`? The Director derives the beats from `hook`, `problem`, `solution`, `features`, `stats`, `cta`.

## Files written per project

`character/` (copy of the package: `character.json`, `CHARACTER_BIBLE.md`, `bible.json`, `pose-library.json`, `anchors.json`, `rig.json`, `poses-contact.png`), `character_plan.json` (every shot: intent, pose, match, camera, cut, phases), `character_direction.md` (readable direction notes), `qc/character-acting.png` (acting sheet, from `animatic`).

## CLI

```bash
npx tsx cli/nitaaq.ts character prepare <brief.json | sheet.png --as sheet | pose-folder | char.svg>   # package + bible + contact sheet
npx tsx cli/nitaaq.ts character inspect <package-dir>
npx tsx cli/nitaaq.ts character bench   <same inputs>     # cold vs warm preparation
npx tsx cli/nitaaq.ts animatic <projectDir>               # fast preview + qc/character-acting.png
npx tsx cli/nitaaq.ts character sheet <projectDir> [--video final.mp4]
npx tsx cli/test-characters.ts [--only a,f]               # acceptance tests A–J + benchmark
```

See also: CHARACTER_FORMAT.md · CHARACTER_POSES.md · CHARACTER_RIGGING.md · CHARACTER_QC.md · CHARACTER_PERFORMANCE.md · CHARACTER_TROUBLESHOOTING.md.


---

# Character Package Format (`nitaaq.character/1`)

A prepared character is a folder. It is portable (copy it to another machine, or point `character.use` at it) and is what the cache and the character library store.

```
<package>/
  character.json         manifest (written LAST — an interrupted run never looks complete)
  CHARACTER_BIBLE.md      human-readable bible (identity lock, poses, capabilities, behaviour)
  bible.json              the same, structured
  pose-library.json       byState / byGesture / byProp / byExpression indexes
  anchors.json            poseId → anchors (fractions of the pose image)
  anchors.override.json   manual anchor corrections (optional, survive re-analysis)
  rig.json                layered SVG rig (level C only)
  poses/<poseId>.png      transparent, trimmed pose images (PNG levels)
  thumbnails/<poseId>.png + thumbnails/contact.png   pose contact sheet
```

Where it lives:

- cache: `.cache/nitaaq-motion/characters/<hash>/` (or `$NITAAQ_CACHE/characters/…`). The hash covers the engine version (`ce-1.0.0`), the bytes of every source file, labels and crops — the same art is never analysed twice, changed art is never served stale.
- library: `<workspace>/characters/<name>/` when the brief says `"saveAs": "<name>"`; reuse with `"use": "<name>"` (or a folder path).

## `character.json` (manifest, abridged)

| field | meaning |
|---|---|
| `schema`, `engineVersion`, `characterId`, `name`, `sourceType` | identity of the package; `sourceType` ∈ sheet, poses, svg, single, package |
| `poses[]` | `poseId`, `file`, `source{asset, rect, label}`, `width`, `height`, `angle`, `expression`, `gesture`, `handState`, `prop`, `bodyDirection`, `headDirection`, `energy`, `semantics{state, confidence, evidence[]}`, `anchors`, `fingerprint`, `framing`, `rigPose` (rig) |
| `palette`, `lighting`, `style` | measured visual identity |
| `hasRig`, `animationCapabilities` | `complexity` ceiling (STATIC / POSE_BASED / PARTIAL_RIG / FULL_VECTOR_RIG), `headSeparable`, `blink`, `mouthStates`, `expressionLayers`, `armRig` |
| `allowedActions`, `restrictedActions`, `preferredCameraAngles` | what the Director may and may not ask for (e.g. «new arm gestures» restricted for flat PNGs, «mirroring» restricted for asymmetric art) |
| `identity` | palette + garments + lock rules (see CHARACTER_QC.md) |

## Anchors (per pose, fractions of the image)

`headTop`, `headCenter`, `neck`, `shoulderL/R`, `elbowL/R?`, `wristL/R?`, `handL/R`, `torsoCenter`, `hips`, `feet`, `headHeight` (scale reference: the engine sizes characters in pixels-per-head, never by bounding box), `confidence`, `source` (auto / rig / manual), `headSeparable`.

Manual correction in the brief (wins over detection, persisted in `anchors.override.json`):

```json
"character": { "poses": [...], "anchors": { "holding-phone": { "handR": { "x": 0.71, "y": 0.52 } } } }
```

## Brief fields (`brief.character`)

`use`, `name`, `sheet`, `sheetLabels[]`, `crops[{x,y,width,height,label?}]`, `poses[{path,label?}]`, `svg`, `image`, `saveAs`, `anchors`, `motion` (subtle / normal / exaggerated), `lockFace`, `talk` (0–3), `side` (left / right / center), `garments[]`. Beats: `content.characterScript[]` (1–24) with `line`, `action?`, `emotion?`, `pose?`, `prop?`, `camera?`, `scene?` (stage, phone, chat, product, chart, title, cta), `messages?`, `seconds?`.

## In `video.json`

`video.character` carries what the renderer needs: `id`, `name`, `complexity`, `mode` (rig | poses), `poses{poseId → asset, width, height, state, bodyDirection, framing, prop, anchors, headHeight}`, `rig`, `identity{palette, garments, lock}`. Pose PNGs are ingested as `avatar` assets (`char-<poseId>`), byte-identical, never edited.


---

# Poses and the Pose Library

## Recommended character sheet (a recommendation, not a requirement)

8–12 useful states, full body, same scale, same outfit, on a plain or transparent background, with some space between figures:

1. Neutral · 2. Happy · 3. Surprised · 4. Confused · 5. Thinking · 6. Talking · 7. Pointing · 8. Presenting · 9. Holding phone · 10. Looking at phone · 11. Excited · 12. Listening

Labels under each figure («محتار»، "pointing") help; `sheetLabels` in reading order also works. Fewer poses still work — the Director substitutes (below).

## Extraction (sheet)

`detectSheet()` (local, sharp): background colour from the border → flood-fill matte → connected components → figure regions (text labels and small marks are ignored) → reading-order sort → crop + trim each figure. If detection is unsure it does **not** guess: it falls back to `crops` (manual crop manifest) or single-pose mode and says so in the warnings.

## Classification

Each pose gets `semantics.state` with a confidence and evidence from:

1. its label / file name (Arabic + English words: «يشير»، "pointing", «جوال», "phone" …), and
2. its silhouette (arm reach and height per side, symmetry, hand near face, a dark rectangular prop near a hand, facing).

Conflicts between label and silhouette are reported (`<pose>: label says X, silhouette suggests Y`). States: neutral, idle, thinking, confused, surprised, happy, excited, talking, listening, pointing, presenting, holding_phone, looking_phone, typing, celebrating, explaining, warning, questioning.

## Missing-pose strategy (`choosePose`)

1. the exact state exists → use it (mirror it toward the text when allowed)
2. a rig can perform it safely → rig pose
3. another state communicates the same intent → substitute (e.g. pointing → presenting → explaining)
4. composition hides the limit → closest valid pose + tighter shot + a graphic (thought bubble, «؟», «!», a phone card)
5. only then → ask for more artwork (`needsArt` in `character_plan.json` and the direction notes)

The character is never deformed, re-drawn or stretched to fake a pose.

## Single PNG (level D) — honest limits

Possible: camera framing (wide → close), push / pull / drift, 2.5D parallax, breathing, subtle sway, entrance / exit, overlays, speech bubbles, typography beside the character.
Not possible (and never faked): new arm gestures, expression changes, lip sync, turning around. A «شوف هنا» line with a single image keeps the character as drawn and puts the line beside it — no pointing layout, no invented arm.

## Pose library (`pose-library.json`)

`byState`, `byGesture`, `byProp`, `byExpression` → poseIds, plus `uses` per pose (establishing shot, reaction, CTA …). The Director reads it; you can read it to see what the art supports.


---

# Rigging (layered SVG)

`svgToRig()` reads the artist's groups and builds a lightweight 2D rig. No external tool, no upload.

## Naming

Group ids / Inkscape labels / `data-name` are mapped to logical parts (English or Arabic, any case or separator):

| part | names it understands (examples) |
|---|---|
| torso | torso, body, chest, thobe, thawb, dishdasha, shirt, abaya, ثوب, جسم, بشت |
| head / neck | head, face, رأس, وجه · neck, رقبة |
| headwear | ghutra, shemagh, keffiyeh, agal, iqal, hijab, cap, غترة, شماغ, عقال, حجاب, طاقية |
| arms | upperArm L/R, lowerArm / forearm L/R, hand L/R, arm L/R, عضد, ساعد, يد, كف (+ يمين / يسار) |
| face | eyes, eyebrows, mouth, nose, beard, عين, حاجب, فم, لحية |
| legs / hips | legs, feet, shoes, ساق, قدم · hips, waist |
| props | phone, mobile, laptop, product, جوال |

Sides are **image** sides (screen left / right). Nesting in the SVG defines the hierarchy; otherwise anatomical defaults are used (hand → lower arm → upper arm → torso; headwear → head → neck → torso).

Face states: child groups with `data-state="open"` (or ids like `mouth-open`, `eyes-closed`) become swappable states (blink, talk, expressions).

Manual pivots: `data-pivot="x,y"` (viewBox units) on a group overrides detection.

## Modes

- **full** — head, both arms (upper / lower / hand), face states → FULL_VECTOR_RIG: real gestures (point with an aim angle, present, hold phone in the hand that holds it, type, shrug, hand on chin, celebrate, wave, thumbs up, stop, explain).
- **partial** — some parts (e.g. head only) → PARTIAL_RIG: head tilt / turn, blink, the rest as drawn.
- **grouped** — no recognisable parts → the whole artwork moves as one (pose-based camera and idle); never an error.

Each part's geometry is measured by rasterising it alone (transforms, clip paths and strokes included). Joint limits keep elbows and heads within natural ranges. Secondary motion: the headwear follows the head with a lag and settles (follow-through), the lower arm and hand drag behind the upper arm (overlapping action).

## Fixtures

`test/fixtures/characters/saudi/saudi-layered.svg` (full rig: thobe, shemagh, agal, face states, phone) and `saudi-flat.svg` (grouped fallback) are generated by `cli/make-character-assets.ts`, which also renders the PNG poses, the 12-pose sheet and the single image used by the tests.


---

# Character QC

The character is checked like a user asset (a logo, a product photo), not like decoration. Checks run inside the normal staged QC (`src/qc/quality.ts` → `src/qc/character-qc.ts`); the probe (`QCProbe`) reports every character on sampled frames: pose, mode, shot size, pixels-per-head, mirror, side, text side, head box, ground line.

## Structural (DOM probe, settled frames)

| code | severity | what | repair |
|---|---|---|---|
| `CHARACTER_MISSING` | critical | a character scene shows no character on any settled frame | — (not delivered) |
| `CHARACTER_HEAD_CROPPED` | error / warning | the head leaves the frame / the top of the head is cut | shrink layout |
| `CHARACTER_TEXT_ON_FACE` | error | a visible text block covers > 12 % of the face | shrink layout |
| `CHARACTER_SCALE_DRIFT` | warning | the same shot size renders the character at sizes > 8 % apart (grouped by mode and shot size; shots that share the frame with a graphic are their own group) | — |
| `CHARACTER_FACING_AWAY` | warning | a PNG pose looks away from the text it presents (mirroring considered) | — |

## Identity (rendered pixels)

`CHARACTER_IDENTITY` — the character's own palette (measured from the art) must be present inside its box on the rendered frame: none of the identity colours → **critical** (the art is hidden, recoloured or replaced); only one of several → warning.

## Identity lock (enforced by construction)

Written into the bible and respected by the engine:

- never regenerate, redraw, recolour or restyle the character; scale is always uniform (x = y, unit-tested)
- face, proportions, skin tone, outfit and accessories exactly as supplied
- cultural garments detected or declared (`garments`) are protected: thobe, shemagh / ghutra (pattern, colours, drape), agal, bisht, abaya, hijab …
- mirroring only when the art is symmetric enough (asymmetric art: `mirroring` is a restricted action)
- pose PNGs are byte-identical copies; the rig only moves the artist's own groups

## Design QC adaptations for character films

- the character's own patterns (e.g. the shemagh checks) are masked from the dot / grid detector — they are the user's art, not a banned background
- transition monotony is not flagged when every cut is a planned pose cut; same-family back-to-back is flagged only when the pose and variant repeat too

## Review it yourself

QC 100 is not the end. Look at:

- `qc/character-acting.png` — one settled frame per shot with state → pose, match, camera, cut
- `character/poses-contact.png` — the pose library as analysed
- the motion strip: `ffmpeg -i film.mp4 -vf "fps=4,scale=150:-1,tile=13x6" -frames:v 1 strip.png`

What to look for: the same person in every shot (face, garments, colours), one size per shot size, eyes / hands toward the text, props in the hand that holds them, no text on the face, no arm under the text.


---

# Character Performance

Measured, not claimed. Numbers below come from `npx tsx cli/test-characters.ts` (writes `benchmark.json`) on the 4-CPU build container, 2026-10-04.

## Character preparation: cold vs warm

Fresh cache folder, the same art prepared twice (`prepareCharacter`):

| input | poses | cold | warm | warm result |
|---|---|---|---|---|
| single PNG | 1 | 199 ms | 1 ms | cache hit |
| character sheet (12 figures) | 12 | 1449 ms | 1 ms | cache hit |
| 12 PNG poses | 12 | 1148 ms | 1 ms | cache hit |
| layered SVG (rig) | 17 rig poses | 1542 ms | 2 ms | cache hit |

Cold stages (ms): sheet = detection 860 + pose analysis 323 + thumbnails 249; poses = intake / matte 500 + analysis 333 + thumbnails 297; SVG = rig 610 + pose analysis 398 + thumbnails 514.

A warm run loads `character.json`, `pose-library.json`, `bible.json` and `rig.json` and nothing else: no re-cropping, no silhouette analysis, no SVG rasterisation. The cache key covers the engine version and the bytes of every source file, so changed art is re-analysed and unchanged art never is. `npx tsx cli/nitaaq.ts character bench <art>` measures any character the same way.

## In the film pipeline

The `character` stage in `performance_report.json` (prepare + direct + copy the package into the project): 0.005–0.13 s on a cache hit, 1.5–1.9 s on a miss. Rendering dominates. Acceptance films (10–29 s, production profile): animatic 6.5–16.9 s, production render 18.7–44 s for 10–20 s films and 70 s for the 29 s social ad (`character-results.json`).

## What keeps it fast

- **Lazy module:** `src/node/character/*` and the character scenes' heavy work load only when the brief has `character`.
- **Cache + library:** `.cache/nitaaq-motion/characters/<hash>/`; `saveAs` / `use` for a named, portable package.
- **Rig mode renders vector:** the rig solve is a few matrix multiplications per part per frame (pure; target poses memoised per shot); no per-frame rasterisation.
- **Pose mode renders images:** each pose is a byte-identical PNG asset, decoded once by the browser.
- **Planning is pure and deterministic:** the Director and Actor are closed-form (springs, curves) — no simulation state, so any frame can be rendered alone (parallel workers, cached QC probes).
- **Complexity class:** the lowest sufficient class is used (STATIC → POSE_BASED → PARTIAL_RIG → FULL_VECTOR_RIG); a single image never pays for rigging.
- **Fast preview:** `animatic` (half size, 15 fps) + `qc/character-acting.png` before the production render.


---

# Character Troubleshooting

| symptom | cause | fix |
|---|---|---|
| `character file not found` | path in `brief.character` is wrong (paths are relative to the brief) | fix the path |
| `automatic sheet detection found 1 figure(s) … single-pose mode` | figures touch each other, or the background is busy | add `character.crops` (x, y, width, height in sheet pixels, reading order), or export the poses as separate PNGs |
| a pose is classified wrongly | no label, ambiguous silhouette | label it (`poses[].label`, `sheetLabels`) or name the file («character-pointing.png»); the label wins and the conflict is reported |
| `<pose>: low-confidence anchors` | unusual proportions / cropped art | props go on a foreground card instead of the hand; correct with `character.anchors` |
| `colours differ from <pose>` | one pose has a different outfit or colour grade | check it is the same character; otherwise remove that pose |
| the SVG character does not move its arms | layers not named / grouped | name the groups (see CHARACTER_RIGGING.md); without parts it runs in grouped mode (moves as one) |
| an arm bends the wrong way | a wrong pivot | add `data-pivot="x,y"` to that group |
| «شوف هنا» but the character does not point | single image or no pointing pose | expected: the engine never invents a gesture; add a pointing pose or a layered SVG |
| the character is small next to the phone / chart | shared frame by design (graphic layouts are a separate size group) | use `camera: "medium-close"` on that beat or let the phone carry the shot |
| text over the face (`CHARACTER_TEXT_ON_FACE`) | very long line in a tight shot | shorten the line; the repair loop shrinks the layout once |
| mirrored pose looks wrong (logo / text on clothes flipped) | art is asymmetric | the analyser restricts mirroring for asymmetric art; add a pose facing the other way |
| the second film still re-analyses | the art bytes or labels changed, or the engine version changed | expected; otherwise check `NITAAQ_CACHE` points to the same folder |
| talking level 3 requested | phoneme lip sync needs mouth shapes per phoneme + alignment | level 2 (voice-energy mouth) is used and reported |

Logs: the `[CHARACTER]` stage line shows source, pose count, complexity, cache (hit / miss) and the state → pose of every shot. Details: `character_direction.md`, `character_plan.json`, and the package's `CHARACTER_BIBLE.md`.
