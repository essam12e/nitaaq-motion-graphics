/**
 * nitaaq — NITAAQ | Motion Graphics CLI (shared by the Claude Code and Codex adapters).
 *
 *   nitaaq create   <brief.json> [--shots shots.json] [--profile production] [--no-logo] [--out dir] [--name file] [--clean-voice]
 *   nitaaq direct   <brief.json> [--shots shots.json] [--project dir] [--no-logo]   → plan.json, storyboard.json, video.json
 *                   --direction direction.json: Stage mode (P1) — required when shots.json has a "stage"
 *                   --film film_plan.json: P3 Film Director — the film plan (motifs, phrases, sequences, arcs); without it a plan is derived for analysis only
 *                   --shots: Full Director Mode (Claude-authored shot script → voice map → animatic → motion metrics → final)
 *   nitaaq produce  <projectDir|video.json> [--profile …] [--animatic]  → staged QC + repair + render + final QC
 *   nitaaq animatic <projectDir|video.json>                            → structural QC + sheets + half-size 15 fps animatic
 *   nitaaq redirect request <projectDir>                  → redirection_request.json (critic, diagnosis, capabilities, style frames) for Claude
 *   nitaaq redirect apply <projectDir> <redirection.json>  → applied / mapped / rejected report, shots recompiled (P2-E)
 *   nitaaq validate <video.json> [--fix]
 *   nitaaq render   <projectDir|video.json> [--profile preview|animatic|draft|production] [--out file.mp4] [--no-cache]
 *   nitaaq quality  <projectDir|video.json> [--video file.mp4]
 *   nitaaq metrics  <file.mp4> [--project dir] [--compare before.json] [--out motion_metrics.json]  → motion metrics (still ratio, holds, energy, camera, …)
 *   nitaaq voice-map <audio> [--transcript text|file] [--offset s] [--engine auto|whisper|silence] [--out voice_map.json]  → word-level voice timing (local)
 *   nitaaq brand    <logo> [--name …]
 *   nitaaq recompose <projectDir> [--aspects 9:16,16:9,1:1,4:5] [--render false]  → re-laid-out formats (not crops)
 *   nitaaq beats    <audio>                   → BPM, beats, downbeats, onsets, energy (cached by hash)
 *   nitaaq reference <image|video|url>        → reference_style.json (principles, never copied)
 *   nitaaq capture  <url> [--mobile]           → real website screenshot
 *   nitaaq classify <brief.json>               → SIMPLE / STANDARD / ADVANCED / LONG_FORM + budget
 *   nitaaq cache    [summary|clear [namespace]]
 *   nitaaq character prepare|inspect|bench <brief.json|art|package>   → character package (cached), bible, pose contact sheet
 *   nitaaq character sheet <projectDir> [--video f]                    → acting sheet: one settled frame per character shot
 *   nitaaq seek     <projectDir|video.json> <seconds> [--png [out.png]] [--scale 0.5]  → the film's exact state at t (deterministic)
 *   nitaaq video    probe <file> | prepare <file> --project <dir> [--id] [--segment <sec>] [--proxy auto|always|never] [--loop] [--rate <x>]
 *                   → Video Asset Pipeline: probe, normalise (CFR H.264), preview proxy, best segment (cached)
 *   nitaaq lottie   inspect <file.json|.lottie> | prepare <file> --project <dir> [--id] [--kind lottie|logo|icon] [--marker <name>] [--loop] [--rate <x>]
 *   nitaaq vector   inspect <file.svg> | prepare <file.svg> --project <dir> [--id] [--kind svg|logo|icon|image] | frame <graph.json> <t> (SVG of a vector graph at t)
 *                   → Lottie: inspect (timing, markers, refusals), ingest unchanged + self-contained copy (cached)
 *   nitaaq audio    index | search <query> [--kind sfx|music] [--online] | fetch <query> [--provider ogsi|atomcut]
 *                   → local audio registry (CC0 library + generated + yours); online CC0 fallback only with NITAAQ_AUDIO_ONLINE=1
 *   nitaaq preflight [--full] | scenes [--json] | styles | schema-export [--out dir] | voices
 *
 * Exit codes: 0 ok · 1 failed · 2 needs user input (questions printed as JSON).
 */
import { existsSync, mkdirSync, readdirSync, readFileSync, statSync, writeFileSync } from 'node:fs';
import { basename, dirname, extname, join, resolve } from 'node:path';
import { zodToJsonSchema } from 'zod-to-json-schema';
import { formatMotionError, isMotionError } from '../src/core/errors';
import { log } from '../src/core/logger';
import { SceneRegistry } from '../src/scenes';
import { STYLE_PRESETS } from '../src/styles/presets';
import { VideoSchema } from '../src/schema/video';
import { BriefSchema, VARIANT_STRATEGIES } from '../src/schema/brief';
import { CreativePlanSchema, StoryboardSchema } from '../src/schema/plan';
import { validateSpec, summarize } from '../src/validation/validate';
import { repairSpec } from '../src/validation/repair';
import { loadSpec, nodeValidateOptions, renderVideo, closeBrowser, RENDER_PROFILES, type RenderProfile } from '../src/node/render';
import { cacheSummary, clearCache } from '../src/cache/store';
import { Perf } from '../src/perf/timer';
import { runQuality } from '../src/qc/quality';
import { produce } from '../src/node/produce';
import { direct } from '../src/node/direct';
import { preflightFast } from '../src/node/preflight';
import { recomposeProject } from '../src/node/recompose';
import { planVariants } from '../src/director/variants';
import { beatsFor } from '../src/node/beats';
import { analyzeReference } from '../src/reference/analyze';
import { captureWebsite } from '../src/node/capture';
import { classifyBrief } from '../src/director/classify';
import { intake } from '../src/director/intake';
import type { Aspect } from '../src/layout/canvas';
import { brandFromLogo } from '../src/brand/logo-analyzer';
import { voiceProviders } from '../src/node/tts';
import { workspace, ROOT } from '../src/node/workspace';

const argv = process.argv.slice(2);
const cmd = argv[0];
const pos: string[] = [];
const flags = new Map<string, string>();
for (let i = 1; i < argv.length; i++) {
  const a = argv[i];
  if (a.startsWith('--')) {
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) flags.set(a.slice(2), 'true');
    else flags.set(a.slice(2), argv[++i]);
  } else pos.push(a);
}
const flag = (k: string) => flags.get(k);
const profileOf = (d: RenderProfile): RenderProfile => {
  const p = (flag('profile') ?? d) as RenderProfile;
  if (!RENDER_PROFILES.includes(p)) throw new Error(`--profile must be one of ${RENDER_PROFILES.join(', ')} (got ${p})`);
  return p;
};
/** Accepts a project folder or a video.json path. */
function project(arg: string | undefined): { dir: string; spec: string } {
  if (!arg) throw new Error('Missing project folder or video.json path');
  const p = resolve(arg);
  if (existsSync(p) && statSync(p).isDirectory()) return { dir: p, spec: join(p, 'video.json') };
  return { dir: dirname(p), spec: p };
}
const out = (o: unknown) => process.stdout.write(JSON.stringify(o, null, 2) + '\n');

async function main(): Promise<number> {
  switch (cmd) {
    case 'preflight': {
      const r = preflightFast({ full: flag('full') === 'true' });
      log.info('PREFLIGHT', `${r.cached ? 'cached result (nothing changed since the last full check)' : 'full check'} in ${r.ms} ms`);
      for (const c of r.checks) log.info('PREFLIGHT', `${c.ok ? '✓' : c.level === 'optional' ? '·' : '✗'} ${c.id}: ${c.detail}${!c.ok && c.action ? ` → ${c.action}` : ''}`);
      log.info('PREFLIGHT', r.ok ? 'ready' : 'not ready — fix the ✗ items above');
      return r.ok ? 0 : 1;
    }
    case 'redirect': {
      const [sub, dirArg, redFile] = pos;
      const dir = resolve(dirArg ?? '.');
      const { RedirectionSchema, applyRedirection, CAPABILITIES } = await import('../src/stage/redirection');
      const shots = JSON.parse(readFileSync(join(dir, 'shots.json'), 'utf8'));
      if (sub === 'request') {
        const { diagnoseShot } = await import('../src/stage/redirector');
        const critic = JSON.parse(readFileSync(join(dir, 'critic.json'), 'utf8'));
        const gate = existsSync(join(dir, 'style_frame_gate.json')) ? JSON.parse(readFileSync(join(dir, 'style_frame_gate.json'), 'utf8')) : null;
        const stage = JSON.parse(readFileSync(join(dir, 'stage.json'), 'utf8'));
        const req = {
          version: 1,
          task: 'Re-direct the shots the critic failed. Answer with redirection.json (schema below): per shot a diagnosis and a change of ORGANISATION (strategy, shot size, subject, roles, placement, depth, motion, camera, transition, timing). Never code, never new copy.',
          capabilities: CAPABILITIES,
          schema: (await import('zod-to-json-schema')).zodToJsonSchema(RedirectionSchema),
          critic: { overall: critic.overall, verdict: critic.verdict, shots: critic.shots, issues: critic.issues },
          diagnosis: critic.shots.filter((x: { overall: number }) => x.overall < 7).map((x: { shot: string }) => diagnoseShot(critic, shots, x.shot)),
          shots: shots.shots.map((x: Record<string, unknown>) => ({ id: x.id, purpose: x.purpose, message: x.message, subject: x.subject, shotSize: x.shotSize, composition: x.composition, cast: x.cast, camera: x.camera, cameraReason: x.cameraReason, transitionOut: x.transitionOut, transitionReason: x.transitionReason, metaphor: x.metaphor })),
          compositions: stage.shots.map((x: { id: string; composition: unknown }) => ({ shot: x.id, composition: x.composition })),
          styleFrames: existsSync(join(dir, 'style_frames')) ? readdirSync(join(dir, 'style_frames')).map((f) => join(dir, 'style_frames', f)) : [],
          gate: gate?.rounds?.[gate.rounds.length - 1] ?? null,
          previousAttempts: existsSync(join(dir, 'repair_memory.json')) ? JSON.parse(readFileSync(join(dir, 'repair_memory.json'), 'utf8')).attempts : [],
        };
        writeFileSync(join(dir, 'redirection_request.json'), JSON.stringify(req, null, 2));
        out({ request: join(dir, 'redirection_request.json'), shots: req.diagnosis.map((d: { shot: string }) => d.shot) });
        return 0;
      }
      if (sub === 'apply') {
        if (!redFile) throw new Error('Usage: nitaaq redirect apply <projectDir> <redirection.json>');
        const parsed = RedirectionSchema.safeParse(JSON.parse(readFileSync(resolve(redFile), 'utf8')));
        if (!parsed.success) {
          out({ ok: false, errors: parsed.error.issues.map((i) => `${i.path.join('.')}: ${i.message}`) });
          return 1;
        }
        const { script, report } = applyRedirection(shots, parsed.data);
        writeFileSync(join(dir, 'shots.redirected.json'), JSON.stringify(script, null, 2));
        writeFileSync(join(dir, 'redirection_apply.json'), JSON.stringify(report, null, 2));
        const src = JSON.parse(readFileSync(join(dir, 'stage_source.json'), 'utf8'));
        const direction = JSON.parse(readFileSync(join(dir, 'direction.json'), 'utf8'));
        await direct({ brief: src.brief, baseDir: src.baseDir, projectDir: dir, shots: script, direction });
        out({ ok: true, applied: report.applied.length, mapped: report.mapped, rejected: report.rejected, intent: report.intent, timing: report.timing });
        return 0;
      }
      throw new Error('Usage: nitaaq redirect request|apply <projectDir> [redirection.json]');
    }
    case 'create':
    case 'direct': {
      const file = pos[0];
      if (!file) throw new Error(`Usage: nitaaq ${cmd} <brief.json>`);
      const brief = JSON.parse(readFileSync(file, 'utf8'));
      const perf = new Perf();
      const shots = flag('shots') ? JSON.parse(readFileSync(resolve(flag('shots')!), 'utf8')) : undefined;
      const direction = flag('direction') ? JSON.parse(readFileSync(resolve(flag('direction')!), 'utf8')) : undefined;
      const film = flag('film') ? JSON.parse(readFileSync(resolve(flag('film')!), 'utf8')) : undefined;
      const r = await direct({ brief, baseDir: dirname(resolve(file)), projectDir: flag('project') ? resolve(flag('project')!) : undefined, assumeNoLogo: flag('no-logo') === 'true', cleanVoice: flag('clean-voice') === 'true', perf, shots, direction, film });
      if (r.status === 'needs-input') {
        out({ status: 'needs-input', questions: r.questions });
        return 2;
      }
      log.info('DIRECTOR', `project ready: ${r.projectDir}`);
      if (cmd === 'direct') {
        out({ status: 'ready', project: r.projectDir, assumptions: r.assumptions, scenes: r.storyboard!.scenes.map((s) => `${s.family}/${s.variant} ${s.duration}s`) });
        return 0;
      }
      const res = await produce({ projectDir: r.projectDir, profile: profileOf('production'), deliverTo: flag('out') ? resolve(flag('out')!) : undefined, name: flag('name'), animatic: flag('animatic') === 'true' ? true : undefined, perf });
      const extra = (brief.formats ?? []).filter((a: string) => a !== r.spec!.canvas.aspect) as Aspect[];
      const formats = [];
      if (res.ok && extra.length) {
        for (const m of recomposeProject(r.projectDir, extra)) {
          const fr = await produce({ projectDir: m.dir, profile: profileOf('production'), deliverTo: flag('out') ? resolve(flag('out')!) : undefined, name: `${flag('name') ?? r.spec!.project.id}-${m.aspect.replace(':', 'x')}` });
          formats.push({ aspect: m.aspect, ok: fr.ok, delivered: fr.delivered, scores: fr.report?.scores });
        }
      }
      out({ ok: res.ok && formats.every((f) => f.ok), delivered: res.delivered, formats, report: join(r.projectDir, 'quality_report.json'), performance: join(r.projectDir, 'performance_report.json'), summary: res.report?.summary, scores: res.report?.scores, repairs: res.repairs.length, totalSec: Math.round(res.perf.totalMs / 100) / 10 });
      return res.ok && formats.every((f) => f.ok) ? 0 : 1;
    }
    case 'produce': {
      const p = project(pos[0]);
      const res = await produce({ projectDir: p.dir, profile: profileOf('production'), deliverTo: flag('out') ? resolve(flag('out')!) : undefined, name: flag('name'), animatic: flag('animatic') === 'true' ? true : flag('no-animatic') === 'true' ? false : undefined });
      out({ ok: res.ok, delivered: res.delivered, animatic: res.animatic, summary: res.report?.summary, scores: res.report?.scores, failed: res.report?.acceptance.filter((a) => !a.ok).map((a) => a.rule), repairs: res.repairs.length, passes: res.passes, totalSec: Math.round(res.perf.totalMs / 100) / 10 });
      return res.ok ? 0 : 1;
    }
    case 'animatic': {
      const p = project(pos[0]);
      const res = await produce({ projectDir: p.dir, stopAfterAnimatic: true });
      let actingSheet: string | undefined;
      if (res.animatic && existsSync(join(p.dir, 'character_plan.json'))) {
        const { characterActingSheet } = await import('../src/node/character/preview');
        actingSheet = (await characterActingSheet(p.dir, res.animatic, join(p.dir, 'qc', 'character-acting.png'))).file;
      }
      out({ ok: res.ok, animatic: res.animatic, actingSheet, contactSheet: res.report?.contactSheet, phoneView: res.report?.phoneSheet, scores: res.report?.scores, critique: res.report?.critique, totalSec: Math.round(res.perf.totalMs / 100) / 10 });
      return res.ok ? 0 : 1;
    }
    case 'character': {
      // nitaaq character prepare <brief.json|image|sheet|svg|folder> · inspect <package> · bench <…> · sheet <projectDir> [--video f]
      const sub = pos[0];
      const target = pos[1];
      if (!sub || !target) throw new Error('Usage: nitaaq character prepare|inspect|bench <brief.json|art|package> · nitaaq character sheet <projectDir>');
      const { prepareCharacter, loadPackage } = await import('../src/node/character/package');
      const charOf = (t: string): { c: Record<string, unknown>; base: string } => {
        const f = resolve(t);
        if (f.endsWith('.json') && existsSync(f)) {
          const b = JSON.parse(readFileSync(f, 'utf8'));
          if (!b.character) throw new Error('this brief has no "character"');
          return { c: b.character, base: dirname(f) };
        }
        if (existsSync(f) && statSync(f).isDirectory()) return existsSync(join(f, 'character.json')) ? { c: { use: f }, base: dirname(f) } : { c: { poses: readdirSync(f).filter((x) => /\.png$/i.test(x)).map((x) => ({ path: join(f, x) })) }, base: f };
        if (/\.svg$/i.test(f)) return { c: { svg: f }, base: dirname(f) };
        return { c: { [flag('as') === 'sheet' ? 'sheet' : 'image']: f }, base: dirname(f) };
      };
      if (sub === 'sheet') {
        const p = project(target);
        const video = flag('video') ?? join(p.dir, 'renders', `${basename(p.dir)}-animatic.mp4`);
        if (!existsSync(video)) throw new Error(`no render at ${video} — run: nitaaq animatic ${p.dir}`);
        const { characterActingSheet } = await import('../src/node/character/preview');
        out(await characterActingSheet(p.dir, video, resolve(flag('out') ?? join(p.dir, 'qc', 'character-acting.png'))));
        return 0;
      }
      if (sub === 'inspect') {
        const dir = resolve(target);
        const pkg = loadPackage(dir);
        out({ name: pkg.manifest.name, sourceType: pkg.manifest.sourceType, complexity: pkg.manifest.animationCapabilities.complexity, poses: pkg.manifest.poses.map((x) => `${x.poseId}: ${x.semantics.state} ${Math.round(x.semantics.confidence * 100)}%`), rig: Boolean(pkg.rig), identityLock: pkg.bible.identityLock, restricted: pkg.manifest.restrictedActions, contactSheet: join(dir, 'thumbnails', 'contact.png') });
        return 0;
      }
      const { c, base } = charOf(target);
      if (sub === 'prepare') {
        const r = await prepareCharacter(c as never, { baseDir: base, force: flag('force') === 'true' });
        out({ dir: r.dir, cache: r.cache, sourceType: r.manifest.sourceType, complexity: r.manifest.animationCapabilities.complexity, poses: r.manifest.poses.map((x) => `${x.poseId}: ${x.semantics.state}`), rig: Boolean(r.rig), warnings: r.warnings, timings: r.timings, bible: join(r.dir, 'CHARACTER_BIBLE.md'), contactSheet: join(r.dir, 'thumbnails', 'contact.png') });
        return 0;
      }
      if (sub === 'bench') {
        const t1 = performance.now();
        const cold = await prepareCharacter(c as never, { baseDir: base, force: true });
        const coldMs = performance.now() - t1;
        const t2 = performance.now();
        const warm = await prepareCharacter(c as never, { baseDir: base });
        const warmMs = performance.now() - t2;
        out({ cold: { ms: Math.round(coldMs), stages: cold.timings }, warm: { ms: Math.round(warmMs), cache: warm.cache }, speedup: Math.round((coldMs / Math.max(1, warmMs)) * 10) / 10 });
        return 0;
      }
      throw new Error(`unknown character command: ${sub}`);
    }
    case 'variants': {
      // Ad creative variants: one directed film per strategy × aspect (recomposed per aspect, never cropped)
      const file = pos[0];
      if (!file) throw new Error(`Usage: nitaaq variants <brief.json> [--strategies ${VARIANT_STRATEGIES.join(',')}] [--aspects 9:16,4:5,1:1,16:9] [--plan-only]`);
      const raw = JSON.parse(readFileSync(file, 'utf8'));
      if (flag('strategies') || flag('aspects')) raw.variants = { ...(raw.variants ?? {}), ...(flag('strategies') ? { strategies: flag('strategies')!.split(',') } : {}), ...(flag('aspects') ? { aspects: flag('aspects')!.split(',') } : {}) };
      if (!raw.variants?.strategies) raw.variants = { ...(raw.variants ?? {}), strategies: [...VARIANT_STRATEGIES] };
      const brief = BriefSchema.parse(raw);
      const baseId = (brief.title ?? basename(file, '.json')).replace(/[^\w-]+/g, '-');
      const plan = planVariants(brief, baseId);
      for (const u of plan.unsupported) log.info('VARIANTS', `skipped ${u.strategy}: ${u.reason}`);
      const results = [];
      for (const job of plan.jobs) {
        log.info('VARIANTS', `${job.id} — ${job.why}`);
        const perf = new Perf();
        const r = await direct({ brief: job.brief, baseDir: dirname(resolve(file)), projectDir: join(workspace().projects, job.id), assumeNoLogo: flag('no-logo') === 'true', perf });
        if (r.status !== 'ready') {
          results.push({ id: job.id, strategy: job.strategy, aspect: job.aspect, ok: false, questions: r.questions });
          continue;
        }
        const scenes = r.storyboard!.scenes.map((s) => `${s.family}/${s.variant}`);
        if (flag('plan-only') === 'true') {
          results.push({ id: job.id, strategy: job.strategy, aspect: job.aspect, ok: true, project: r.projectDir, scenes });
          continue;
        }
        const res = await produce({ projectDir: r.projectDir, profile: profileOf('production'), deliverTo: flag('out') ? resolve(flag('out')!) : undefined, name: job.id, perf });
        results.push({ id: job.id, strategy: job.strategy, aspect: job.aspect, ok: res.ok, delivered: res.delivered, scenes, scores: res.report?.scores });
      }
      const report = { base: baseId, unsupported: plan.unsupported, results };
      const dest = flag('out') ? resolve(flag('out')!) : workspace().projects;
      mkdirSync(dest, { recursive: true });
      writeFileSync(join(dest, `${baseId}.variants-report.json`), JSON.stringify(report, null, 2));
      out(report);
      return results.every((r) => r.ok) ? 0 : 1;
    }
    case 'recompose': {
      const p = project(pos[0]);
      const aspects = (flag('aspects') ?? '9:16,16:9,1:1').split(',').map((x) => x.trim()) as Aspect[];
      const made = recomposeProject(p.dir, aspects);
      if (flag('render') === 'false') {
        out(made);
        return 0;
      }
      const results = [];
      for (const m of made) {
        const res = await produce({ projectDir: m.dir, profile: profileOf('production'), deliverTo: flag('out') ? resolve(flag('out')!) : undefined, name: `${flag('name') ?? basename(p.dir)}-${m.aspect.replace(':', 'x')}` });
        results.push({ aspect: m.aspect, ok: res.ok, delivered: res.delivered, scores: res.report?.scores, changes: m.changes, totalSec: Math.round(res.perf.totalMs / 100) / 10 });
      }
      out(results);
      return results.every((r) => r.ok) ? 0 : 1;
    }
    case 'seek': {
      // deterministic seek(t): the film's full state at t (+ the rendered frame with --png)
      const pr = project(pos[0]);
      const t = Number(pos[1]);
      if (!Number.isFinite(t)) throw new Error('Usage: nitaaq seek <projectDir|video.json> <seconds> [--png out.png]');
      const { seek } = await import('../src/engine/seek');
      const { loadSpec, prepare, renderFrame, closeBrowser } = await import('../src/node/render');
      const spec = loadSpec(pr.spec);
      const st = seek(spec, t);
      if (flag('png')) {
        const prep = await prepare(spec, pr.dir, 'render');
        await renderFrame(prep, st.frame, resolve(flag('png') === 'true' ? join(pr.dir, 'qc', `seek-${st.frame}.png`) : flag('png')!), Number(flag('scale') ?? 0.5));
        await closeBrowser();
      }
      out(st);
      return 0;
    }
    case 'video': {
      // Video Asset Pipeline: probe a clip, or prepare it into a project (normalise / proxy / segment)
      const sub = pos[0];
      const file = pos[1];
      if (!file || !['probe', 'prepare'].includes(sub ?? '')) throw new Error('Usage: nitaaq video probe <file> | nitaaq video prepare <file> --project <dir> [--id video-1] [--segment 4] [--proxy auto|always|never] [--loop] [--rate 1]');
      const v = await import('../src/node/video-assets');
      if (sub === 'probe') {
        const info = v.probeVideo(resolve(file));
        out({ ...info, normalize: v.normalizeReasons(info, extname(file).toLowerCase()), proxy: v.needsProxy(info) });
        return 0;
      }
      const dir = resolve(flag('project') ?? '.');
      const seg = flag('segment');
      const r = v.prepareVideoAsset(dir, resolve(file), { id: flag('id'), segment: seg ? Number(seg) : undefined, proxy: (flag('proxy') as 'auto' | 'always' | 'never' | undefined) ?? 'auto', loop: flag('loop') ? true : undefined, playbackRate: flag('rate') ? Number(flag('rate')) : undefined });
      out({ id: r.id, asset: r.asset, normalized: r.normalized, cached: r.cached });
      return 0;
    }
    case 'lottie': {
      // Lottie: inspect a file (timing, markers, what it uses, what would be refused), or prepare it into a project
      const sub = pos[0];
      const file = pos[1];
      if (!file || !['inspect', 'prepare'].includes(sub ?? '')) throw new Error('Usage: nitaaq lottie inspect <file.json|.lottie> | nitaaq lottie prepare <file> --project <dir> [--id lottie-1] [--kind lottie|logo|icon] [--marker name] [--loop] [--rate 1]');
      const l = await import('../src/node/lottie-assets');
      if (sub === 'inspect') {
        out(l.inspectLottieFile(resolve(file)));
        return 0;
      }
      const clip = { ...(flag('marker') ? { marker: flag('marker') } : {}), ...(flag('loop') ? { loop: true } : {}), ...(flag('rate') ? { playbackRate: Number(flag('rate')) } : {}) };
      const r = l.prepareLottieAsset(resolve(flag('project') ?? '.'), resolve(file), { id: flag('id'), kind: (flag('kind') as 'lottie' | 'logo' | 'icon' | undefined) ?? 'lottie', clip });
      out({ id: r.id, asset: r.asset, rewritten: r.rewritten, cached: r.cached });
      return 0;
    }
    case 'vector': {
      // Vector Engine: inspect an SVG (what it is made of, what was removed or is unsupported), prepare it into a project,
      // or print a Non-Destructive Vector Graph as SVG at second t
      const sub = pos[0];
      const file = pos[1];
      if (!file || !['inspect', 'prepare', 'frame'].includes(sub ?? '')) throw new Error('Usage: nitaaq vector inspect <file.svg> | nitaaq vector prepare <file.svg> --project <dir> [--id svg-1] [--kind svg|logo|icon|image] | nitaaq vector frame <graph.json> <t>');
      if (sub === 'frame') {
        const g = await import('../src/vector/graph');
        const graph = g.VectorGraphSchema.parse(JSON.parse(readFileSync(resolve(file), 'utf8')));
        process.stdout.write(`${g.graphToSvg(graph, Number(pos[2] ?? 0))}\n`);
        return 0;
      }
      const v = await import('../src/node/vector-assets');
      if (sub === 'inspect') {
        const { doc: _doc, ...r } = v.inspectVectorFile(resolve(file));
        out(r);
        return r.errors.length ? 1 : 0;
      }
      const r = v.prepareVectorAsset(resolve(flag('project') ?? '.'), resolve(file), { id: flag('id'), kind: (flag('kind') as 'svg' | 'logo' | 'icon' | 'image' | undefined) ?? 'svg' });
      out({ id: r.id, asset: r.asset, cached: r.cached });
      return 0;
    }
    case 'audio': {
      // Audio Engine 2.0: registry (local first), bilingual search, optional online fallback
      const sub = pos[0] ?? 'search';
      const { buildRegistry, findSound } = await import('../src/node/audio-library');
      if (sub === 'index') {
        const r = await buildRegistry();
        const by: Record<string, number> = {};
        for (const e of r) by[`${e.kind}:${e.license}`] = (by[`${e.kind}:${e.license}`] ?? 0) + 1;
        out({ entries: r.length, by, file: join(workspace().root, '.audio', 'registry.json') });
        return 0;
      }
      const q = pos.slice(1).join(' ');
      if (!q) throw new Error('Usage: nitaaq audio index | search <query> [--kind sfx|music] [--online] | fetch <query> [--provider ogsi|atomcut|sfxmint]');
      const kind = flag('kind') as 'sfx' | 'music' | undefined;
      const r = await findSound({ text: q, kind, limit: Number(flag('limit') ?? 8) }, { online: sub === 'fetch' || flag('online') === 'true', minScore: sub === 'fetch' ? Infinity : undefined, providers: flag('provider') ? [flag('provider')!] : undefined });
      out({ from: r.from, note: r.note, hits: r.hits.map((h) => ({ id: h.entry.id, score: h.score, why: h.why, license: h.entry.license, duration: h.entry.duration, path: h.entry.path })) });
      return 0;
    }
    case 'beats': {
      if (!pos[0]) throw new Error('Usage: nitaaq beats <audio file>');
      const b = await beatsFor(resolve(pos[0]));
      const { energy: _e, ...rest } = b;
      out({ ...rest, beats: b.beats.length > 24 ? [...b.beats.slice(0, 24), '…'] : b.beats });
      return 0;
    }
    case 'reference': {
      if (!pos[0]) throw new Error('Usage: nitaaq reference <image|video|https://site> [--out reference_style.json]');
      let file = resolve(pos[0]);
      let kind: 'website' | undefined;
      if (/^https?:/.test(pos[0])) {
        file = (await captureWebsite(pos[0], join(workspace().cache, 'captures', 'reference.png'))).file;
        kind = 'website';
      }
      const r = await analyzeReference(file, kind, pos[0]);
      if (flag('out')) writeFileSync(resolve(flag('out')!), JSON.stringify(r, null, 2));
      out(r);
      return 0;
    }
    case 'capture': {
      if (!pos[0]) throw new Error('Usage: nitaaq capture <https://site> [--out file.png] [--mobile]');
      const r = await captureWebsite(pos[0], resolve(flag('out') ?? 'site-capture.png'), { viewport: flag('mobile') === 'true' ? 'mobile' : 'desktop' });
      out(r);
      return 0;
    }
    case 'classify': {
      if (!pos[0]) throw new Error('Usage: nitaaq classify <brief.json>');
      const { brief } = intake(JSON.parse(readFileSync(pos[0], 'utf8')), { assumeNoLogo: true });
      out(classifyBrief(brief));
      return 0;
    }
    case 'cache': {
      if (pos[0] === 'clear') {
        clearCache(pos[1]);
        log.info('CACHE', `cleared ${pos[1] ?? 'everything'}`);
      }
      out(cacheSummary());
      return 0;
    }
    case 'validate': {
      const p = project(pos[0]);
      let spec = loadSpec(p.spec);
      if (flag('fix') === 'true') {
        const r = repairSpec(spec, nodeValidateOptions(p.dir, spec));
        spec = r.spec;
        writeFileSync(p.spec, JSON.stringify(spec, null, 2));
        for (const x of r.repairs) log.info('REPAIR', `${x.path}: ${x.issue} → ${x.fix}`);
      }
      const issues = validateSpec(spec, nodeValidateOptions(p.dir, spec));
      for (const i of issues) log.info('VALIDATION', `${i.severity.toUpperCase()} ${i.code} ${i.path}: ${i.message}`);
      const s = summarize(issues);
      log.info('VALIDATION', `critical ${s.critical}, error ${s.error}, warning ${s.warning}, info ${s.info}`);
      return s.critical + s.error === 0 ? 0 : 1;
    }
    case 'render': {
      const p = project(pos[0]);
      const spec = loadSpec(p.spec);
      const profile = profileOf('preview');
      const file = flag('out') ? resolve(flag('out')!) : join(p.dir, 'renders', `${spec.project.id}-${profile}.mp4`);
      mkdirSync(dirname(file), { recursive: true });
      const r = await renderVideo({ spec, projectDir: p.dir, output: file, profile, cache: flag('no-cache') !== 'true' });
      log.info('RENDER', `${file} (${(r.bytes / 1e6).toFixed(2)} MB). Not QC'd — run \`nitaaq quality\` or use \`nitaaq produce\` for a checked delivery.`);
      return 0;
    }
    case 'quality': {
      const p = project(pos[0]);
      const spec = loadSpec(p.spec);
      const video = flag('video') ? resolve(flag('video')!) : null;
      const r = await runQuality({ spec, projectDir: p.dir, video, outDir: join(p.dir, 'qc', 'manual'), profile: flag('profile') });
      for (const i of r.issues.filter((x) => x.severity !== 'info')) log.info('QUALITY', `${i.severity.toUpperCase()} ${i.code}${i.scene ? ` [${i.scene}]` : ''}: ${i.message}`);
      log.info('QUALITY', `${r.passed ? 'PASSED' : 'FAILED'} → ${join(p.dir, 'qc', 'manual', 'quality-report.json')}`);
      return r.passed ? 0 : 1;
    }
    case 'metrics': {
      if (!pos[0]) throw new Error('Usage: nitaaq metrics <file.mp4> [--project dir] [--compare before.json] [--out motion_metrics.json]');
      const { analyzeMotion, specNear, emphasisWordsOf } = await import('../src/node/motion-analysis');
      const { compareMetrics } = await import('../src/qc/motion-metrics');
      const spec = flag('project') ? specNear(resolve(flag('project')!)) : null;
      const words = spec ? emphasisWordsOf(spec) : [];
      const r = analyzeMotion(resolve(pos[0]), { spec, stage: 'external', out: flag('out') ? resolve(flag('out')!) : undefined, words: words.length ? words : undefined });
      const g = r.metrics.global;
      log.info('QUALITY', `motion score ${g.score} · still ${Math.round(g.stillFrameRatio * 100)}% · longest hold ${g.longestStaticHold.sec}s (${g.longestStaticHold.class ?? '—'}) · dead holds ${g.deadHoldSec}s → ${r.file}`);
      for (const w of r.metrics.warnings) log.info('QUALITY', `${w.code}${w.scene ? ` [${w.scene}]` : ''}: ${w.message}`);
      if (flag('compare')) out(compareMetrics(JSON.parse(readFileSync(resolve(flag('compare')!), 'utf8')), r.metrics));
      return 0;
    }
    case 'voice-map': {
      if (!pos[0]) throw new Error('Usage: nitaaq voice-map <audio> [--transcript text|file] [--offset s] [--engine auto|whisper|silence] [--model small] [--out voice_map.json]');
      const { voiceMap, readTranscript } = await import('../src/node/voice-map');
      const r = voiceMap(resolve(pos[0]), { transcript: readTranscript(flag('transcript')), offset: Number(flag('offset') ?? 0), engine: flag('engine') as 'auto' | 'whisper' | 'silence' | undefined, model: flag('model'), language: flag('language'), out: flag('out') ? resolve(flag('out')!) : undefined });
      const m = r.map;
      log.info('VOICE', `${m.engine.name}${m.engine.whisper.available ? ` (${m.engine.model})` : ` — Whisper unavailable: ${m.engine.whisper.reason}`} · ${m.words.length} words (${m.confidence.timing}) · ${m.pauses.length} pauses · ${m.speechRate.wordsPerMin} wpm → ${r.file}`);
      out({ engine: m.engine, confidence: m.confidence, words: m.words.length, emphasis: m.emphasisCandidates.map((e) => `${e.word}@${e.start}s (${e.reasons.join(', ')})`), keywords: m.keywords.map((k) => k.word) });
      return 0;
    }
    case 'brand': {
      const logo = pos[0];
      if (!logo) throw new Error('Usage: nitaaq brand <logo.png|svg|jpg|webp> [--name …]');
      const r = await brandFromLogo(resolve(logo), { projectRelativeLogo: basename(logo), name: flag('name') });
      out({ brand: r.brand, analysis: { width: r.analysis.width, height: r.analysis.height, hasAlpha: r.analysis.hasAlpha, dominant: r.analysis.dominant.slice(0, 6) } });
      return 0;
    }
    case 'scenes': {
      const list = SceneRegistry.list().map((m) => ({ id: m.manifest.id, category: m.manifest.category, variants: m.manifest.variants, beats: m.manifest.beats, duration: [m.manifest.minDuration, m.manifest.maxDuration] }));
      if (flag('json') === 'true') out(list);
      else for (const s of list) process.stdout.write(`${s.category.padEnd(12)} ${s.id.padEnd(22)} ${s.variants.join(', ')}\n`);
      process.stdout.write(`\n${list.length} families, ${list.reduce((a, s) => a + s.variants.length, 0)} variants\n`);
      return 0;
    }
    case 'styles': {
      for (const t of Object.values(STYLE_PRESETS)) process.stdout.write(`${t.id.padEnd(18)} ${t.mode.padEnd(5)} ${t.description}\n`);
      return 0;
    }
    case 'voices': {
      out(voiceProviders());
      return 0;
    }
    case 'schema-export': {
      const dir = resolve(flag('out') ?? join(ROOT, 'schemas'));
      mkdirSync(dir, { recursive: true });
      const write = (name: string, schema: Parameters<typeof zodToJsonSchema>[0]) => writeFileSync(join(dir, `${name}.schema.json`), JSON.stringify(zodToJsonSchema(schema, { name, $refStrategy: 'none' }), null, 2));
      write('video', VideoSchema);
      write('brief', BriefSchema);
      write('creative-plan', CreativePlanSchema);
      write('storyboard', StoryboardSchema);
      const scenes: Record<string, unknown> = {};
      for (const m of SceneRegistry.list()) scenes[m.manifest.id] = { variants: m.manifest.variants, content: zodToJsonSchema(m.manifest.content as never, { $refStrategy: 'none' }) };
      writeFileSync(join(dir, 'scene-content.schema.json'), JSON.stringify(scenes, null, 2));
      log.info('SCHEMA', `JSON Schemas written to ${dir}`);
      return 0;
    }
    case 'workspace': {
      out(workspace());
      return 0;
    }
    default:
      process.stdout.write(readFileSync(new URL(import.meta.url), 'utf8').split('*/')[0].replace(/^\/\*\*?/, '').replace(/^ \* ?/gm, '') + '\n');
      return cmd ? 1 : 0;
  }
}

main()
  .then(async (code) => {
    await closeBrowser();
    process.exit(code);
  })
  .catch((e) => {
    if (isMotionError(e)) process.stderr.write(formatMotionError(e) + '\n');
    else process.stderr.write(`Error: ${(e as Error).message}\n`);
    process.exit(1);
  });
